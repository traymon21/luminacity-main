-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 209.97.162.121
-- Generation Time: Oct 30, 2023 at 08:44 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `s154_curoleplay`
--

-- --------------------------------------------------------

--
-- Table structure for table `actor`
--

CREATE TABLE `actor` (
  `actorID` int(11) NOT NULL,
  `actorName` varchar(24) NOT NULL,
  `actorSkin` int(11) NOT NULL,
  `actorX` float NOT NULL,
  `actorY` float NOT NULL,
  `actorZ` float NOT NULL,
  `actorA` float NOT NULL,
  `actorVw` int(11) NOT NULL,
  `actorInt` int(11) NOT NULL,
  `animlib` varchar(32) NOT NULL DEFAULT 'null',
  `animname` varchar(32) NOT NULL DEFAULT 'null'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `actor`
--

INSERT INTO `actor` (`actorID`, `actorName`, `actorSkin`, `actorX`, `actorY`, `actorZ`, `actorA`, `actorVw`, `actorInt`, `animlib`, `animname`) VALUES
(1, 'Rent Owner', 170, 1739.16, -1850.33, 13.4141, 177.987, 0, 0, 'PED', 'IDLE_GANG1'),
(2, 'Your Helper', 71, 1746.87, -1850.38, 13.4141, 183.124, 0, 0, 'PED', 'IDLE_GANG1'),
(3, 'SECURITY', 71, 1172.32, -1324.75, 15.4061, 268.828, 0, 0, 'PED', 'IDLE_GANG1'),
(4, 'SECURITY', 71, 1172.08, -1321.38, 15.3987, 275.261, 0, 0, 'PED', 'IDLE_GANG1'),
(5, 'SECURITY', 71, 1483.23, -1772.04, 18.7958, 358.819, 0, 0, 'PED', 'IDLE_GANG1'),
(6, 'SECURITY', 71, 1478.72, -1771.88, 18.7958, 3.70945, 0, 0, 'PED', 'IDLE_GANG1'),
(7, 'Police Man', 71, 1552.46, -1673.11, 16.1953, 93.0939, 0, 0, 'PED', 'IDLE_GANG1'),
(8, 'Police Man', 71, 1552.33, -1678.02, 16.1953, 80.2262, 0, 0, 'PED', 'IDLE_GANG1'),
(9, 'SECURITY', 71, 647.829, -1363.56, 13.6057, 95.3915, 0, 0, 'PED', 'IDLE_GANG1'),
(10, 'SECURITY', 71, 647.862, -1358.82, 13.5802, 95.3915, 0, 0, 'PED', 'IDLE_GANG1'),
(11, 'SECURITY', 71, 1460.61, -1010.38, 26.8438, 174.01, 0, 0, 'PED', 'IDLE_GANG1'),
(12, 'SECURITY', 71, 1464, -1010.57, 26.8438, 182.742, 0, 0, 'PED', 'IDLE_GANG1'),
(13, 'SECURITY', 71, 2055.94, -1897.92, 13.5538, 190.667, 0, 0, 'PED', 'IDLE_GANG1'),
(15, 'Tukang Toll', 71, 66.4599, -1531.81, 5.12923, 353.491, 0, 0, 'PED', 'IDLE_GANG1'),
(16, 'Tukang Toll', 71, 36.4619, -1531.86, 5.43146, 171.111, 0, 0, 'PED', 'IDLE_GANG1'),
(17, 'Fishmonger', 168, 2838.1, -1534.27, 11.0991, 268.997, 0, 0, 'PED', 'IDLE_GANG1');

-- --------------------------------------------------------

--
-- Table structure for table `aksesoris`
--

CREATE TABLE `aksesoris` (
  `ID` int(11) NOT NULL,
  `accID` int(11) NOT NULL,
  `Model` int(11) NOT NULL,
  `Bone` int(11) NOT NULL DEFAULT 1,
  `Show` int(11) NOT NULL DEFAULT 0,
  `Type` varchar(32) NOT NULL DEFAULT 'NONE',
  `Color1` varchar(128) DEFAULT NULL,
  `Color2` varchar(128) DEFAULT NULL,
  `Offset` varchar(24) NOT NULL,
  `Rot` varchar(128) NOT NULL,
  `Scale` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `arrestrecord`
--

CREATE TABLE `arrestrecord` (
  `ID` int(11) NOT NULL,
  `owner` int(11) NOT NULL DEFAULT -1,
  `reason` varchar(128) NOT NULL DEFAULT '',
  `issued` varchar(128) NOT NULL DEFAULT '',
  `date` varchar(128) NOT NULL DEFAULT '',
  `fine` int(11) NOT NULL DEFAULT -1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `atms`
--

CREATE TABLE `atms` (
  `id` int(11) NOT NULL,
  `posx` float NOT NULL,
  `posy` float NOT NULL,
  `posz` float NOT NULL,
  `posrx` float NOT NULL,
  `posry` float NOT NULL,
  `posrz` float NOT NULL,
  `interior` int(11) NOT NULL DEFAULT 0,
  `world` int(11) NOT NULL DEFAULT 0,
  `atmmoney` int(11) NOT NULL DEFAULT 1000000
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=FIXED;

--
-- Dumping data for table `atms`
--

INSERT INTO `atms` (`id`, `posx`, `posy`, `posz`, `posrx`, `posry`, `posrz`, `interior`, `world`, `atmmoney`) VALUES
(0, 2365.23, -1767.38, 13.0766, 0, 0, 0, 0, 0, 1000000),
(1, 2373.06, -1750.23, 12.9228, 0, 0, 0, 0, 0, 1000000),
(2, -401.715, -1376.92, 23.5218, 0, 0, 0, 0, 0, 1000000);

-- --------------------------------------------------------

--
-- Table structure for table `auction_queue`
--

CREATE TABLE `auction_queue` (
  `ID` int(11) NOT NULL,
  `Property` int(11) NOT NULL,
  `Location` varchar(32) NOT NULL,
  `Date` int(11) NOT NULL,
  `Type` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auction_queue`
--

INSERT INTO `auction_queue` (`ID`, `Property`, `Location`, `Date`, `Type`) VALUES
(2, 1, 'Idlewood', 1689242107, 0),
(11, 1, 'El Corona', 1695112827, 0),
(27, 2, 'Willowfield', 1696777332, 0),
(59, 2, 'Willowfield', 1697119462, 0),
(64, 2, 'Idlewood', 1697518944, 0),
(64, 2, 'Idlewood', 1697588357, 0),
(64, 2, 'Idlewood', 1697589257, 0);

-- --------------------------------------------------------

--
-- Table structure for table `baju`
--

CREATE TABLE `baju` (
  `id` int(10) NOT NULL,
  `Owner` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `slot_baju0` int(8) NOT NULL DEFAULT -1,
  `slot_baju1` int(8) NOT NULL DEFAULT -1,
  `slot_baju2` int(8) NOT NULL DEFAULT -1,
  `slot_baju3` int(8) NOT NULL DEFAULT -1,
  `slot_baju4` int(8) NOT NULL DEFAULT -1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `baju`
--

INSERT INTO `baju` (`id`, `Owner`, `slot_baju0`, `slot_baju1`, `slot_baju2`, `slot_baju3`, `slot_baju4`) VALUES
(123, 'Alhard_Romeo', 62, -1, -1, -1, -1);

-- --------------------------------------------------------

--
-- Table structure for table `bisnis`
--

CREATE TABLE `bisnis` (
  `ID` int(11) NOT NULL,
  `owner` varchar(40) NOT NULL DEFAULT '-',
  `name` varchar(40) NOT NULL DEFAULT 'Bisnis',
  `price` int(11) NOT NULL DEFAULT 500000,
  `type` int(11) NOT NULL DEFAULT 1,
  `locked` int(11) NOT NULL DEFAULT 1,
  `money` int(11) NOT NULL DEFAULT 0,
  `prod` int(11) NOT NULL DEFAULT 50,
  `bprice0` int(11) NOT NULL DEFAULT 500,
  `bprice1` int(11) NOT NULL DEFAULT 500,
  `bprice2` int(11) NOT NULL DEFAULT 500,
  `bprice3` int(11) NOT NULL DEFAULT 500,
  `bprice4` int(11) NOT NULL DEFAULT 500,
  `bprice5` int(11) NOT NULL DEFAULT 500,
  `bprice6` int(11) NOT NULL DEFAULT 500,
  `bprice7` int(11) NOT NULL DEFAULT 500,
  `bprice8` int(11) NOT NULL DEFAULT 500,
  `bprice9` int(11) NOT NULL DEFAULT 500,
  `bprice10` int(11) NOT NULL DEFAULT 500,
  `bint` int(11) NOT NULL DEFAULT 0,
  `extposx` float NOT NULL DEFAULT 0,
  `extposy` float NOT NULL DEFAULT 0,
  `extposz` float NOT NULL DEFAULT 0,
  `extposa` float NOT NULL DEFAULT 0,
  `intposx` float NOT NULL DEFAULT 0,
  `intposy` float NOT NULL DEFAULT 0,
  `intposz` float NOT NULL DEFAULT 0,
  `intposa` float NOT NULL DEFAULT 0,
  `pointx` float DEFAULT 0,
  `pointy` float DEFAULT 0,
  `pointz` float DEFAULT 0,
  `visit` bigint(20) NOT NULL DEFAULT 0,
  `restock` tinyint(4) NOT NULL DEFAULT 0,
  `segel` int(11) NOT NULL DEFAULT 0,
  `bpname0` varchar(40) NOT NULL,
  `bpname1` varchar(40) NOT NULL,
  `bpname2` varchar(40) NOT NULL,
  `bpname3` varchar(40) NOT NULL,
  `bpname4` varchar(40) NOT NULL,
  `bpname5` varchar(40) NOT NULL,
  `bpname6` varchar(40) NOT NULL,
  `bpname7` varchar(40) NOT NULL,
  `bpname8` varchar(40) NOT NULL,
  `bpname9` varchar(40) NOT NULL,
  `bpname10` varchar(40) NOT NULL,
  `bpname11` varchar(40) NOT NULL,
  `stream` varchar(40) NOT NULL DEFAULT '',
  `extvw` int(11) NOT NULL DEFAULT 0,
  `extint` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0|0',
  `vehiclepos` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0.00|0.00|0.00|0.00',
  `vehiclepos1` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0.00|0.00|0.00|0.00	',
  `garagepos` varchar(52) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0.00|0.00|0.00|0	'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `bisnis`
--

INSERT INTO `bisnis` (`ID`, `owner`, `name`, `price`, `type`, `locked`, `money`, `prod`, `bprice0`, `bprice1`, `bprice2`, `bprice3`, `bprice4`, `bprice5`, `bprice6`, `bprice7`, `bprice8`, `bprice9`, `bprice10`, `bint`, `extposx`, `extposy`, `extposz`, `extposa`, `intposx`, `intposy`, `intposz`, `intposa`, `pointx`, `pointy`, `pointz`, `visit`, `restock`, `segel`, `bpname0`, `bpname1`, `bpname2`, `bpname3`, `bpname4`, `bpname5`, `bpname6`, `bpname7`, `bpname8`, `bpname9`, `bpname10`, `bpname11`, `stream`, `extvw`, `extint`, `vehiclemodel`, `vehiclepos`, `vehiclepos1`, `garagepos`) VALUES
(5, 'Daniel_Pitcher', 'Northrop Grumman Gunshop', 5500000, 7, 0, 84575, 999, 5000, 4500, 5000, 4800, 0, 0, 0, 0, 0, 0, 0, 1, 1368.29, -1279.87, 13.5469, 273.621, 286.149, -40.6444, 1001.52, 0, 295.446, -38.0804, 1001.52, 1698651866, 1, 0, '{ADD8E6}Avtomat Kalashnikova 47', '{ffffff}Maschinepistole 5', '{ADD8E6}Desert Eagle', '{ffffff}Shotgun', '', '', '', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(1, 'Daniel_Pitcher', '102th Idlewood Sportshop', 5500000, 4, 0, 87094, 926, 100, 100, 2250, 2250, 2500, 0, 0, 0, 0, 0, 0, 1, 1928.88, -1776.3, 13.5469, 91.6002, 203.72, -50.0292, 1001.8, 5.1475, 203.843, -43.2778, 1001.8, 1698651866, 1, 0, '{add8e6}Baseball', '{ffffff}Shovel', '{ffff00}Cane', '{00ff00}FIsh Tool', '{ff0000}Mask', '', '', '', '', '', '', '', '', 0, 0, '0|0|0|0.000000|0|0|0|0.000000|0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0'),
(3, '-', 'Pinky Clotches', 5500000, 3, 0, 333625, 0, 2500, 1000, 1000, 1000, 1000, 1000, 1000, 700, 1200, 0, 0, 15, 2244.39, -1665.57, 15.4766, 78.1779, 207.55, -110.67, 1005.13, 0.159997, 207.541, -100.91, 1005.26, 1698650601, 0, 0, '{ffc0cb}Clothes', '{ffc0cb}Caps', '{ffc0cb}Bandana', '{ffc0cb}Fake Mask', '{ffc0cb}Helmet', '{ffc0cb}Watch', '{ffc0cb}Glasses', '{ffc0cb}Hairs', '{ffc0cb}Accessories', '', '', '', '', 0, 0, '0|0|0|0.000000|0|0|0|0.000000|0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0'),
(4, '-', 'Verdant Bluffs', 5500000, 5, 0, 68771, 911, 3500, 100, 100, 150, 0, 0, 0, 0, 0, 0, 0, 6, 1597.04, -1862.97, 13.5217, 178.31, -2240.39, 137.399, 1035.41, 270.259, -2235.41, 130.158, 1035.41, 1698650601, 1, 0, 'Handphone', 'GPS', 'Phone credit', 'Walkie talkie', '', '', '', '', '', '', '', '', '', 0, 0, '0|0|0|0.000000|0|0|0|0.000000|0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0'),
(0, 'Jhon_Andreas', 'RM.Barokah', 5500000, 1, 0, 35147, 663, 200, 300, 400, 400, 2500, 0, 0, 0, 0, 0, 0, 5, 2105.49, -1806.59, 13.5547, 279.246, 372.34, -133.25, 1001.49, 4.8, 375.44, -119.912, 1001.5, 1698650601, 1, 0, 'mini pizza', 'medium pizza', 'large pizza', 'cola', '{00ff00}X Card', '', '', '', '', '', '', '', 'http://j.top4top.io/m_2845r3r0h0.mp3', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(6, '-', 'Marina', 5500000, 4, 0, 9883, 996, 375, 375, 375, 3750, 3750, 0, 0, 0, 0, 0, 0, 1, 850.925, -1587.44, 13.5469, 44.9905, 203.72, -50.0292, 1001.8, 5.1475, 203.843, -43.2778, 1001.8, 1698650601, 1, 0, 'Baseball Bat', 'Shovel', 'Cane', 'Fishing Tools', 'Mask', '', '', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(7, 'Daniel_Pitcher', 'Helathy Gym', 5500000, 6, 0, 21082, 958, 3500, 100, 100, 150, 0, 0, 0, 0, 0, 0, 0, 6, 2229.8, -1721.36, 13.5622, 323.249, 774.2, -50.3137, 1000.59, 322.598, 767.628, -37.0808, 1000.69, 1698651866, 1, 0, 'GYM Membership', 'Energy Drink', 'Water', 'Snack', '', '', '', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(10, '-', 'Palomino Creek', 5500000, 1, 0, 0, 1000, 75, 300, 350, 375, 0, 0, 0, 0, 0, 0, 0, 10, 2333.04, -17.2583, 26.4844, 49.3795, 363.22, -74.86, 1001.5, 319.72, 376.814, -68.0401, 1001.52, 1698650601, 1, 0, 'Fried Chicken(+25)', 'Pizza Stack(+45)', 'Patty Burger(+60)', 'Sprunk(+45)', '', '', '', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(12, '-', 'Market', 5500000, 3, 0, 179350, 875, 2500, 1000, 1000, 1000, 1000, 1000, 0, 0, 0, 0, 0, 15, 1133.39, -1370.21, 13.9844, 0.96205, 207.55, -110.67, 1005.13, 0.159997, 207.523, -100.736, 1005.26, 1698650601, 1, 0, 'Clothes', 'Hats', 'Glasses', 'Helm', 'Accessory', 'Mask (Accessory)', 'Hairs', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(13, '-', 'Market', 5500000, 3, 0, 10625, 994, 2500, 1000, 1000, 1000, 1000, 1000, 0, 0, 0, 0, 0, 14, 1154.73, -1439.91, 15.7969, 246.597, 204.49, -168.26, 1000.52, 358.74, 204.372, -159.698, 1000.52, 1698650601, 1, 0, 'Clothes', 'Hats', 'Glasses', 'Helm', 'Accessory', 'Mask (Accessory)', 'Hairs', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(14, '-', 'Whetstone', 5500000, 7, 0, 19550, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, -2626.28, -2281.76, 7.57368, 128.126, 286.149, -40.6444, 1001.52, 0, 295.446, -38.0804, 1001.52, 1698650601, 1, 0, 'AK47', 'MP5', 'Desert Eagle', 'Shotgun', '', '', '', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(11, 'Daniel_Pitcher', 'Corner Device', 5500000, 5, 0, 501377, 419, 3500, 100, 100, 150, 0, 0, 0, 0, 0, 0, 0, 6, 1847.94, -1871.72, 13.5781, 268.918, -2240.39, 137.399, 1035.41, 270.259, -2235.41, 130.158, 1035.41, 1698651866, 1, 0, '{ADD8E6}Line Phone', '{ffff00}Global Positioning System', '{add8e6}Phone Credits', '{00ff00}Walkie Talkie', '', '', '', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(2, '-', 'Playa del Seville', 5500000, 2, 0, 17769, 987, 100, 100, 2250, 2250, 2500, 0, 0, 0, 0, 0, 0, 6, 2723.86, -2033.73, 13.5472, 269.062, -26.68, -57.92, 1003.54, 357.58, -23.4406, -55.6324, 1003.55, 1698650601, 1, 0, 'Snack', 'Sprunk', 'Bandage', 'Cigarretes', 'Toll Card', '', '', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(17, '-', 'Temple', 5500000, 1, 0, 9679, 967, 75, 300, 350, 375, 0, 0, 0, 0, 0, 0, 0, 10, 1200.43, -918.535, 43.1124, 276.402, 363.22, -74.86, 1001.5, 319.72, 376.814, -68.0401, 1001.52, 1698650601, 1, 0, 'Fried Chicken(+25)', 'Pizza Stack(+45)', 'Patty Burger(+60)', 'Sprunk(+45)', '', '', '', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(8, '-', 'Ganton', 5500000, 3, 0, 4250, 998, 2500, 1000, 1000, 1000, 1000, 1000, 0, 0, 0, 0, 0, 14, 2368.7, -1760.41, 13.5469, 190.615, 204.49, -168.26, 1000.52, 358.74, 204.372, -159.698, 1000.52, 1698650601, 1, 0, 'Clothes', 'Hats', 'Glasses', 'Helm', 'Accessory', 'Mask (Accessory)', 'Hairs', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(9, '-', 'Ganton', 5500000, 3, 0, 0, 1000, 2500, 1000, 1000, 1000, 1000, 1000, 0, 0, 0, 0, 0, 14, 2373.4, -1761.61, 13.5469, 38.888, 204.49, -168.26, 1000.52, 358.74, 204.372, -159.698, 1000.52, 1698650601, 1, 0, 'Clothes', 'Hats', 'Glasses', 'Helm', 'Accessory', 'Mask (Accessory)', 'Hairs', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0'),
(15, '-', 'Ganton', 5500000, 3, 0, 0, 1000, 2500, 1000, 1000, 1000, 1000, 1000, 0, 0, 0, 0, 0, 14, 2370.36, -1765.06, 13.5469, 83.888, 204.49, -168.26, 1000.52, 358.74, 204.372, -159.698, 1000.52, 1698650601, 1, 0, 'Clothes', 'Hats', 'Glasses', 'Helm', 'Accessory', 'Mask (Accessory)', 'Hairs', '', '', '', '', '', '', 0, 0, '0|0', '0.00|0.00|0.00|0.00', '0.00|0.00|0.00|0.00	', '0.00|0.00|0.00|0');

-- --------------------------------------------------------

--
-- Table structure for table `business_employee`
--

CREATE TABLE `business_employee` (
  `ID` int(11) NOT NULL,
  `Biz` int(10) UNSIGNED NOT NULL,
  `Name` varchar(24) NOT NULL,
  `Time` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `casino`
--

CREATE TABLE `casino` (
  `casinoID` int(11) NOT NULL,
  `casinoOwner` int(11) NOT NULL DEFAULT -1,
  `casinoPrice` int(11) NOT NULL DEFAULT 99999999,
  `casinoName` varchar(128) NOT NULL DEFAULT 'Casino',
  `casinoOwnerName` varchar(128) NOT NULL DEFAULT 'None',
  `ExtPosX` float NOT NULL DEFAULT 0,
  `ExtPosY` float NOT NULL DEFAULT 0,
  `ExtPosZ` float NOT NULL DEFAULT 0,
  `ExtPosA` float NOT NULL DEFAULT 0,
  `IntPosX` float NOT NULL DEFAULT 0,
  `IntPosY` float NOT NULL DEFAULT 0,
  `IntPosZ` float NOT NULL DEFAULT 0,
  `IntPosA` float NOT NULL DEFAULT 0,
  `Interior` int(11) NOT NULL DEFAULT 0,
  `World` int(11) NOT NULL DEFAULT 0,
  `Vault` int(11) NOT NULL DEFAULT 0,
  `int` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cd`
--

CREATE TABLE `cd` (
  `ID` int(11) NOT NULL,
  `owner` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '-',
  `name` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Dealership',
  `entrancex` float NOT NULL DEFAULT 0,
  `entrancey` float NOT NULL DEFAULT 0,
  `entrancez` float NOT NULL DEFAULT 0,
  `exitx` float NOT NULL DEFAULT 0,
  `exity` float NOT NULL DEFAULT 0,
  `exitz` float NOT NULL DEFAULT 0,
  `till` int(11) NOT NULL DEFAULT 0,
  `interior` int(11) NOT NULL DEFAULT 0,
  `vehiclespawnx` float NOT NULL DEFAULT 0,
  `vehiclespawny` float NOT NULL DEFAULT 0,
  `vehiclespawnz` float NOT NULL DEFAULT 0,
  `vehiclespawna` float NOT NULL DEFAULT 0,
  `radius` float NOT NULL DEFAULT 0,
  `price` int(11) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0,
  `vehiclex0` float DEFAULT 0,
  `vehicley0` float DEFAULT 0,
  `vehiclez0` float DEFAULT 0,
  `vehiclea0` float DEFAULT 0,
  `vehicleprice0` int(11) DEFAULT 0,
  `vehiclemodel0` int(11) DEFAULT 0,
  `vehiclex1` float NOT NULL DEFAULT 0,
  `vehicley1` float NOT NULL DEFAULT 0,
  `vehiclez1` float NOT NULL DEFAULT 0,
  `vehiclea1` float NOT NULL DEFAULT 0,
  `vehicleprice1` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel1` int(11) NOT NULL DEFAULT 0,
  `vehiclex2` float NOT NULL DEFAULT 0,
  `vehicley2` float NOT NULL DEFAULT 0,
  `vehiclez2` float NOT NULL DEFAULT 0,
  `vehiclea2` float NOT NULL DEFAULT 0,
  `vehicleprice2` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel2` int(11) NOT NULL DEFAULT 0,
  `vehiclex3` float NOT NULL DEFAULT 0,
  `vehicley3` float NOT NULL DEFAULT 0,
  `vehiclez3` float NOT NULL DEFAULT 0,
  `vehiclea3` float NOT NULL DEFAULT 0,
  `vehicleprice3` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel3` int(11) NOT NULL DEFAULT 0,
  `vehiclex4` float NOT NULL DEFAULT 0,
  `vehicley4` float NOT NULL DEFAULT 0,
  `vehiclez4` float NOT NULL DEFAULT 0,
  `vehiclea4` decimal(10,0) NOT NULL DEFAULT 0,
  `vehicleprice4` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel4` int(11) NOT NULL DEFAULT 0,
  `vehiclex5` float NOT NULL DEFAULT 0,
  `vehicley5` float NOT NULL DEFAULT 0,
  `vehiclez5` float NOT NULL DEFAULT 0,
  `vehiclea5` float NOT NULL DEFAULT 0,
  `vehicleprice5` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel5` int(11) NOT NULL DEFAULT 0,
  `vehiclex6` float NOT NULL DEFAULT 0,
  `vehicley6` float NOT NULL DEFAULT 0,
  `vehiclez6` float NOT NULL DEFAULT 0,
  `vehiclea6` float NOT NULL DEFAULT 0,
  `vehicleprice6` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel6` int(11) NOT NULL DEFAULT 0,
  `vehiclex7` float NOT NULL DEFAULT 0,
  `vehicley7` float NOT NULL DEFAULT 0,
  `vehiclez7` float NOT NULL DEFAULT 0,
  `vehiclea7` float NOT NULL DEFAULT 0,
  `vehicleprice7` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel7` int(11) NOT NULL DEFAULT 0,
  `vehiclex8` float NOT NULL DEFAULT 0,
  `vehicley8` float NOT NULL DEFAULT 0,
  `vehiclez8` float NOT NULL DEFAULT 0,
  `vehiclea8` float NOT NULL DEFAULT 0,
  `vehicleprice8` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel8` int(11) NOT NULL DEFAULT 0,
  `vehiclex9` float NOT NULL DEFAULT 0,
  `vehicley9` float NOT NULL DEFAULT 0,
  `vehiclez9` float NOT NULL DEFAULT 0,
  `vehiclea9` float NOT NULL DEFAULT 0,
  `vehicleprice9` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel9` int(11) NOT NULL DEFAULT 0,
  `vehiclex10` float NOT NULL DEFAULT 0,
  `vehicley10` float NOT NULL DEFAULT 0,
  `vehiclez10` float NOT NULL DEFAULT 0,
  `vehiclea10` float NOT NULL DEFAULT 0,
  `vehicleprice10` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel10` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cd_employee`
--

CREATE TABLE `cd_employee` (
  `ID` int(11) NOT NULL,
  `Biz` int(10) UNSIGNED NOT NULL,
  `Name` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Time` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `ID` int(12) DEFAULT 0,
  `contactID` int(12) NOT NULL,
  `contactName` varchar(32) DEFAULT NULL,
  `contactNumber` int(12) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `crimerecord`
--

CREATE TABLE `crimerecord` (
  `id` int(11) NOT NULL,
  `owner` int(11) NOT NULL DEFAULT -1,
  `reason` varchar(128) NOT NULL DEFAULT '',
  `issue` varchar(128) NOT NULL DEFAULT '',
  `date` varchar(128) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `damages`
--

CREATE TABLE `damages` (
  `IDs` int(10) UNSIGNED NOT NULL,
  `weapon` int(10) UNSIGNED NOT NULL,
  `bodypart` int(10) UNSIGNED NOT NULL,
  `amount` int(10) UNSIGNED NOT NULL,
  `time` int(11) NOT NULL,
  `ID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `damages`
--

INSERT INTO `damages` (`IDs`, `weapon`, `bodypart`, `amount`, `time`, `ID`) VALUES
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(8, 6, 0, 56, 1696787028, 0),
(8, 6, 0, 56, 1696787028, 0),
(5, 0, 0, 2, 1697660449, 0),
(8, 6, 0, 56, 1696787028, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(14, 0, 0, 2, 1697719214, 0),
(14, 0, 0, 2, 1697719214, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(8, 6, 0, 56, 1696787028, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(25, 24, 0, 5, 1697589551, 0),
(34, 0, 0, 82, 1696154815, 0),
(35, 25, 6, 1, 1696692109, 0),
(29, 24, 0, 5, 1697589551, 0),
(33, 0, 0, 2, 1696144685, 0),
(37, 0, 0, 2, 1696144789, 0),
(5, 0, 0, 2, 1697660449, 0),
(32, 0, 0, 4, 1696600760, 0),
(44, 0, 0, 16, 1696146502, 0),
(10, 24, 0, 1, 1696949538, 0),
(59, 0, 0, 4, 1696149222, 0),
(60, 0, 0, 82, 1696154815, 0),
(10, 24, 0, 1, 1696949538, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(62, 24, 4, 1, 1696169208, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(67, 0, 0, 82, 1696154815, 0),
(9, 24, 3, 1, 1697468869, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(10, 24, 0, 1, 1696949538, 0),
(70, 25, 6, 1, 1696692109, 0),
(47, 24, 0, 1, 1696949538, 0),
(9, 24, 3, 1, 1697468869, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(25, 24, 0, 5, 1697589551, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(92, 8, 0, 2, 1696154673, 0),
(9, 24, 3, 1, 1697468869, 0),
(45, 5, 0, 68, 1697440555, 0),
(111, 5, 0, 4, 1697380116, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(64, 5, 0, 42, 1696157691, 0),
(45, 5, 0, 68, 1697440555, 0),
(45, 5, 0, 68, 1697440555, 0),
(45, 5, 0, 68, 1697440555, 0),
(45, 5, 0, 68, 1697440555, 0),
(123, 0, 0, 4, 1697657199, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(10, 24, 0, 1, 1696949538, 0),
(18, 24, 0, 3, 1697558894, 0),
(202, 0, 0, 50, 1697206359, 0),
(154, 24, 0, 1, 1696412562, 0),
(83, 0, 0, 4, 1697657199, 0),
(41, 0, 0, 50, 1696428439, 0),
(9, 24, 3, 1, 1697468869, 0),
(35, 25, 6, 1, 1696692109, 0),
(203, 0, 0, 2, 1696418402, 0),
(10, 24, 0, 1, 1696949538, 0),
(109, 5, 0, 4, 1696425316, 0),
(41, 0, 0, 50, 1696428439, 0),
(29, 24, 0, 5, 1697589551, 0),
(18, 24, 0, 3, 1697558894, 0),
(41, 0, 0, 50, 1696428439, 0),
(208, 0, 0, 2, 1696507168, 0),
(220, 0, 0, 130, 1696585857, 0),
(25, 24, 0, 5, 1697589551, 0),
(18, 24, 0, 3, 1697558894, 0),
(188, 0, 0, 80, 1697377267, 0),
(29, 24, 0, 5, 1697589551, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(18, 24, 0, 3, 1697558894, 0),
(29, 24, 0, 5, 1697589551, 0),
(188, 0, 0, 80, 1697377267, 0),
(96, 24, 0, 1, 1696949538, 0),
(47, 24, 0, 1, 1696949538, 0),
(197, 0, 0, 2, 1697641462, 0),
(83, 0, 0, 4, 1697657199, 0),
(146, 0, 0, 4, 1696599922, 0),
(57, 29, 0, 5, 1697542988, 0),
(123, 0, 0, 4, 1697657199, 0),
(5, 0, 0, 2, 1697660449, 0),
(12, 0, 0, 2, 1697458964, 0),
(197, 0, 0, 2, 1697641462, 0),
(14, 0, 0, 2, 1697719214, 0),
(5, 0, 0, 2, 1697660449, 0),
(29, 24, 0, 5, 1697589551, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(150, 0, 0, 2, 1697660449, 0),
(224, 0, 0, 12, 1696692807, 0),
(25, 24, 0, 5, 1697589551, 0),
(150, 0, 0, 2, 1697660449, 0),
(47, 24, 0, 1, 1696949538, 0),
(5, 0, 0, 2, 1697660449, 0),
(18, 24, 0, 3, 1697558894, 0),
(25, 24, 0, 5, 1697589551, 0),
(57, 29, 0, 5, 1697542988, 0),
(5, 0, 0, 2, 1697660449, 0),
(89, 6, 0, 56, 1696787028, 0),
(229, 24, 6, 1, 1696771468, 0),
(5, 0, 0, 2, 1697660449, 0),
(88, 24, 6, 1, 1696771468, 0),
(10, 24, 0, 1, 1696949538, 0),
(19, 24, 1, 1, 1697643706, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(9, 24, 3, 1, 1697468869, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(9, 24, 3, 1, 1697468869, 0),
(19, 24, 1, 1, 1697643706, 0),
(9, 24, 3, 1, 1697468869, 0),
(19, 24, 1, 1, 1697643706, 0),
(88, 24, 6, 1, 1696771468, 0),
(88, 24, 6, 1, 1696771468, 0),
(9, 24, 3, 1, 1697468869, 0),
(88, 24, 6, 1, 1696771468, 0),
(72, 0, 0, 6, 1696771650, 0),
(10, 24, 0, 1, 1696949538, 0),
(10, 24, 0, 1, 1696949538, 0),
(5, 0, 0, 2, 1697660449, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(197, 0, 0, 2, 1697641462, 0),
(10, 24, 0, 1, 1696949538, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(19, 24, 1, 1, 1697643706, 0),
(57, 29, 0, 5, 1697542988, 0),
(197, 0, 0, 2, 1697641462, 0),
(234, 0, 0, 4, 1697657199, 0),
(235, 0, 0, 2, 1696869535, 0),
(123, 0, 0, 4, 1697657199, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(15, 0, 0, 8, 1697553900, 0),
(47, 24, 0, 1, 1696949538, 0),
(9, 24, 3, 1, 1697468869, 0),
(18, 24, 0, 3, 1697558894, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(19, 24, 1, 1, 1697643706, 0),
(15, 0, 0, 8, 1697553900, 0),
(10, 24, 0, 1, 1696949538, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(150, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(19, 24, 1, 1, 1697643706, 0),
(150, 0, 0, 2, 1697660449, 0),
(57, 29, 0, 5, 1697542988, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(239, 0, 0, 48, 1697131895, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(5, 0, 0, 2, 1697660449, 0),
(19, 24, 1, 1, 1697643706, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(245, 0, 0, 2, 1697209142, 0),
(19, 24, 1, 1, 1697643706, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(188, 0, 0, 80, 1697377267, 0),
(272, 5, 0, 8, 1697379379, 0),
(273, 0, 0, 10, 1697379032, 0),
(18, 24, 0, 3, 1697558894, 0),
(282, 0, 0, 4, 1697657199, 0),
(249, 0, 0, 30, 1697468588, 0),
(288, 24, 0, 1, 1697558235, 0),
(260, 5, 0, 4, 1697380116, 0),
(260, 5, 0, 4, 1697380116, 0),
(45, 5, 0, 68, 1697440555, 0),
(57, 29, 0, 5, 1697542988, 0),
(290, 1, 0, 42, 1697379512, 0),
(290, 1, 0, 42, 1697379512, 0),
(116, 0, 0, 2, 1697547573, 0),
(29, 24, 0, 5, 1697589551, 0),
(293, 0, 0, 2, 1697547573, 0),
(5, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(45, 5, 0, 68, 1697440555, 0),
(116, 0, 0, 2, 1697547573, 0),
(290, 1, 0, 42, 1697379512, 0),
(263, 5, 0, 2, 1697379061, 0),
(25, 24, 0, 5, 1697589551, 0),
(281, 0, 0, 6, 1697533204, 0),
(29, 24, 0, 5, 1697589551, 0),
(292, 0, 0, 10, 1697459724, 0),
(18, 24, 0, 3, 1697558894, 0),
(263, 5, 0, 2, 1697379061, 0),
(285, 0, 0, 10, 1697379032, 0),
(45, 5, 0, 68, 1697440555, 0),
(18, 24, 0, 3, 1697558894, 0),
(25, 24, 0, 5, 1697589551, 0),
(29, 24, 0, 5, 1697589551, 0),
(38, 5, 0, 4, 1697380116, 0),
(38, 5, 0, 4, 1697380116, 0),
(18, 24, 0, 3, 1697558894, 0),
(292, 0, 0, 10, 1697459724, 0),
(9, 24, 3, 1, 1697468869, 0),
(281, 0, 0, 6, 1697533204, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(19, 24, 1, 1, 1697643706, 0),
(9, 24, 3, 1, 1697468869, 0),
(19, 24, 1, 1, 1697643706, 0),
(150, 0, 0, 2, 1697660449, 0),
(9, 24, 3, 1, 1697468869, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(386, 0, 0, 2, 1697660449, 0),
(386, 0, 0, 2, 1697660449, 0),
(293, 0, 0, 2, 1697547573, 0),
(150, 0, 0, 2, 1697660449, 0),
(19, 24, 1, 1, 1697643706, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(371, 24, 0, 5, 1697589551, 0),
(371, 24, 0, 5, 1697589551, 0),
(371, 24, 0, 5, 1697589551, 0),
(19, 24, 1, 1, 1697643706, 0),
(197, 0, 0, 2, 1697641462, 0),
(282, 0, 0, 4, 1697657199, 0),
(19, 24, 1, 1, 1697643706, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(150, 0, 0, 2, 1697660449, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(19, 24, 1, 1, 1697643706, 0),
(419, 0, 0, 2, 1697660449, 0),
(5, 0, 0, 2, 1697660449, 0),
(419, 0, 0, 2, 1697660449, 0),
(14, 0, 0, 2, 1697719214, 0),
(1, 24, 1, 1, 1698354139, 0),
(1, 24, 1, 1, 1698354139, 0),
(2, 24, 1, 1, 1698354381, 0),
(1, 24, 1, 1, 1698354139, 0),
(4, 38, 3, 2, 1698354444, 0),
(2, 24, 1, 1, 1698354381, 0),
(1, 24, 1, 1, 1698354139, 0),
(4, 38, 3, 2, 1698354444, 0),
(4, 38, 3, 2, 1698354444, 0),
(2, 24, 1, 1, 1698354381, 0),
(2, 24, 1, 1, 1698354381, 0),
(2, 24, 1, 1, 1698354381, 0),
(2, 24, 1, 1, 1698354381, 0),
(1, 24, 1, 1, 1698354139, 0),
(1, 24, 1, 1, 1698354139, 0),
(1, 24, 1, 1, 1698354139, 0),
(4, 38, 3, 2, 1698354444, 0),
(4, 38, 3, 2, 1698354444, 0),
(4, 38, 3, 2, 1698354444, 0),
(4, 38, 3, 2, 1698354444, 0),
(4, 38, 3, 2, 1698354444, 0),
(2, 24, 1, 1, 1698354381, 0),
(1, 24, 1, 1, 1698354139, 0),
(2, 24, 1, 1, 1698354381, 0),
(2, 24, 1, 1, 1698354381, 0),
(4, 38, 3, 2, 1698354444, 0),
(2, 24, 1, 1, 1698354381, 0),
(2, 24, 1, 1, 1698354381, 0),
(4, 38, 3, 2, 1698354444, 0),
(4, 38, 3, 2, 1698354444, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dealership`
--

CREATE TABLE `dealership` (
  `ID` int(11) NOT NULL,
  `owner` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '-',
  `name` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Dealership',
  `price` int(11) NOT NULL DEFAULT 1,
  `type` int(11) NOT NULL DEFAULT 1,
  `locked` int(11) NOT NULL DEFAULT 1,
  `money` int(11) NOT NULL DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 100,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `posa` float NOT NULL DEFAULT 0,
  `pointx` float DEFAULT 0,
  `pointy` float DEFAULT 0,
  `pointz` float DEFAULT 0,
  `restock` tinyint(2) NOT NULL DEFAULT 0,
  `vehprice0` int(11) NOT NULL DEFAULT 0,
  `vehprice1` int(11) NOT NULL DEFAULT 0,
  `vehprice2` int(11) NOT NULL DEFAULT 0,
  `vehprice3` int(11) NOT NULL DEFAULT 0,
  `vehprice4` int(11) NOT NULL DEFAULT 0,
  `vehprice5` int(11) NOT NULL DEFAULT 0,
  `vehprice6` int(11) NOT NULL DEFAULT 0,
  `vehprice7` int(11) NOT NULL DEFAULT 0,
  `vehprice8` int(11) NOT NULL DEFAULT 0,
  `vehprice9` int(11) NOT NULL DEFAULT 0,
  `vehprice10` int(11) NOT NULL DEFAULT 0,
  `vehprice11` int(11) NOT NULL DEFAULT 0,
  `vehprice12` int(11) NOT NULL DEFAULT 0,
  `vehprice13` int(11) NOT NULL DEFAULT 0,
  `vehprice14` int(11) NOT NULL DEFAULT 0,
  `vehprice15` int(11) NOT NULL DEFAULT 0,
  `vehprice16` int(11) NOT NULL DEFAULT 0,
  `vehprice17` int(11) NOT NULL DEFAULT 0,
  `vehprice18` int(11) NOT NULL DEFAULT 0,
  `vehprice19` int(11) NOT NULL DEFAULT 0,
  `vehprice20` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doors`
--

CREATE TABLE `doors` (
  `ID` int(11) NOT NULL,
  `name` varchar(50) DEFAULT 'None',
  `password` varchar(50) DEFAULT '',
  `icon` int(11) DEFAULT 19130,
  `locked` int(11) NOT NULL DEFAULT 0,
  `admin` int(11) NOT NULL DEFAULT 0,
  `vip` int(11) NOT NULL DEFAULT 0,
  `faction` int(11) NOT NULL DEFAULT 0,
  `family` int(11) NOT NULL DEFAULT -1,
  `garage` tinyint(3) NOT NULL DEFAULT 0,
  `custom` int(11) NOT NULL DEFAULT 0,
  `extvw` int(11) DEFAULT 0,
  `extint` int(11) DEFAULT 0,
  `extposx` float DEFAULT 0,
  `extposy` float DEFAULT 0,
  `extposz` float DEFAULT 0,
  `extposa` float DEFAULT 0,
  `intvw` int(11) DEFAULT 0,
  `intint` int(11) NOT NULL DEFAULT 0,
  `intposx` float DEFAULT 0,
  `intposy` float DEFAULT 0,
  `intposz` float DEFAULT 0,
  `intposa` float DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doors`
--

INSERT INTO `doors` (`ID`, `name`, `password`, `icon`, `locked`, `admin`, `vip`, `faction`, `family`, `garage`, `custom`, `extvw`, `extint`, `extposx`, `extposy`, `extposz`, `extposa`, `intvw`, `intint`, `intposx`, `intposy`, `intposz`, `intposa`) VALUES
(0, 'All Saint General Hospital', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1172.86, -1323.27, 15.3997, 268.975, 0, 1, 1439.91, -1759.94, -20.5291, 280.804),
(1, 'Citty Hall Los Santos', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1480.94, -1771.76, 18.8375, 358.819, 0, 1, -1840.79, 2670.5, 3.58844, 89.0403),
(2, 'San Andreas Police Dapartment', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1554.59, -1675.68, 16.1953, 95.8513, 0, 1, 1563.88, 1597.5, 1003.5, 264.163),
(3, 'San Andreas Network', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 649.281, -1360.96, 14.133, 95.8511, 0, 1, 2954.98, -284.459, 2014.49, 241.048),
(4, 'Los Santos Bank', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1462.38, -1010.72, 26.8438, 186.566, 0, 1, 1411.73, 1316.01, 1501.08, 83.7657),
(5, 'Black Market', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1566.74, 18.7645, 24.1641, 95.0958, 0, 5, 318.558, 1115.36, 1083.88, 353.763),
(6, 'Abandoned Building', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 870.392, -25.3991, 63.9469, 156.282, 0, 1, -878.416, 1116.12, 5442.84, 184.086),
(7, 'Auction Los Santos', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1631.82, -1172.56, 24.0843, 5.08727, 0, 13, 1117.56, -1611.99, 789.445, 182.019),
(8, 'Los Santos Driving School', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 2057.73, -1897.77, 13.5538, 186.219, 0, 3, 1494.57, 1304.16, 1093.29, 6.3012),
(9, 'Boat School', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 2944.81, -1472.82, 11.0039, 262.837, 3, 3, -2027.02, -103.981, 1035.17, 182.792),
(10, 'Basement Police Headquarter', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1524.48, -1677.82, 6.21875, 107.37, 0, 1, 1574.31, 1612.94, 997.724, 39.7519),
(11, 'Basement General Hospital', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1144.81, -1326.1, 13.5864, 112.452, 0, 1, 1441.17, -1780, -19.6632, 1.16315),
(12, 'Rooftop General Hospital', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1161.7, -1329.56, 31.4943, 8.44759, 0, 1, 1458.06, -1772.37, -20.5291, 81.3103),
(13, 'Rooftop Police Departement', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1565.33, -1666.74, 28.3956, 147.794, 0, 1, 1575.61, 1614.65, 1003.53, 185.618),
(14, 'News Studio', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 2847.57, -284.151, 2014.48, 299.13, 0, 1, 2964.39, -270.732, 2014.48, 188.867),
(15, 'Basement News Agency', '', 19130, 0, 0, 0, 4, -1, 0, 0, 0, 0, 740.354, -1351.21, 14.7142, 288.652, 0, 1, 2970.63, -270.78, 2014.48, 184.189),
(16, 'Newbie School', '', 19130, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1286.79, -1329.22, 13.5548, 278.296, 0, 5, 1499.12, -1540.01, 15.0255, 182.69);

-- --------------------------------------------------------

--
-- Table structure for table `faction_vehpoint`
--

CREATE TABLE `faction_vehpoint` (
  `id` int(11) NOT NULL,
  `owner` int(11) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0,
  `posx` float DEFAULT 0,
  `posy` float DEFAULT 0,
  `posz` float DEFAULT 0,
  `posa` float DEFAULT 0,
  `world` int(11) NOT NULL DEFAULT 0,
  `interior` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faction_vehpoint`
--

INSERT INTO `faction_vehpoint` (`id`, `owner`, `type`, `posx`, `posy`, `posz`, `posa`, `world`, `interior`) VALUES
(0, 0, 1, 1531.31, -1671.84, 6.21875, 197.674, 0, 0),
(1, 0, 2, 1479.9, -1826.53, 13.5469, 183.652, 0, 0),
(2, 0, 3, 1129.79, -1323.79, 13.7441, 259.972, 0, 0),
(3, 0, 4, 743.277, -1345.81, 13.8414, 355.516, 0, 0),
(4, 0, 3, 1163.72, -1311.34, 31.4905, 9.27297, 0, 0),
(5, 0, 1, 1557.84, -1654.51, 28.3956, 340.022, 0, 0),
(6, 0, 2, 1422.9, -1794.81, 33.4297, 34.1903, 0, 0),
(7, 0, 4, 741.293, -1348.69, 25.2202, 184.882, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `familys`
--

CREATE TABLE `familys` (
  `ID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT 'None',
  `leader` varchar(50) NOT NULL DEFAULT 'None',
  `motd` varchar(100) NOT NULL DEFAULT 'None',
  `color` int(11) DEFAULT 0,
  `extposx` float DEFAULT 0,
  `extposy` float DEFAULT 0,
  `extposz` float DEFAULT 0,
  `extposa` float DEFAULT 0,
  `intposx` float DEFAULT 0,
  `intposy` float DEFAULT 0,
  `intposz` float DEFAULT 0,
  `intposa` float DEFAULT 0,
  `fint` int(11) NOT NULL DEFAULT 0,
  `Weapon1` int(11) NOT NULL DEFAULT 0,
  `Ammo1` int(11) NOT NULL DEFAULT 0,
  `Weapon2` int(11) NOT NULL DEFAULT 0,
  `Ammo2` int(11) NOT NULL DEFAULT 0,
  `Weapon3` int(11) NOT NULL DEFAULT 0,
  `Ammo3` int(11) NOT NULL DEFAULT 0,
  `Weapon4` int(11) NOT NULL DEFAULT 0,
  `Ammo4` int(11) NOT NULL DEFAULT 0,
  `Weapon5` int(11) NOT NULL DEFAULT 0,
  `Ammo5` int(11) NOT NULL DEFAULT 0,
  `Weapon6` int(11) NOT NULL DEFAULT 0,
  `Ammo6` int(11) NOT NULL DEFAULT 0,
  `Weapon7` int(11) NOT NULL DEFAULT 0,
  `Ammo7` int(11) NOT NULL DEFAULT 0,
  `Weapon8` int(11) NOT NULL DEFAULT 0,
  `Ammo8` int(11) NOT NULL DEFAULT 0,
  `Weapon9` int(11) NOT NULL DEFAULT 0,
  `Ammo9` int(11) NOT NULL DEFAULT 0,
  `Weapon10` int(11) NOT NULL DEFAULT 0,
  `Ammo10` int(11) NOT NULL DEFAULT 0,
  `safex` float DEFAULT 0,
  `safey` float DEFAULT 0,
  `safez` float DEFAULT 0,
  `money` int(11) NOT NULL DEFAULT 0,
  `marijuana` int(11) NOT NULL DEFAULT 0,
  `component` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 0,
  `vehiclemodel` varchar(52) NOT NULL DEFAULT '0|0|0|0|0',
  `vehiclefuel` varchar(52) NOT NULL DEFAULT '0|0|0|0|0',
  `vehiclehealth` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00',
  `vehiclepos1` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00',
  `vehiclepos2` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00',
  `vehiclepos3` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00',
  `vehiclepos4` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00',
  `vehiclepos5` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `fishingarea`
--

CREATE TABLE `fishingarea` (
  `ID` int(11) NOT NULL,
  `PosX` float NOT NULL,
  `PosY` float NOT NULL,
  `PosZ` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fishingarea`
--

INSERT INTO `fishingarea` (`ID`, `PosX`, `PosY`, `PosZ`) VALUES
(0, 329.314, -2071.55, -0.08103),
(1, -16.2773, -2234.29, -0.664652),
(2, 283.355, -2332.83, 0.085421),
(3, 640.196, -2212.26, -0.3714);

-- --------------------------------------------------------

--
-- Table structure for table `flat`
--

CREATE TABLE `flat` (
  `ID` int(11) NOT NULL,
  `Name` varchar(32) DEFAULT NULL,
  `Type` int(11) NOT NULL DEFAULT 0,
  `World` int(11) NOT NULL DEFAULT 0,
  `Interior` int(11) NOT NULL DEFAULT 0,
  `IntWorld` int(11) NOT NULL DEFAULT 0,
  `IntInterior` int(11) NOT NULL DEFAULT 0,
  `Position` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00',
  `IntPosition` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00',
  `GaragePos` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flatroom`
--

CREATE TABLE `flatroom` (
  `ID` int(11) NOT NULL,
  `FlatID` int(11) NOT NULL DEFAULT 0,
  `Owner` int(11) NOT NULL DEFAULT 0,
  `Locked` int(11) NOT NULL DEFAULT 0,
  `Price` int(11) NOT NULL DEFAULT 0,
  `World` int(11) NOT NULL DEFAULT 0,
  `Interior` int(11) NOT NULL DEFAULT 0,
  `Seal` int(11) NOT NULL DEFAULT 0,
  `Money` int(11) NOT NULL DEFAULT 0,
  `Position` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00',
  `AreaPos` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00',
  `DoorPosition` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00',
  `DoorRotation` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00',
  `LastVisited` int(11) NOT NULL DEFAULT 0,
  `Builder` varchar(24) NOT NULL DEFAULT '0|0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flat_furniture`
--

CREATE TABLE `flat_furniture` (
  `ID` int(11) NOT NULL,
  `Flatid` int(11) NOT NULL DEFAULT 0,
  `Model` int(11) NOT NULL DEFAULT 0,
  `Name` int(11) NOT NULL DEFAULT 0,
  `Unused` int(11) NOT NULL DEFAULT 0,
  `Position` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00',
  `Rotation` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00',
  `Materials` varchar(128) NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flat_storage`
--

CREATE TABLE `flat_storage` (
  `ID` int(11) NOT NULL DEFAULT 0,
  `itemID` int(11) NOT NULL,
  `itemName` varchar(32) DEFAULT NULL,
  `itemModel` int(11) NOT NULL DEFAULT 0,
  `itemQuantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flat_structure`
--

CREATE TABLE `flat_structure` (
  `ID` int(11) NOT NULL,
  `Static` int(11) NOT NULL DEFAULT 0,
  `Flatid` int(11) NOT NULL DEFAULT 0,
  `Model` int(11) NOT NULL DEFAULT 0,
  `Position` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00	',
  `Rotation` varchar(128) NOT NULL DEFAULT '0.00|0.00|0.00	',
  `Material` varchar(128) NOT NULL DEFAULT '0|0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flat_weapon`
--

CREATE TABLE `flat_weapon` (
  `id` int(10) UNSIGNED NOT NULL,
  `flatroomid` int(10) UNSIGNED NOT NULL,
  `weaponid` tinyint(3) UNSIGNED NOT NULL,
  `ammo` int(10) UNSIGNED NOT NULL,
  `durability` int(10) UNSIGNED NOT NULL,
  `typeammo` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `furniture`
--

CREATE TABLE `furniture` (
  `ID` int(11) NOT NULL DEFAULT 0,
  `furnitureID` int(11) NOT NULL,
  `furnitureName` varchar(32) DEFAULT NULL,
  `furnitureModel` int(11) NOT NULL DEFAULT 0,
  `furnitureX` float NOT NULL DEFAULT 0,
  `furnitureY` float NOT NULL DEFAULT 0,
  `furnitureZ` float NOT NULL DEFAULT 0,
  `furnitureRX` float NOT NULL DEFAULT 0,
  `furnitureRY` float NOT NULL DEFAULT 0,
  `furnitureRZ` float NOT NULL DEFAULT 0,
  `furnitureType` int(11) NOT NULL DEFAULT 0,
  `furnitureUnused` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `furnitureStatus` int(10) UNSIGNED NOT NULL,
  `furnitureMaterials` varchar(128) NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `furniture`
--

INSERT INTO `furniture` (`ID`, `furnitureID`, `furnitureName`, `furnitureModel`, `furnitureX`, `furnitureY`, `furnitureZ`, `furnitureRX`, `furnitureRY`, `furnitureRZ`, `furnitureType`, `furnitureUnused`, `furnitureStatus`, `furnitureMaterials`) VALUES
(61, 14, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(61, 15, '{8B4513}[SYN] Desk', 2184, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(61, 16, '{8B4513}[SYN] Office Chair', 19999, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(61, 17, '{8B4513}[SYN] White Chair', 2123, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(61, 18, '{8B4513}[SYN] Round Table', 2030, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(61, 19, '{8B4513}[SYN] Tiger Skin', 1828, 350.459, 1667.07, 1001.22, 0, -1.8, 86.9918, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 94, 'Sofa Modern', 1703, 421.606, 610.195, 999.221, 0, 0, -88.8908, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 95, 'Lampu Panjang', 2069, 339.576, 1789.77, 1001.27, 0, 0, 172.668, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 97, 'Picture 2', 2255, 346.033, 1789.73, 1003.07, 0, 0, 178.256, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 98, 'Komik Doujin', 2827, 342.866, 1789.57, 1001.67, 0, 0, 173.678, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 100, 'Picture 3', 19174, 344.532, 1731.07, 1003.28, 0, 0, 90.303, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 101, 'Moose Head', 1736, 343.668, 1795.63, 1003.57, 0, 0, -88.5126, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 103, 'Lampu Tidur', 2106, 347.961, 1741.95, 1001.69, 0, 0, 358.662, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 104, 'PlayStation', 2028, 342.155, 1789.61, 1001.67, 0, 0, -179.173, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 115, '{8B4513}[SYN] Desk', 2184, 4582.45, -2533.22, 5.297, 0, 0, 59.6607, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 118, '{8B4513}[SYN] Desk', 2184, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 120, '{8B4513}[SYN] Office Chair', 19999, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 123, '{8B4513}[SYN] Round Table', 2030, 4582.13, -2534.87, 5.297, 0, 0, 134.548, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 124, '{8B4513}[SYN] White Chair', 2123, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 125, '{8B4513}[SYN] Tiger Skin', 1828, 4584.39, -2532.74, 4.2797, 0, 0, 262.288, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 126, '{8B4513}[SYN] Plate', 2820, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 127, '{8B4513}[SYN] Kitchen 2', 2151, 0, 0, 0, 0, 0, 0, 0, 1, 0, '455|463|455|463|463|463|463|463|0|0|0|0|0|0|0|0'),
(49, 128, '{8B4513}[SYN] Kitchen Faucet', 2160, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|463|463|455|455|455|455|0|0|0|0|0|0|0|0|0'),
(92, 129, '{8B4513}[SYN] Modern Bed Set', 2575, 4588.57, -2534.25, 3.7397, 0, 0, 80.4418, 0, 0, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 130, '{8B4513}[SYN] Kitchen Stove', 2135, 0, 0, 0, 0, 0, 0, 0, 1, 0, '97|463|455|463|463|463|0|0|0|0|0|0|0|0|0|0'),
(49, 131, '{8B4513}[SYN] Fridge', 2147, 0, 0, 0, 0, 0, 0, 0, 1, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(92, 132, '{8B4513}[SYN] Roundless Bed', 1797, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|8702|8704|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 133, 'Wine rak', 1742, 0, 0, 0, 0, 0, 0, 0, 1, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 134, '{8B4513}[SYN] Trash Bin', 11706, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 135, '{8B4513}[SYN] Darktone Cabinet', 2576, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 136, '{8B4513}[SYN] Microwave', 2149, 0, 0, 0, 0, 0, 0, 0, 1, 0, '5708|5708|5708|5708|5708|5708|5|0|0|0|0|0|0|0|0|0'),
(49, 137, '{8B4513}[SYN] Potrait 7', 2272, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|528|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 138, '{8B4513}[SYN] Potrait 5', 2284, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 139, '{8B4513}[SYN] Potrait 4', 2263, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 140, '{8B4513}[SYN] Potrait 2', 2269, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 141, '{8B4513}[SYN] Potrait 1', 19173, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 142, '{8B4513}[SYN] Long Mirror', 2815, 4580.23, -2532.96, 5.7428, 90.0999, -19.5, 105.335, 0, 0, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 143, '{8B4513}[SYN] Long Mirror', 2815, 4584.33, -2542.51, 5.3267, 89.9, -5.1999, -95.0576, 0, 0, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 144, '{8B4513}[SYN] Long Mirror', 2815, 0, 0, 0, 0, 0, 0, 0, 1, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 145, '{8B4513}[SYN] Big Map', 19174, 0, 0, 0, 0, 0, 0, 0, 1, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 146, '{8B4513}[SYN] Grey Round Table', 2315, 4584.59, -2538.36, 4.2397, 0, 0, 80.9818, 0, 0, 0, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 147, '{FFFFFF}Banteng PDIP', 1736, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 148, '{8B4513}[SYN] Satin Long Sofa', 1713, 4582.94, -2526.94, 4.2697, 0, 0, -9.7684, 0, 1, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 149, '{8B4513}[SYN] Desk', 2184, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 150, '{8B4513}[SYN] Satin Long Sofa', 1713, 4580.78, -2533.17, 4.257, 0, 0, 83.4476, 0, 0, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 151, '{8B4513}[SYN] Single Satin Sofa', 1708, 4585.53, -2527.88, 4.2396, 0, 0, -97.9618, 0, 1, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 152, '{8B4513}[SYN] Office Chair', 19999, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 153, '{8B4513}[SYN] White Chair', 2123, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 154, '{8B4513}[SYN] Classic Table', 2311, 4582.34, -2533.22, 4.287, 0, 0, 83.327, 0, 0, 0, '1868|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 155, '{8B4513}[SYN] Round Table', 2030, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 156, '{8B4513}[SYN] Tiger Skin', 1828, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 157, '{8B4513}[SYN] Tiger Skin', 1828, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 158, '{8B4513}[SYN] Abstract Carpet', 2631, 0, 0, 0, 0, 0, 0, 0, 1, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 159, '{8B4513}[SYN] Modern Bed Set', 2575, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 160, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 4585.97, -2533.33, 6.077, 0, 0, -99.3261, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 161, '{8B4513}[SYN] Darktone Cabinet', 2576, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 162, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 4584.68, -2540.52, 6.0897, 0, 0, -100.778, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 163, '{8B4513}[SYN] \" I \" Speaker', 2229, 4586.19, -2532.11, 4.3097, 0, 0, -100.478, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 164, '{8B4513}[SYN] Light Wood Rack', 2067, 0, 0, 0, 0, 0, 0, 0, 1, 0, '229|455|455|455|455|455|0|0|0|0|0|0|0|0|0|0'),
(92, 165, '{8B4513}[SYN] White Toilet', 2514, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 166, '{8B4513}[SYN] Wood Stand Lamp', 2108, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|1310|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 167, '{8B4513}[SYN] Towel Hanging', 11707, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 168, '{8B4513}[SYN] Wood Frame Lamp', 2069, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 169, '{8B4513}[SYN] Long Mirror', 2815, 0, 0, 0, 0, 0, 0, 0, 1, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 170, '{8B4513}[SYN] White Bathtub', 2516, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(49, 171, '{8B4513}[SYN] Square Mirror', 11737, 0, 0, 0, 0, 0, 0, 0, 1, 0, '220|5266|0|0|0|0|0|0|8273|0|42|0|0|0|0|0'),
(92, 172, '{8B4513}[SYN] White Shower', 2517, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 173, '{8B4513}[SYN] Stand White Sink', 2523, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 174, '{8B4513}[SYN] White Marble Sink', 2518, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 175, '{8B4513}[SYN] Big White Safe', 2332, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 176, '{FFFFFF}Banteng PDIP', 1736, 4585.5, -2527.25, 5.4297, 0, 0, -100.17, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 177, '{8B4513}[SYN] Water Cooler', 1808, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 178, '{8B4513}[SYN] Big Map', 19174, 0, 0, 0, 0, 0, 0, 0, 1, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 179, '{8B4513}[SYN] Potrait 1', 19173, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 180, '{8B4513}[SYN] Potrait 2', 2269, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 181, '{8B4513}[SYN] Potrait 2', 2269, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 182, '{8B4513}[SYN] Potrait 4', 2263, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 183, '{8B4513}[SYN] Potrait 5', 2284, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 184, '{8B4513}[SYN] Potrait 7', 2272, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|528|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 185, '{8B4513}[SYN] Microwave', 2149, 0, 0, 0, 0, 0, 0, 0, 1, 0, '5708|5708|5708|5708|5708|5708|5|0|0|0|0|0|0|0|0|0'),
(92, 186, '{8B4513}[SYN] Trash Bin', 11706, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 187, '{8B4513}[SYN] Trash Bin', 11706, 4577.85, -2526.34, 4.297, 0, 0, 83.7149, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 188, '{8B4513}[SYN] Plate', 2820, 4585.03, -2536.71, 4.7297, 0, 0, 260.721, 0, 0, 0, '463|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 189, '{8B4513}[SYN] Plate', 2820, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 190, '{8B4513}[SYN] Plate', 2820, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 191, '{8B4513}[SYN] Kitchen 2', 2151, 0, 0, 0, 0, 0, 0, 0, 1, 0, '455|463|455|463|463|463|463|463|0|0|0|0|0|0|0|0'),
(92, 192, '{8B4513}[SYN] Kitchen Faucet', 2160, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|463|463|455|455|455|455|0|0|0|0|0|0|0|0|0'),
(92, 193, '{8B4513}[SYN] Kitchen Stove', 2135, 0, 0, 0, 0, 0, 0, 0, 1, 0, '97|463|455|463|463|463|0|0|0|0|0|0|0|0|0|0'),
(92, 194, '{8B4513}[SYN] Fridge', 2147, 0, 0, 0, 0, 0, 0, 0, 1, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(92, 195, 'Wine rak', 1742, 4581.06, -2534.72, 4.2897, 0, 0, 170.88, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 196, 'Wine rak', 1742, 4585.31, -2537.85, 4.7297, 0, 0, -101.345, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 197, 'Wine rak', 1742, 4581.15, -2534.99, 4.2697, 0, 0, 165.735, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 198, '{8B4513}[SYN] Office Chair', 19999, 426.174, 609.694, 999.241, 0, 0, 90.4896, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 199, '{8B4513}[SYN] Desk', 2184, 427.437, 608.699, 999.221, 0, 0, 89.066, 0, 0, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 200, '{8B4513}[SYN] White Chair', 2123, 428.104, 607.823, 1000.22, 0, 0, 171.833, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 201, '{8B4513}[SYN] Round Table', 2030, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 202, '{8B4513}[SYN] Modern Bed Set', 2575, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 203, '{8B4513}[SYN] Air Conditioner', 2230, 428.752, 605.255, 1002.2, 24, 89.7998, -178.734, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(5, 204, '{8B4513}[SYN] Single Satin Sofa', 1708, 427.71, 605.987, 999.181, 0, 0, -179.802, 0, 0, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 205, '{8B4513}[SYN] Satin Long Sofa', 1713, 430.552, 606.001, 999.171, 0, 0, 179.933, 0, 0, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 206, '{8B4513}[SYN] Classic Table', 2311, 431.097, 609.747, 999.201, 0, 0, -90.1455, 0, 0, 0, '1868|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 207, '{8B4513}[SYN] Abstract Carpet', 2631, 0, 0, 0, 0, 0, 0, 0, 1, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 208, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 431.676, 608.99, 1001.43, 0, 0, -89.7176, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 209, '{8B4513}[SYN] \" I \" Speaker', 2229, 431.937, 618.357, 999.231, 0, 0, 330.401, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 210, 'Wine rak', 1742, 0, 0, 0, 0, 0, 0, 0, 1, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 211, '{8B4513}[SYN] Kitchen Faucet', 2160, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|463|463|455|455|455|455|0|0|0|0|0|0|0|0|0'),
(5, 212, '{8B4513}[SYN] Kitchen 2', 2151, 0, 0, 0, 0, 0, 0, 0, 1, 0, '455|463|455|463|463|463|463|463|0|0|0|0|0|0|0|0'),
(5, 213, '{8B4513}[SYN] Desk', 2184, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 214, '{8B4513}[SYN] Office Chair', 19999, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 215, '{8B4513}[SYN] Round Table', 2030, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 216, '{8B4513}[SYN] White Chair', 2123, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 217, '{8B4513}[SYN] Modern Bed Set', 2575, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 218, '{8B4513}[SYN] Air Conditioner', 2230, 428.514, 618.594, 1002.08, 0, 89.7998, 1.8149, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(5, 219, '{8B4513}[SYN] Air Conditioner', 2230, 0, 0, 0, 0, 0, 0, 0, 1, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(5, 220, '{8B4513}[SYN] Air Conditioner', 2230, 0, 0, 0, 0, 0, 0, 0, 1, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(5, 221, '{8B4513}[SYN] Darktone Cabinet', 2576, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 222, '{8B4513}[SYN] Darktone Cabinet', 2576, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 223, '{8B4513}[SYN] Light Wood Rack', 2067, 0, 0, 0, 0, 0, 0, 0, 1, 0, '229|455|455|455|455|455|0|0|0|0|0|0|0|0|0|0'),
(5, 224, '{8B4513}[SYN] Light Wood Rack', 2067, 0, 0, 0, 0, 0, 0, 0, 1, 0, '229|455|455|455|455|455|0|0|0|0|0|0|0|0|0|0'),
(5, 225, '{8B4513}[SYN] Wood Stand Lamp', 2108, 425.911, 608.042, 999.181, 0, 0, 267.441, 0, 0, 0, '463|1067|1310|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 226, '{8B4513}[SYN] Wood Frame Lamp', 2069, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 227, '{8B4513}[SYN] Grey Round Table', 2315, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 228, '{8B4513}[SYN] Grey Round Table', 2315, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 229, '{8B4513}[SYN] Satin Long Sofa', 1713, 0, 0, 0, 0, 0, 0, 0, 1, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 230, '{8B4513}[SYN] Satin Long Sofa', 1713, 0, 0, 0, 0, 0, 0, 0, 1, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 231, '{8B4513}[SYN] Single Satin Sofa', 1708, 0, 0, 0, 0, 0, 0, 0, 1, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 232, '{8B4513}[SYN] Single Satin Sofa', 1708, 0, 0, 0, 0, 0, 0, 0, 1, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 233, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 234, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 235, '{8B4513}[SYN] \" I \" Speaker', 2229, 431.958, 618.324, 1000.55, 0, 0, -34.1922, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 236, '{8B4513}[SYN] \" I \" Speaker', 2229, 431.965, 618.375, 1001.26, 0, 0, 328.563, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 237, '{8B4513}[SYN] \" I \" Speaker', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 238, '{8B4513}[SYN] \" I \" Speaker', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 239, '{8B4513}[SYN] Big White Safe', 2332, 426.063, 607.398, 999.651, 0, 0, 90.3955, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 240, '{8B4513}[SYN] Big Map', 19174, 425.63, 607.272, 1001.22, 0, 0, 90.4228, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 241, '{8B4513}[SYN] Potrait 1', 19173, 425.591, 612.777, 1001.77, 0, 0, 90.5317, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 242, '{8B4513}[SYN] Potrait 2', 2269, 426.083, 611.116, 1001.47, 0, 0, 90.072, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 243, '{8B4513}[SYN] Potrait 4', 2263, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 244, '{8B4513}[SYN] Potrait 5', 2284, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 245, '{8B4513}[SYN] Potrait 7', 2272, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|528|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 246, '{8B4513}[SYN] Trash Bin', 11706, 426.962, 617.915, 999.301, 0, 0, 68.9617, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(5, 247, '{8B4513}[SYN] Kitchen 2', 2151, 0, 0, 0, 0, 0, 0, 0, 1, 0, '455|463|455|463|463|463|463|463|0|0|0|0|0|0|0|0'),
(5, 248, '{8B4513}[SYN] Kitchen Faucet', 2160, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|463|463|455|455|455|455|0|0|0|0|0|0|0|0|0'),
(5, 249, 'Wine rak', 1742, 0, 0, 0, 0, 0, 0, 0, 1, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 250, 'Tumpukan celana', 2819, 346.548, 1791.16, 1001.67, 0, 0, 163.564, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 251, 'Tumpukan Baju', 2819, 346.677, 1791.13, 1001.67, 0, 0, -175.969, 0, 0, 0, '4220|455|4220|4220|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 252, 'Lampu Tidur', 2106, 344.582, 1789.58, 1001.67, 0, 0, 165.921, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 253, 'Keset', 11737, 338.332, 1794.9, 1001.17, 0, 0, -92.572, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 254, 'Picture 1', 2257, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 255, 'Speaker 1', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 256, 'Kulit Macan', 1828, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 257, 'Foto Kenangan', 2828, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 258, 'Picture 4', 19173, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 259, 'Picture 2', 2255, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 260, 'Bola Basket', 2114, 4580.87, -2530.72, 4.3685, 0, 0, 72.7482, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 261, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 262, 'BoomBox', 2226, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 263, 'Lemari Kayu', 2025, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 264, 'Long Table', 2357, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 265, 'Tabble Modern', 2311, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 266, 'Kursi makan', 2120, 4583.81, -2536.24, 4.8997, 0, 0, -55.8051, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 267, 'Kursi makan', 2120, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 268, 'Kursi makan', 2120, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 269, 'Keset', 11737, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(92, 270, 'Picture 3', 19174, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 271, 'Picture 2', 2255, 346.468, 1741.93, 1003.11, 0, 0, 0.0046, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 272, 'Tempat Sampah', 11706, 343.86, 1728.62, 1001.14, 0, 0, -89.7449, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 273, 'Kulit Macan', 1828, 344.677, 1744.15, 1001.09, 0, 0, 178.81, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 274, 'Moose Head', 1736, 421.035, 617.968, 1002.28, 0, 0, 357.703, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 275, 'Moose Head', 1736, 431.099, 612.682, 1002.14, 18.5, 0.1, 266.522, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 332, 'Lampu Panjang', 2069, 423.96, 619.264, 1000.22, 0, 0, 181.404, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 333, 'Bed Set 2', 2298, 345.184, 1738.45, 1001.21, 0, 0, 0.1641, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 334, 'Tempat Sampah', 11706, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 335, 'Picture 3', 19174, 344.296, 1730.39, 1003.19, 0, 0, -90.6193, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 336, 'Wine rak', 1742, 346.676, 1795.58, 1001.94, 0, 0, -179.923, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 337, '{8B4513}[SYN] Fridge', 2147, 344.99, 1796.2, 1001.17, 0, 0, -174.476, 0, 0, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(37, 338, '{8B4513}[SYN] Big Map', 19174, 337.703, 1791.74, 1002.49, 0, 0, 90.1349, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 340, '{8B4513}[SYN] Air Conditioner', 2230, 337.531, 1792.42, 1004.17, 0, -89.9999, 88.6343, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(37, 342, 'Lemari Kayu', 2025, 346.281, 1795, 1001.25, 0, 0, -0.6016, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 344, 'Speaker 1', 2229, 340.551, 1789.29, 1001.17, 0, 0, 178.832, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 345, 'Speaker 1', 2229, 343.266, 1789.26, 1001.17, 0, 0, 178.295, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 346, 'Tempat Sampah', 11706, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 347, 'Kursi makan', 2120, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 348, 'Tempat Sampah', 11706, 344.513, 1798.36, 1001.16, 0, 0, 4.4144, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 349, 'Wine rak', 1742, 344.724, 1795.63, 1001.37, 0, 0, -0.8568, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 350, 'Wine rak', 1742, 0, 0, 0, 0, 0, 0, 0, 1, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 351, '{8B4513}[SYN] Fridge', 2147, 0, 0, 0, 0, 0, 0, 0, 1, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(94, 352, '{8B4513}[SYN] Modern Bed Set', 2575, 422.507, 625.192, 999.651, 0, 0, 0.6394, 0, 0, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 353, '{8B4513}[SYN] Big Map', 19174, 0, 0, 0, 0, 0, 0, 0, 1, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 354, '{8B4513}[SYN] Wood Frame Lamp', 2069, 343.845, 1728.6, 1001.15, 0, 0, 271.285, 0, 1, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 355, 'Wine rak', 1742, 341.128, 1729.39, 1002.84, 0, 0, -179.951, 0, 1, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 356, 'Wine rak', 1742, 342.904, 1728.03, 1001.13, 0, 0, 180.617, 0, 1, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 357, '{8B4513}[SYN] Air Conditioner', 2230, 340.19, 1790.95, 1002.17, 0, 0, 88.0825, 0, 1, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(94, 358, '{8B4513}[SYN] Potrait 5', 2284, 423.947, 627.318, 1001.27, 0, 0, 359.98, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 359, '{8B4513}[SYN] Potrait 4', 2263, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 360, '{8B4513}[SYN] Potrait 2', 2269, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 361, '{8B4513}[SYN] Potrait 7', 2272, 424.13, 619.053, 1001.3, 0, 0, 179.739, 0, 0, 0, '463|528|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(37, 362, 'Wine rak', 1742, 0, 0, 0, 0, 0, 0, 0, 1, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 363, '{8B4513}[SYN] Wood Frame Lamp', 2069, 418.559, 611.531, 999.302, 0, 0, 133.722, 0, 0, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 364, '{8B4513}[SYN] Square Mirror', 11737, 0, 0, 0, 0, 0, 0, 0, 1, 0, '220|5266|0|0|0|0|0|0|8273|0|42|0|0|0|0|0'),
(94, 365, '{8B4513}[SYN] Wood Stand Lamp', 2108, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|1310|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 366, '{8B4513}[SYN] Darktone Cabinet', 2576, 426.543, 618.932, 999.261, 0, 0, 178.803, 0, 0, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 367, '{8B4513}[SYN] Wood Frame Lamp', 2069, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 368, 'RADIO', 2103, 424.13, 618.853, 1000.4, 0, 0, 179.07, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 369, '{8B4513}[SYN] Air Conditioner', 2230, 0, 0, 0, 0, 0, 0, 0, 1, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(94, 370, '{8B4513}[SYN] Wood Frame Lamp', 2069, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 371, '{8B4513}[SYN] Long Mirror', 2815, 0, 0, 0, 0, 0, 0, 0, 1, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 372, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 373, 'Sofa Modern', 1703, 418.421, 608.031, 999.232, 0, 0, 90.9523, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 374, 'Small Sofa Modern', 1724, 419.491, 611.557, 999.172, 0, 0, 0.7448, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 375, 'Tabble Modern', 2311, 420.04, 608.396, 999.281, 0, 0, 91.1198, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 376, 'TV 18\"Inch', 19786, 419.983, 605.506, 1001.61, 0, 0, 179.84, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 377, 'TV 18\"Inch', 19786, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 378, 'Lemari Baju', 2066, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(94, 379, 'Bed Set 1', 2566, 422.762, 623.564, 1000.22, 0, 0, 176.563, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 381, 'Speaker 1', 2229, 340.444, 1789.27, 1001.17, 0, 0, 163.075, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 383, 'Lampu Tidur', 2106, 344.591, 1789.59, 1001.67, 0, 0, 100.497, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 384, 'Picture 3', 19174, 347.833, 1792.51, 1003.57, 0, 0, -87.9062, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 385, 'Karpet Kotak\"', 2818, 338.244, 1795.07, 1001.27, 0, 0, -88.708, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 386, 'Karpet Kotak\"', 2818, 346.483, 1793.5, 1001.17, 0, 0, 3.1433, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 388, 'Small Sofa Modern', 1724, 347.102, 1792.95, 1001.17, 0, 0, -177.612, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 389, 'Dispenser', 2002, 338.036, 1789.82, 1001.17, 0, 0, -173.163, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 390, 'Lemari Baju', 2066, 347.43, 1790.34, 1001.17, 0, 0, -88.9607, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 391, 'BoomBox', 2226, 347.735, 1790.26, 1002.57, 0, 0, -93.079, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 392, 'Speaker 1', 2229, 343.26, 1789.37, 1001.37, 0, 0, -160.764, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 394, 'TV 12\"Inch', 19787, 346.686, 1795.48, 1002.67, 0, 0, 1.8432, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 395, 'Lemari Baju', 2066, 347.361, 1790.94, 1001.17, 0, 0, -88.3816, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 396, 'Tabble Modern', 2311, 346.126, 1795.03, 1001.17, 0, 0, 1.787, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 397, 'Moose Head', 1736, 346.085, 1789.64, 1003.87, 0, 0, -175.924, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 398, 'Komik Doujin', 2827, 346.209, 1794.81, 1001.27, 0, 0, -18.0111, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 399, 'Tempat Sampah', 11706, 344.497, 1795.36, 1001.17, 0, 0, -178.891, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(36, 400, 'PlayStation', 2028, 346.818, 1794.91, 1001.77, 0, 0, 173.177, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 401, 'Picture 2', 2255, 1284.66, -624.606, 1004.48, 0, 0, -93.233, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 402, 'Bola Basket', 2114, 1279.02, -623.774, 1004.48, 0, 0, 124.513, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 403, 'BoomBox', 2226, 1278.86, -624.902, 1004.78, 0, 0, 107.414, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 404, 'TV 18\"Inch', 19786, 1285.2, -626.844, 1004.98, 0, 0, -86.297, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 405, 'TV 18\"Inch', 19786, 1258.55, -617.167, 1003.36, 180, 0, -88.3946, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 406, 'PlayStation', 2028, 1284.78, -626.776, 1003.88, 0, 0, -104.068, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 407, 'Speaker 1', 2229, 1285.15, -625.68, 1003.28, 0, 0, -93.6602, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 408, 'Speaker 1', 2229, 1285.1, -628.604, 1003.28, 0, 0, -90.2299, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 409, 'Picture 3', 19174, 1278.63, -620.06, 1004.78, 0, 0, 88.3728, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 410, 'Picture 4', 19173, 1282.23, -615.937, 1004.98, 0, 0, 4.7831, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 411, 'Tabble Modern', 2311, 1284.71, -626.066, 1003.28, 0, 0, -85.6396, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 412, 'Small Sofa Modern', 1724, 1282.95, -627.381, 1003.18, 0, 0, 93.5827, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 413, 'Lampu Panjang', 2069, 1278.97, -625.765, 1003.38, 0, 0, 94.4879, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 414, 'Kulit Macan', 1828, 1281.67, -619.841, 1003.28, 0, 0, 85.517, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 446, '{8B4513}[SYN] Desk', 2184, 417.128, 625.202, 999.222, 0, 0, -0.2238, 0, 0, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 447, '{8B4513}[SYN] Office Chair', 19999, 418.053, 627.295, 999.202, 0, 0, -1.6991, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 448, '{8B4513}[SYN] Modern Bed Set', 2575, 423.278, 625.33, 999.622, 0, 0, 0.4456, 0, 0, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 449, '{8B4513}[SYN] Air Conditioner', 2230, 422.197, 627.915, 1002.29, -178.8, 90.4, -178.673, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(35, 450, '{8B4513}[SYN] Darktone Cabinet', 2576, 425.949, 621.564, 999.192, 0, 0, -89.743, 0, 0, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 451, '{8B4513}[SYN] Wood Stand Lamp', 2108, 422.636, 627.535, 999.242, 0, 0, -84.5854, 0, 0, 0, '463|1067|1310|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 452, '{8B4513}[SYN] Long Mirror', 2815, 426.405, 622.58, 1000.21, 0.5, -89.7999, -1.9945, 0, 0, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 453, '{8B4513}[SYN] Long Soft Sofa', 1753, 424.561, 606.356, 999.222, 0, 0, 177.704, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(35, 454, '{8B4513}[SYN] Classic Table', 2311, 424.27, 607.727, 999.222, 0, 0, -178.327, 0, 0, 0, '1868|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 455, '{8B4513}[SYN] Satin Long Sofa', 1713, 426.797, 617.589, 999.222, 0, 0, -0.9309, 0, 0, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 456, '{8B4513}[SYN] Unrest Soft Sofa', 2293, 421.549, 607.635, 999.222, 0, 0, 90.2575, 0, 0, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 457, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 431.694, 608.573, 1001.22, 0, 0, -89.5319, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 458, '{8B4513}[SYN] \" I \" Speaker', 2229, 431.694, 606.873, 999.122, 0, 0, -89.5319, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 459, '{8B4513}[SYN] White Bathtub', 2516, 417.205, 609.763, 999.201, 0, 0, -177.54, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(97, 464, '{8B4513}[SYN] Big Map', 19174, 337.176, 1848.86, 1002.89, 0, 0, 86.9978, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 465, '{8B4513}[SYN] Big Map', 19174, 1248.29, -608.948, 1003.49, 0, 0, 86.406, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(97, 466, 'Wine rak', 1742, 341.371, 1852.3, 1001.59, 0, 0, -2.1742, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 467, 'Wine rak', 1742, 1278.65, -627.713, 1003.38, 0, 0, 93.3752, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 468, '{8B4513}[SYN] Microwave', 2149, 1268.28, -626.968, 1001.29, 0, 0, -86.1124, 0, 0, 0, '5708|5708|5708|5708|5708|5708|5|0|0|0|0|0|0|0|0|0'),
(97, 469, '{8B4513}[SYN] Air Conditioner', 2230, 344.435, 1849.4, 1003.59, 0, 89.9999, -87.8476, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(103, 470, '{8B4513}[SYN] Air Conditioner', 2230, 1282.68, -629.163, 1005.18, 0, 89.9999, 175.915, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(103, 471, '{8B4513}[SYN] Fridge', 2147, 1268.29, -624.842, 1001.09, 0, 0, -86.9721, 0, 0, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(103, 472, '{8B4513}[SYN] Plate', 2820, 1268.38, -629.368, 1001.19, 0, 0, -86.1124, 0, 0, 0, '463|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(103, 473, '{8B4513}[SYN] Water Cooler', 1808, 1268.23, -623.836, 1001.09, 0, 0, -82.2821, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 491, '{8B4513}[SYN] Modern Bed Set', 2575, 419.197, 624.646, 999.622, 0, 0, 89.8148, 0, 0, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 492, '{8B4513}[SYN] Darktone Cabinet', 2576, 417.234, 618.25, 999.212, 0, 0, 91.6482, 0, 0, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 493, '{8B4513}[SYN] Wood Frame Lamp', 2069, 422.074, 618.779, 999.301, 0, 0, 183.249, 0, 0, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 494, '{8B4513}[SYN] Wood Frame Lamp', 2069, 420.058, 618.67, 999.281, 0, 0, 178.676, 0, 0, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 497, '{8B4513}[SYN] Unrest Soft Sofa', 2293, 423.391, 607.453, 999.222, 0, 0, 90.3177, 0, 0, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 498, '{8B4513}[SYN] Long Soft Sofa', 1753, 421.829, 623.821, 999.144, -0.6, 0.0999, 89.6857, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(105, 499, '{8B4513}[SYN] Marble Carpet', 2632, 424.24, 624.493, 999.192, 0, 0, 1.6142, 0, 0, 0, '4670|4118|4118|4118|4118|4118|4|0|0|0|0|0|0|0|0|0'),
(105, 500, '{8B4513}[SYN] Grey Round Table', 2315, 423.586, 625.581, 999.194, 0, 0, 270.591, 0, 0, 0, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 501, 'Kitchen Set Besar', 14720, 413.065, 617.84, 999.2, 0, 0, -89.8668, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 502, 'Lemari Kayu', 2025, 417.163, 622.002, 999.211, 0, 0, 89.6331, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 503, 'Meja Kerja', 2184, 425.987, 622.246, 999.242, 0, 0, -156, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 504, 'Computer', 2190, 426.022, 621.868, 999.992, 0.6999, 0, -11.1074, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 505, 'Kursi Kerja', 19999, 425.8, 619.584, 999.221, 0, 0, -153.338, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 506, 'PlayStation', 2028, 425.045, 621.557, 1000.08, 0, 0, 33.6559, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 507, 'Picture 1', 2257, 416.729, 626.13, 1001.47, 0, 0, 89.537, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 508, 'Kulit Macan', 1828, 420.987, 620.563, 999.232, 0, 0, -91.9381, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 509, 'Moose Head', 1736, 426.143, 625.079, 1002.16, 0, 0, 269.809, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 510, 'TV 18\"Inch', 19786, 426.485, 625.058, 1000.93, 0, 0, -89.9488, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 511, 'Speaker 1', 2229, 426.379, 626.111, 1000.28, 0, 0, 271.555, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 512, 'Speaker 1', 2229, 426.432, 623.387, 1000.29, 0, 0, 270.653, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 513, '{8B4513}[SYN] Long Soft Sofa', 1753, 422.727, 626.971, 999.161, 0, 0, 359.629, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(105, 514, '{8B4513}[SYN] Marble Carpet', 2632, 424.238, 625.618, 999.182, 0, 0, 0.3499, 0, 0, 0, '4670|4118|4118|4118|4118|4118|4|0|0|0|0|0|0|0|0|0'),
(35, 515, 'Computer', 2190, 417.709, 625.465, 999.972, 0, 0, 162.223, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 516, 'Kursi Kerja', 19999, 418.929, 617.216, 999.422, 0, 0, 64.6527, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 517, 'BathTub', 2522, 415.906, 606.998, 999.222, 0, 0, -0.0706, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 518, 'Shower', 2517, 416.065, 609.393, 999.202, 0, 0, -89.3056, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 519, 'Toilet', 2514, 417.16, 608.1, 999.242, 0, 0, -90.5418, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 520, 'Wastafel', 2518, 414.673, 607.075, 999.102, 0, 0, 179.872, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 521, 'Handuk', 11707, 414.917, 606.569, 1000.88, 0, 0, 178.248, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 522, 'Kitchen Set Besar', 14720, 413.146, 617.793, 999.241, 0, 0.0999, -89.7183, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 523, 'BBQ Toast', 1481, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 524, 'Tempat Sampah', 11706, 417.421, 615.54, 999.242, 0, 0, -89.4475, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 525, 'Dispenser', 2002, 415.01, 617.544, 999.252, 0, 0, 0.791, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 526, 'Picture 3', 19174, 418.389, 618.529, 1001.05, 0, 0, -178.779, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 527, 'Moose Head', 1736, 423.101, 605.786, 1002.12, 0, 0, 179.911, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 528, 'Keset', 11737, 431.111, 612.595, 999.221, 0, 0, 90.4692, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 529, 'Sajadah', 2833, 422.754, 626.789, 999.222, 0, 0, 180.632, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 530, 'Long Table', 2357, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 531, 'Kursi makan', 2120, 425.152, 612.355, 999.822, 0, 0, -87.3329, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 532, 'Kursi makan', 2120, 423.612, 615.124, 999.822, 0, 0, 87.2628, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 533, 'Kursi makan', 2120, 422.206, 612.062, 999.822, 0, 0, -84.0998, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 534, 'Long Table', 2357, 423.79, 613.854, 999.622, 0, 0, -175.471, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 535, 'Piring&Gelas', 2812, 412.227, 614.641, 1000.28, 0, 0, 91.7354, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 536, 'Shower', 2517, 416.294, 607.228, 999.221, 0, 0, 271.676, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 537, 'BathTub', 2522, 417.229, 608.44, 999.242, 0, 0, 90.3703, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 538, 'Toilet', 2514, 413.05, 607.017, 999.302, 0, 0, 179.583, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 539, 'Wastafel', 2518, 412.725, 606.997, 999.351, 0, 0, -179.667, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 540, 'Handuk', 11707, 416.052, 606.506, 1001.15, 0, 0, 180.044, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 541, 'Bathub 2', 2526, 413.875, 606.91, 999.241, 0, 0, -0.0159, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 542, 'Picture 3', 19174, 421.237, 627.802, 1001.18, 0, 0, 0.015, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 543, 'Dispenser', 2002, 414.902, 617.557, 999.252, 0, -0.0999, -0.1797, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 544, 'Tempat Sampah', 11706, 416.974, 617.814, 999.222, 0, 0, -0.0814, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 545, 'Lampu Tidur', 2106, 416.957, 624.833, 999.922, 0, 0, 88.9078, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 546, 'Lampu Tidur', 2106, 431.196, 617.573, 999.802, 0, 0, 273.299, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 547, 'Long Table', 2357, 420.347, 609.363, 999.632, 0, 0, 90.2921, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 548, 'Kursi makan', 2120, 418.536, 608.395, 999.852, 0, 0, -178.706, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 549, 'Kursi makan', 2120, 418.536, 610.315, 999.832, 0, 0, -179.385, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 550, 'Kursi makan', 2120, 420.299, 606.167, 999.852, 0, 0, -89.8792, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 551, 'Piring&Gelas', 2812, 412.114, 614.69, 1000.22, 0, 0, 88.0478, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 552, 'BoomBox', 2226, 413.964, 617.803, 1000.22, 0, 0, -30.2929, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 553, 'Komik Doujin', 2827, 423.637, 623.884, 999.692, 0, 0, 22.7906, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 554, 'Bed Set 1', 2566, 429.074, 617.597, 999.752, 0, 0, -89.9264, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 555, 'Lampu Tidur', 2106, 431.153, 614.627, 999.811, 0, 0, 269.69, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 556, 'Sofa Modern', 1703, 431.078, 608.951, 999.222, 0, 0, -89.9315, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 557, 'Keset', 11737, 430.987, 612.628, 999.232, 0, 0, -91.0817, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 558, 'Lemari Kayu', 2025, 426.718, 614.442, 999.212, 0, 0, -179.8, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 559, 'Kitchen Set 2', 2136, 417.038, 613.097, 999.281, 0, 0, -89.8867, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 560, 'Kitchen Set 1', 2135, 417.109, 611.049, 999.252, 0, 0, -89.4396, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 561, 'Picture 4', 19173, 417.887, 609.119, 1001.5, 0, 0, 90.5143, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 562, 'Picture 3', 19174, 429.414, 613.936, 1001.36, 0, 0, -178.627, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 563, 'Tempat Sampah', 11706, 427.347, 605.872, 999.224, 1.7, 0.1, -88.9904, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 564, '{8B4513}[SYN] Microwave', 2149, 412.078, 617.783, 1000.35, 0.3, 1.0999, 48.0228, 0, 0, 0, '5708|5708|5708|5708|5708|5708|5|0|0|0|0|0|0|0|0|0'),
(105, 565, 'Wine rak', 1742, 415.507, 610.32, 1000.3, 0, 0, -179.374, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 566, '{8B4513}[SYN] Air Conditioner', 2230, 420.36, 618.486, 1002.32, -0.1999, -89.5999, -179.86, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(105, 567, 'Wine rak', 1742, 426.643, 605.442, 1000.38, 0, 0, -177.874, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 568, '{8B4513}[SYN] Long Mirror', 2815, 431.586, 610.828, 1000.58, 90.3, 0.7999, -90.7296, 0, 0, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 569, '{8B4513}[SYN] Long Mirror', 2815, 419.405, 618.494, 1001.55, -0.5999, 89.5999, 90.0197, 0, 0, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 570, 'Picture 1', 2257, 431.586, 616.108, 1001.34, 0, 0, -90.478, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 571, 'Lemari Baju', 2066, 417.216, 623.976, 999.252, 0, 0, 88.5618, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 572, 'Lemari Baju', 2066, 427.695, 614.588, 999.262, -0.1999, 0, 179.635, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 573, 'Sofa Modern', 1703, 430.199, 606.024, 999.196, 0, 0.5999, 179.827, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 574, 'Tabble Modern', 2311, 429.802, 607.893, 999.242, 0, 0, 179.994, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 575, '{8B4513}[SYN] Big Map', 19174, 422.214, 608.246, 1001, 0, 0, 90.1188, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 576, '{8B4513}[SYN] Fridge', 2147, 415.828, 617.689, 999.222, 0, 0, -0.2042, 0, 0, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(105, 577, 'Wine rak', 1742, 425.181, 605.361, 1000.37, 0, 0, 179.962, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 578, 'RADIO', 2103, 417.117, 620.707, 1000.36, 0, 0, 107.631, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 579, '{8B4513}[SYN] Air Conditioner', 2230, 429.879, 605.492, 1001.66, 0.4, 91.2999, -179.472, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(105, 580, '{8B4513}[SYN] Air Conditioner', 2230, 417.734, 613.801, 1002.2, 0, -90.1, -88.8939, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(105, 581, '{8B4513}[SYN] Wood Stand Lamp', 2108, 431.194, 605.977, 999.242, 0, 0, 224.25, 0, 0, 0, '463|1067|1310|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 582, 'Sajadah', 2833, 418.318, 623.596, 999.232, 0, 0, -0.2481, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 583, '{8B4513}[SYN] Unrest Soft Sofa', 2293, 423.389, 608.432, 999.221, 0, 0, 89.7826, 0, 0, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 584, '{8B4513}[SYN] Unrest Soft Sofa', 2293, 423.383, 609.402, 999.231, 0, 0, 90.6432, 0, 0, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 585, '{8B4513}[SYN] Unrest Soft Sofa', 2293, 424.371, 606.468, 999.212, 0, 0, 179.692, 0, 0, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(105, 586, '{8B4513}[SYN] Unrest Soft Sofa', 2293, 424.504, 610.391, 999.232, 0, 0, 0.4115, 0, 0, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 606, 'Wine rak', 1742, 423.419, 608.286, 1000.52, 0, 0, -94.4202, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 611, '{8B4513}[SYN] \" I \" Speaker', 2229, 429.838, 605.482, 1000.02, 0, 0, -147.957, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 612, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 428.517, 605.431, 1001.02, 0, 0, -177.709, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 619, '{8B4513}[SYN] White Chair', 2123, 420.267, 606.093, 999.822, 0, 0, -86.9682, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 623, '{8B4513}[SYN] Kitchen Stove', 2135, 412.149, 611.474, 999.022, 0, 0, 88.2982, 0, 0, 0, '97|463|455|463|463|463|0|0|0|0|0|0|0|0|0|0'),
(70, 624, '{8B4513}[SYN] Kitchen Faucet', 2160, 411.91, 610.123, 999.222, 0, 0, 87.7288, 0, 0, 0, '463|463|463|455|455|455|455|0|0|0|0|0|0|0|0|0'),
(70, 630, '{8B4513}[SYN] Light Wood Rack', 2067, 424.053, 606.27, 999.322, 0, 0, 174.831, 0, 0, 0, '229|455|455|455|455|455|0|0|0|0|0|0|0|0|0|0'),
(70, 633, '{8B4513}[SYN] Grey Round Table', 2315, 427.403, 608.051, 999.422, 0, 0, 1.6131, 0, 0, 0, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 637, '{8B4513}[SYN] Air Conditioner', 2230, 411.554, 613.403, 999.222, 0, 0, 87.5177, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(70, 642, 'Tabble Modern', 2311, 429.105, 615.91, 999.322, 0, 0, 3.1426, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 643, 'Long Table', 2357, 428.394, 606.014, 999.622, 0, 0, -177.707, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 644, 'Komik Doujin', 2827, 427.786, 608.196, 1000.02, 0, 0, 159.849, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 647, 'Dispenser', 2002, 431.133, 606.268, 999.222, 0, 0, -146.869, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 654, '{8B4513}[SYN] Long Soft Sofa', 1753, 428.061, 613.996, 999.222, 0, 0, -177.69, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(70, 655, 'Speaker 1', 2229, 426.576, 605.577, 1000.02, 0, 0, 159.376, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 656, 'BathTub', 2522, 416.921, 616.49, 999.322, -10, 0, 90.7527, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 657, 'Shower', 2517, 411.24, 616.039, 999.222, 0, 0, -87.6742, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 658, 'Toilet', 2514, 412.425, 617.577, 999.322, 0, 0, 84.2593, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 659, 'Handuk', 11707, 411.725, 617.04, 1000.72, -10, 0, -96.6923, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 662, 'Kitchen Set Besar', 14720, 412.133, 608.072, 999.122, 0, 0, -0.7926, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 663, 'BBQ Toast', 1481, 417.15, 607.266, 1000.02, 0, 0, -174.848, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 665, 'Wine rak', 1742, 423.383, 606.891, 1000.53, 0, 0, -87.6933, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 666, '{8B4513}[SYN] Kitchen Stove', 2135, 412.132, 612.4, 999.022, 0, 0, 88.2054, 0, 0, 0, '97|463|455|463|463|463|0|0|0|0|0|0|0|0|0|0'),
(70, 667, '{8B4513}[SYN] Big Map', 19174, 423.625, 607.898, 1001.12, 0, 0, 92.9108, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 669, '{8B4513}[SYN] White Chair', 2123, 420.242, 608.329, 999.822, 0, 0, 95.687, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 670, '{8B4513}[SYN] White Chair', 2123, 419.019, 607.093, 999.822, 0, 0, -175.498, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 673, '{8B4513}[SYN] White Chair', 2123, 421.361, 607.178, 999.922, 0, 0, 4.0798, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 678, '{8B4513}[SYN] Single Satin Sofa', 1708, 424.73, 609.51, 999.222, 0, 0, 39.2609, 0, 0, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 680, '{8B4513}[SYN] Long Soft Sofa', 1753, 425.944, 617.57, 999.322, 0, 0, -0.3087, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(70, 682, '{8B4513}[SYN] Classic Table', 2311, 426.441, 615.619, 999.222, 0, 0, 3.9212, 0, 0, 0, '1868|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(70, 686, '{8B4513}[SYN] Long Soft Sofa', 1753, 431.001, 614.265, 999.222, 0, 0, -173.406, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(70, 689, '{8B4513}[SYN] Long Soft Sofa', 1753, 428.965, 610.376, 999.222, 0, 0, -17.5222, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(70, 690, '{8B4513}[SYN] Long Soft Sofa', 1753, 429.125, 617.722, 999.322, 0, 0, -1.1762, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(70, 691, '{8B4513}[SYN] Long Soft Sofa', 1753, 426.095, 610.096, 999.222, 0, 0, 6.4771, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(70, 695, '{8B4513}[SYN] Long Soft Sofa', 1753, 424.014, 614.693, 999.222, 0, 0, 89.9999, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(70, 696, '{8B4513}[SYN] Round Table', 2030, 420.246, 607.26, 999.622, 0, 0, 178.169, 0, 0, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 697, 'Wine rak', 1742, 424.795, 614.889, 999.185, -0.5999, -11.3, 166.015, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 698, '{8B4513}[SYN] Big Map', 19174, 422.72, 610.743, 1001.65, 0, 0, -0.9379, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 699, 'Komik Doujin', 2827, 426.86, 616.145, 999.711, 0, 0, 158.538, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 700, 'BoomBox', 2226, 427.887, 616.336, 999.662, 0, 0, 46.1541, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 701, 'Bola Basket', 2114, 422.947, 616.854, 1000.45, 0, 0, 266.874, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 702, 'Tumpukan Baju', 2819, 423.071, 607.484, 999.781, 0, -4.3999, 345.547, 0, 0, 0, '4220|455|4220|4220|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 703, 'Tumpukan celana', 2819, 422.302, 607.634, 999.169, 17.6, 0, 249.531, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 704, '{8B4513}[SYN] Towel Hanging', 11707, 421.332, 605.573, 1001.12, 0, 0, 178.667, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 705, '{8B4513}[SYN] Big White Safe', 2332, 423.48, 610.354, 999.542, 0, 0, -2.8812, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 706, '{8B4513}[SYN] Water Cooler', 1808, 422.432, 615.245, 999.091, 0, 0, -93.8329, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 707, '{8B4513}[SYN] Light Wood Rack', 2067, 421.358, 606.011, 999.161, 0, 0, 176.972, 0, 0, 0, '229|455|455|455|455|455|0|0|0|0|0|0|0|0|0|0'),
(144, 708, 'Moose Head', 1736, 424.869, 607.97, 1001.9, 0, 0, -88.8283, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 709, 'PlayStation', 2028, 422.349, 609.035, 1000.22, 0, 0, 287.96, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0');
INSERT INTO `furniture` (`ID`, `furnitureID`, `furnitureName`, `furnitureModel`, `furnitureX`, `furnitureY`, `furnitureZ`, `furnitureRX`, `furnitureRY`, `furnitureRZ`, `furnitureType`, `furnitureUnused`, `furnitureStatus`, `furnitureMaterials`) VALUES
(144, 710, 'Bed Set 1', 2566, 422.671, 609.513, 999.742, 0, 0, -89.8208, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 711, 'Lampu Tidur', 2106, 424.847, 609.534, 999.761, 0, 0, 273.483, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 712, 'Lemari Baju', 2066, 423.375, 609.48, 1000.22, 0, 0, 278.131, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 713, 'Tempat Sampah', 11706, 431.274, 611.278, 999.113, 8.1999, 3.0999, -0.8286, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 714, 'BBQ Toast', 1481, 422.115, 615.987, 1000.22, 0, 0, -89.9001, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 715, 'Picture 1', 2257, 431.503, 615.664, 1001.14, 0, 0, -87.6732, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 716, 'Picture 3', 19174, 423.76, 610.98, 1001.4, 0, 0, 179.748, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 717, 'Komik Doujin', 2827, 419.38, 616.574, 999.201, 0, 0, 351.804, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 718, 'Foto Kenangan', 2828, 422.933, 617.549, 1000.38, 0, 0, -141.735, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 719, 'Speaker 2', 2230, 423.657, 618.362, 999.211, 0, 0, 64.2247, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 720, 'Lampu Panjang', 2069, 431.391, 618.04, 999.271, 0, 0, 182.843, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 721, 'Dispenser', 2002, 417.185, 611.801, 999.171, 0, 0, 276.286, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 722, 'Tabble Modern', 2311, 426.406, 616.154, 999.201, 0, 0, 3.6218, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 723, 'Kursi makan', 2120, 422.9, 614.487, 999.802, 0, 0, 84.869, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 724, 'Small Sofa Modern', 1724, 424.579, 615.492, 999.071, 0, 0, 90.9813, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 725, 'Small Sofa Modern', 1724, 430.349, 615.526, 999.151, 0, 0, -121.979, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 726, 'Sofa Modern', 1703, 428.081, 614.549, 999.151, 0, 0, -176.955, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 727, 'Shower', 2517, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 728, 'Toilet', 2514, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(144, 729, 'Wastafel', 2518, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 730, 'Bed Set 1', 2566, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 731, 'Kitchen Set Besar', 14720, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 732, 'Dispenser', 2002, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 733, 'Kitchen Set 2', 2136, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 734, 'Kitchen Set 1', 2135, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 735, 'Sofa Modern', 1703, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 736, 'Tabble Modern', 2311, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 737, 'Small Sofa Modern', 1724, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 738, 'TV 18\"Inch', 19786, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 739, 'Speaker 1', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 740, 'Kursi Kerja', 19999, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 741, 'Meja Kerja', 2184, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 742, 'Computer', 2190, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 743, 'PlayStation', 2028, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 744, 'BathTub', 2522, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 745, 'Shower', 2517, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 746, 'Toilet', 2514, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 747, 'Wastafel', 2518, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 748, 'Handuk', 11707, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 749, 'Piring&Gelas', 2812, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 750, 'Long Table', 2357, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 751, 'Kursi makan', 2120, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 752, 'Kursi makan', 2120, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 753, 'Kursi makan', 2120, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 754, 'Kulit Macan', 1828, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 755, 'Sajadah', 2833, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 756, 'Karpet Kotak\"', 2818, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 757, 'Speaker 1', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 758, 'Moose Head', 1736, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 759, 'Lampu Panjang', 2069, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 760, 'Lampu Panjang', 2069, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 761, 'Lampu Tidur', 2106, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 762, '{8B4513}[SYN] Potrait 4', 2263, 417.167, 609.927, 1001.33, 0, 0, -90.3806, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 763, '{8B4513}[SYN] Modern Bed Set', 2575, 416.158, 609.09, 999.562, 0, 0, -178.454, 0, 0, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 764, '{8B4513}[SYN] Darktone Cabinet', 2576, 426.525, 608.588, 999.215, 0, -0.2, -89.6741, 0, 0, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 765, '{8B4513}[SYN] Wood Frame Lamp', 2069, 431.201, 611.376, 999.242, 0, 0, -88.5462, 0, 0, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 766, '{8B4513}[SYN] Long Mirror', 2815, 414.064, 618.278, 1001.07, -0.8, -90.6, 89.6725, 0, 0, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 767, '{8B4513}[SYN] Marble Carpet', 2632, 430.638, 616.443, 999.182, 0, 0, -90.0549, 0, 0, 0, '4670|4118|4118|4118|4118|4118|4|0|0|0|0|0|0|0|0|0'),
(155, 768, '{8B4513}[SYN] Grey Round Table', 2315, 429.659, 617.106, 999.225, 0, 0, 270.376, 0, 0, 0, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 769, '{8B4513}[SYN] Long Soft Sofa', 1753, 431.124, 610.471, 999.201, 0, 0, -90.8205, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(155, 770, '{8B4513}[SYN] Single Soft Sofa', 1754, 430.127, 610.434, 999.212, 0, 0, -1.1886, 0, 0, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 771, '{8B4513}[SYN] Unrest Soft Sofa', 2293, 429.148, 610.404, 999.161, 0, 0, 178.76, 0, 0, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 772, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 429.903, 605.462, 1001.52, 1.1, 0, 179.64, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 773, '{8B4513}[SYN] \" I \" Speaker', 2229, 427.819, 605.501, 999.171, 0, 0, -179.725, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 774, '{8B4513}[SYN] \" I \" Speaker', 2229, 430.998, 605.339, 999.252, 0, 0, 177.934, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 776, '{8B4513}[SYN] White Bathtub', 2516, 418.355, 608.76, 999.163, -0.4999, 0, -89.8167, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 777, '{8B4513}[SYN] White Toilet', 2514, 418.883, 605.934, 999.231, 0, 0, -175.52, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 778, '{8B4513}[SYN] White Shower', 2517, 419.477, 606.102, 999.191, 0, 0, -87.8165, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 781, '{8B4513}[SYN] Desk', 2184, 416.107, 612.531, 999.221, 0, 0, 236.734, 0, 0, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 782, '{8B4513}[SYN] Office Chair', 19999, 416.757, 610.779, 999.241, 0, 0, 235.728, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 783, '{8B4513}[SYN] Plate', 2820, 419.9, 621.258, 1000.22, 0, 0, 302.466, 0, 0, 0, '463|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 784, '{8B4513}[SYN] Kitchen 2', 2151, 422.825, 627.558, 999.241, 0, 0, 1.3556, 0, 0, 0, '455|463|455|463|463|463|463|463|0|0|0|0|0|0|0|0'),
(155, 785, '{8B4513}[SYN] Kitchen Faucet', 2160, 425.353, 627.646, 999.221, 0, 0, -0.6577, 0, 0, 0, '463|463|463|455|455|455|455|0|0|0|0|0|0|0|0|0'),
(155, 786, '{8B4513}[SYN] Kitchen Stove', 2135, 424.318, 627.532, 999.162, 0, 0, -0.1083, 0, 0, 0, '97|463|455|463|463|463|0|0|0|0|0|0|0|0|0|0'),
(155, 787, '{8B4513}[SYN] Fridge', 2147, 421.535, 627.209, 999.121, 0, 0, 0.4453, 0, 0, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(155, 788, '{8B4513}[SYN] Potrait 5', 2284, 414.757, 606.977, 1001.57, 0, 0, 179.118, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 789, '{8B4513}[SYN] Potrait 4', 2263, 431.089, 609.05, 1001.05, 0, 0, -89.5126, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 790, '{8B4513}[SYN] Potrait 2', 2269, 418.339, 609.855, 1001.45, 0, 0, 89.2702, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 791, '{8B4513}[SYN] Potrait 1', 19173, 422.419, 612.138, 1000.94, 0, 0, 179.82, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 792, '{8B4513}[SYN] Big Map', 19174, 425.808, 618.307, 1001.51, 0, 0, -0.2872, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 793, '{8B4513}[SYN] Potrait 7', 2272, 429.526, 617.761, 1000.55, 0, 0, 0.8698, 0, 0, 0, '463|528|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 794, '{8B4513}[SYN] Trash Bin', 11706, 426.178, 621.229, 999.192, 0, 0, 88.9997, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 795, 'Wine rak', 1742, 427.111, 607.154, 999.921, 0, 0, 90.0295, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 796, '{8B4513}[SYN] Tiger Skin', 1828, 429.913, 607.335, 999.202, 0, 0, 178.616, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 798, 'Toilet', 2514, 417.135, 616.334, 999.231, 0, 0, 269.452, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 799, 'Wastafel', 2518, 413.062, 617.75, 999.572, 0, 0, -0.8567, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 800, 'Handuk', 11707, 416.581, 618.186, 1000.56, 0, 0, 0.4241, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 801, 'BathTub', 2522, 415.884, 617.808, 999.101, 0, 0, -0.4482, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 802, 'Lemari Kayu', 2025, 412.466, 609.54, 999.181, 0, 0, 94.5735, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 803, 'Picture 1', 2257, 426.411, 624.056, 1001.36, 0, 0, -90.6639, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 804, 'Bed Set 1', 2566, 424.482, 608.028, 999.782, 0, 0, -179.754, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 805, 'Lampu Tidur', 2106, 416.037, 606.8, 999.882, 0, 0, 148.968, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 806, 'Long Table', 2357, 419.577, 621.563, 999.612, 0, 0, -1.3922, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 807, 'Piring&Gelas', 2812, 420.67, 621.535, 1000.05, 0, 0, 96.7481, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 808, 'Kursi makan', 2120, 420.711, 620.471, 999.862, 0, 0, -92.1986, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 809, 'Kursi makan', 2120, 420.647, 622.83, 999.882, 0, 0, 86.8099, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 810, 'Kursi makan', 2120, 422.231, 621.732, 999.862, 0, 0, 0.2822, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 811, 'Picture 2', 2255, 422.966, 611.414, 1000.62, 0, 0, -0.6477, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 812, 'Komik Doujin', 2827, 423.102, 612.449, 999.732, 0, -0.1999, -177.617, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 813, 'Kitchen Set Besar', 14720, 418.15, 627.362, 999.082, 0, 0, -90.2495, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 814, 'Kitchen Set 1', 2135, 422.304, 612.578, 999.202, 0, 0, 179.872, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 845, '{8B4513}[SYN] Big Map', 19174, 431.505, 608.435, 1001.4, 0.6002, -0.8998, -87.1372, 0, 1, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 846, '{8B4513}[SYN] Big White Safe', 2332, 418.273, 616.191, 999.622, 0, 0, 90.4814, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 847, 'Wine rak', 1742, 424.604, 618.372, 1000.12, 0, 0, -0.8292, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(35, 848, '{8B4513}[SYN] Fridge', 2147, 418.535, 606.105, 999.022, 0, 0, 126.818, 0, 0, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(155, 861, 'Tumpukan Baju', 2819, 415.567, 608.371, 999.732, 0, 0, 160.89, 0, 0, 0, '4220|455|4220|4220|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 862, 'Tumpukan Baju', 2819, 422.302, 607.695, 999.812, -0.8, -4.5999, -81.205, 0, 0, 0, '4220|455|4220|4220|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 863, 'Lemari Baju', 2066, 421.605, 609.614, 999.282, 0, 0, 90.2274, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 864, 'Tempat Sampah', 11706, 424.238, 611.771, 999.112, 0, 0, -0.2226, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 865, 'BoomBox', 2226, 421.83, 612.43, 999.722, -0.9999, 0, 161.219, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 866, '{8B4513}[SYN] Marble Carpet', 2632, 428.727, 616.451, 999.192, 0, 0, -90.1184, 0, 0, 0, '4670|4118|4118|4118|4118|4118|4|0|0|0|0|0|0|0|0|0'),
(155, 867, '{8B4513}[SYN] Square Mirror', 11737, 411.64, 607.693, 1000.77, 0, 89.8999, -0.0492, 0, 0, 0, '220|5266|0|0|0|0|0|0|8273|0|42|0|0|0|0|0'),
(155, 868, '{8B4513}[SYN] Square Mirror', 11737, 421.109, 606.799, 1000.79, 0, 89.8998, 0.8815, 0, 0, 0, '220|5266|0|0|0|0|0|0|8273|0|42|0|0|0|0|0'),
(155, 869, '{8B4513}[SYN] Air Conditioner', 2230, 424.867, 611.881, 1001.69, 0, 90.2999, 0.4299, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(155, 870, '{8B4513}[SYN] Air Conditioner', 2230, 412.568, 614.787, 1001.69, 0.2, 91.0999, 2.0349, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(155, 871, '{8B4513}[SYN] Air Conditioner', 2230, 431.697, 613.315, 1001.75, 0, 89.4999, -92.4094, 0, 0, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(155, 872, '{8B4513}[SYN] Big White Safe', 2332, 417.043, 606.967, 999.622, 0, 0, 180.785, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 873, 'Tabble Modern', 2311, 423.232, 612.551, 999.225, 1.4, 0, 178.714, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 874, 'Small Sofa Modern', 1724, 421.258, 612.665, 999.182, 0, 0, 177.852, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 875, 'Small Sofa Modern', 1724, 424.722, 612.557, 999.232, 0, 0, 179.446, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 876, 'Lemari Kayu', 2025, 421.584, 610.43, 999.231, 0, 0, 90.4492, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 877, 'Kulit Macan', 1828, 422.089, 614.706, 999.212, 0, 0, -2.1342, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(155, 878, 'Moose Head', 1736, 418.122, 614.356, 1002.22, 0, 0, 91.1672, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 919, 'Piring&Gelas', 2812, 737.206, 1698.48, 501.186, 0, 0, -30.0562, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 920, 'Piring&Gelas', 2812, 735.975, 1694.96, 500.886, 0, 0, 17.3791, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 921, 'Piring&Gelas', 2812, 727.319, 1687.54, 500.586, 0, 0, -56.2665, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 922, 'Tumpukan Baju', 2819, 725.736, 1677.19, 500.086, 0, 0, -9.8325, 0, 0, 0, '4220|455|4220|4220|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 923, 'Komik Doujin', 2827, 742.384, 1687.39, 500.106, 0, 0, -17.6921, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 924, 'Komik Doujin', 2827, 727.011, 1678.75, 500.086, 0, 0, 4.9591, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 925, 'Komik Doujin', 2827, 729.112, 1678.01, 500.786, 0, 0, -20.9988, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 926, 'Komik Doujin', 2827, 727.25, 1686.38, 500.586, 0, 0, -58.8438, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 927, 'Komik Doujin', 2827, 728.034, 1687.39, 500.086, 0, 0, 72.7621, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 928, 'BoomBox', 2226, 746.669, 1683.16, 500.106, 0, 0, -115.817, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 929, 'Bola Basket', 2114, 732.197, 1672.89, 500.286, 0, 0, 179.183, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 930, 'Piring&Gelas', 2812, 744.102, 1686.18, 500.106, 0, 0, -17.0752, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 931, 'Piring&Gelas', 2812, 725.78, 1674.83, 500.086, 0, 0, 166.668, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 932, 'Piring&Gelas', 2812, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 933, 'Komik Doujin', 2827, 742.744, 1682.6, 500.906, 0, 0, -36.8688, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 934, 'Komik Doujin', 2827, 726.059, 1673.17, 500.886, 0, 0, 117.804, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 935, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 936, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 937, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(117, 938, '{8B4513}[SYN] Tiger Skin', 1828, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 939, '{8B4513}[SYN] Modern Bed Set', 2575, 423.354, 626.411, 999.582, 0, 0, -179.57, 0, 0, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 942, '{8B4513}[SYN] Satin Long Sofa', 1713, 421.864, 611.006, 999.172, 0, 0, 0.2571, 0, 0, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 943, '{8B4513}[SYN] Single Satin Sofa', 1708, 424.411, 609.069, 999.182, 0, 0, -90.2466, 0, 0, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 945, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 421.559, 627.946, 1001.48, 0, 0, -0.189, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 946, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 421.453, 605.859, 1000.63, 0, 0, -179.928, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 947, '{8B4513}[SYN] White Toilet', 2514, 417.155, 617.763, 999.232, 0, 0, -90.1021, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 948, '{8B4513}[SYN] Stand White Sink', 2523, 417.178, 616.562, 999.212, 0, 0, -88.8089, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 949, '{8B4513}[SYN] Darktone Cabinet', 2576, 419.727, 623.466, 999.148, 0, 0, -0.4425, 0, 0, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 950, '{8B4513}[SYN] White Bathtub', 2516, 414.4, 607.111, 999.212, 0, 0, 0.0953, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 951, '{8B4513}[SYN] Towel Hanging', 11707, 417.63, 612.847, 1000.4, 0, 0, -87.4513, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 952, '{8B4513}[SYN] White Shower', 2517, 417.217, 608.057, 999.191, 0, 0, 179.034, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 953, '{8B4513}[SYN] Big Map', 19174, 421.479, 605.488, 1001.32, 0, 0, -179.811, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 954, '{8B4513}[SYN] Water Cooler', 1808, 431.427, 610.548, 999.182, 0, 0, -88.3989, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 958, '{8B4513}[SYN] Kitchen Stove', 2135, 431.088, 608.726, 999.201, 0, 0, 271.692, 0, 0, 0, '97|463|455|463|463|463|0|0|0|0|0|0|0|0|0|0'),
(159, 959, '{8B4513}[SYN] Fridge', 2147, 431.114, 609.756, 999.131, 0, 0, -88.9814, 0, 0, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(159, 960, 'Wine rak', 1742, 417.791, 611.517, 999.962, 0, 0, -89.4262, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 961, '{8B4513}[SYN] Satin Long Sofa', 1713, 419.401, 611.004, 999.171, 0, 0, 0.1311, 0, 0, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 962, '{8B4513}[SYN] Satin Long Sofa', 1713, 418.422, 607.6, 999.152, 0, 0, 90.6155, 0, 0, 0, '455|1067|463|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 963, '{8B4513}[SYN] Abstract Carpet', 2631, 430.689, 616.343, 999.241, 0, 0, -90.0977, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 964, '{8B4513}[SYN] Abstract Carpet', 2631, 430.673, 612.45, 999.242, 0, 0, -90.571, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 965, '{8B4513}[SYN] Abstract Carpet', 2631, 430.636, 608.568, 999.242, 0, 0, -90.771, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 966, '{8B4513}[SYN] Abstract Carpet', 2631, 429.815, 606.39, 999.242, 0, 0, 182.029, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 967, '{8B4513}[SYN] Abstract Carpet', 2631, 425.98, 606.327, 999.242, 0, 0, 179.685, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 968, '{8B4513}[SYN] Abstract Carpet', 2631, 428.793, 616.557, 999.231, 0, 0, -90.1716, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 969, '{8B4513}[SYN] Abstract Carpet', 2631, 428.749, 612.671, 999.232, 0, 0, -90.9717, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 970, '{8B4513}[SYN] Abstract Carpet', 2631, 428.757, 612.654, 999.231, 0, 0, -90.8983, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 971, '{8B4513}[SYN] Abstract Carpet', 2631, 428.714, 608.748, 999.251, 0, 0, -90.6983, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 972, '{8B4513}[SYN] Abstract Carpet', 2631, 426.919, 616.364, 999.231, 0, 0, -90.9715, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 973, '{8B4513}[SYN] Abstract Carpet', 2631, 426.857, 612.481, 999.232, 0, 0, -90.9715, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 974, '{8B4513}[SYN] Abstract Carpet', 2631, 426.812, 608.934, 999.242, 0, 0, -90.8715, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 975, '{8B4513}[SYN] Abstract Carpet', 2631, 422.088, 606.346, 999.241, 0, 0, 179.867, 0, 0, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 976, '{8B4513}[SYN] Desk', 2184, 417.323, 623.528, 999.212, 0, 0, -1.3791, 0, 0, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 977, '{8B4513}[SYN] Office Chair', 19999, 418.289, 625.631, 999.222, 0, 0, -1.6933, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 978, '{8B4513}[SYN] Long Marble Table', 2357, 421.431, 606.244, 999.612, 0, 0, -179.935, 0, 0, 0, '1339|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 979, '{8B4513}[SYN] Wood Stand Lamp', 2108, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|1310|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 980, '{8B4513}[SYN] Wood Stand Lamp', 2108, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|1310|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 981, '{8B4513}[SYN] \" I \" Speaker', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(159, 982, '{8B4513}[SYN] \" I \" Speaker', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1006, 'PlayStation', 2028, 427.297, 606.053, 1000.11, 0, 0, 176.229, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1007, 'Kulit Macan', 1828, 421.978, 622.623, 999.211, 0, 0, 2.9941, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1008, 'Kitchen Set 2', 2136, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1009, 'Kitchen Set 1', 2135, 423.788, 610.832, 1000.22, 0, 0, 180.196, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1010, 'Lemari Kayu', 2025, 427.014, 606.415, 999.211, 0, 0, -0.4476, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1011, 'Bed Set 3', 1797, 414.858, 611.526, 1000.22, 0, 0, 178.521, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1012, 'Lampu Panjang', 2069, 426.057, 618.858, 999.282, 0, 0, 339.445, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1013, 'Lampu Tidur', 2106, 416.016, 608.101, 999.672, 0, 0, 183.325, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1014, 'Bed Set 1', 2566, 423.957, 622.607, 999.681, 0, 0, -92.3836, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1015, 'Bathub 2', 2526, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1016, 'Shower', 2517, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1017, 'BathTub', 2522, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1018, 'Toilet', 2514, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1019, 'TV 18\"Inch', 19786, 427.218, 605.477, 1001.34, 0, 0, 180.719, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1020, 'Piring&Gelas', 2812, 422.748, 609.568, 1000.11, 0, 0, 48.695, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1021, 'Long Table', 2357, 422.268, 609.836, 999.632, 0, 0, -179.433, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1022, 'Kursi makan', 2120, 423.168, 610.947, 999.822, 0, 0, 90.5895, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1023, 'Sofa Modern', 1703, 426.15, 609.192, 999.102, 0, 0, 1.7463, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1024, 'Tabble Modern', 2311, 427.94, 605.888, 999.301, 0, 0, -178.525, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1025, 'Small Sofa Modern', 1724, 429.293, 608.755, 1000.22, 0, 0, 287.953, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1026, 'Keset', 11737, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 1032, 'Piring&Gelas', 2812, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 1033, 'Piring&Gelas', 2812, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 1034, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 1035, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 1036, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 1037, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 1038, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 1039, 'BoomBox', 2226, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(65, 1040, 'Tempat Sampah', 11706, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1041, '{8B4513}[SYN] \" I \" Speaker', 2229, 425.333, 605.292, 999.151, 0, 0, -177.752, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1042, '{8B4513}[SYN] Potrait 5', 2284, 425.959, 621.073, 1001.05, 0, 0, 268.582, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1043, '{8B4513}[SYN] Potrait 1', 19173, 424.561, 621.87, 1000.22, 0, 0, 270.055, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1044, '{8B4513}[SYN] \" I \" Speaker', 2229, 428.747, 605.424, 998.951, 0, 0, 178.84, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1045, '{8B4513}[SYN] Kitchen 2', 2151, 417.828, 607.422, 999.202, 0, 0, 88.5834, 0, 0, 0, '455|463|455|463|463|463|463|463|0|0|0|0|0|0|0|0'),
(7, 1046, '{8B4513}[SYN] Kitchen Faucet', 2160, 418.09, 608.807, 999.231, 0, 0, 92.4633, 0, 0, 0, '463|463|463|455|455|455|455|0|0|0|0|0|0|0|0|0'),
(7, 1047, '{8B4513}[SYN] Kitchen Stove', 2135, 418.337, 610.245, 999.162, 0, 0, 96.4322, 0, 0, 0, '97|463|455|463|463|463|0|0|0|0|0|0|0|0|0|0'),
(7, 1048, '{8B4513}[SYN] Fridge', 2147, 418.325, 611.232, 999.171, 0, 0, 94.343, 0, 0, 0, '1052|5708|5708|8273|138|10|10|1|0|0|0|0|0|0|0|0'),
(7, 1049, 'Wine rak', 1742, 423.912, 605.472, 999.262, 0, 0, -174.68, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1050, 'Meja Kerja', 2184, 421.158, 625.392, 999.251, 0, 0, 9.557, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1051, 'Kursi Kerja', 19999, 417.221, 623.083, 999.221, 0, 0, 88.5582, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1052, 'Picture 1', 2257, 425.582, 608.919, 999.161, 0, 0, -0.9743, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1053, '{8B4513}[SYN] Darktone Cabinet', 2576, 425.907, 626.37, 999.171, 0, 0, 269.893, 0, 0, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1054, '{8B4513}[SYN] Desk', 2184, 419.15, 622.016, 999.221, 0, 0, 87.6183, 0, 0, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1055, '{8B4513}[SYN] Long Marble Table', 2357, 414.595, 607.106, 999.611, 0, 0, -179.004, 0, 0, 0, '1339|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1056, '{8B4513}[SYN] Marble Carpet', 2632, 427.117, 607.167, 999.172, 0, 0, -179.477, 0, 0, 0, '4670|4118|4118|4118|4118|4118|4|0|0|0|0|0|0|0|0|0'),
(7, 1057, '{8B4513}[SYN] Long Soft Sofa', 1753, 426.252, 608.909, 999.182, 0, 0, -0.1744, 0, 0, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(7, 1058, '{8B4513}[SYN] Grey Round Table', 2315, 427.692, 607.193, 999.232, 0, 0, 179.872, 0, 0, 0, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1059, '{8B4513}[SYN] Air Conditioner', 2230, 423.586, 621.623, 1000.22, 0, 91.3, -92.3492, 0, 1, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(7, 1060, 'Komik Doujin', 2827, 426.901, 607.305, 999.761, 0, 0, 42.9731, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1061, 'Dispenser', 2002, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1062, 'Bed Set 2', 2298, 415.698, 611.797, 999.182, 0, 0, -177.828, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1063, 'TV 12\"Inch', 19787, 414.453, 606.553, 1001.9, 0, 0, 185.13, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1064, 'Computer', 2190, 419.293, 622.82, 999.972, 0, 0, -90.7745, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1065, 'Moose Head', 1736, 417.34, 611.562, 1001.82, 0, 0, -87.5878, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1066, 'Sajadah', 2833, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(7, 1067, 'Tempat Sampah', 11706, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1099, '{8B4513}[SYN] Unrest Soft Sofa', 2293, 424.02, 625.105, 999.122, 0, 0, -175.535, 0, 0, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1100, '{8B4513}[SYN] Modern Bed Set', 2575, 419.47, 622.505, 999.622, 0, 0, 95.2292, 0, 0, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1101, 'Tabble Modern', 2311, 429.101, 608.004, 1000.22, 0, 0, 218.592, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1102, 'Sofa Modern', 1703, 424.181, 621.345, 1000.22, 0, 0, 238.471, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1103, 'Sofa Modern', 1703, 422.527, 623.069, 999.122, 0, 0, 93.516, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1104, 'Kulit Macan', 1828, 423.855, 624.022, 999.222, 0, 0, -93.7069, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1105, 'Kulit Macan', 1828, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1106, 'TV 18\"Inch', 19786, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1107, 'Speaker 1', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1108, 'Speaker 1', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1109, '{8B4513}[SYN] Long Marble Table', 2357, 420.606, 608.388, 999.622, 0, 0, 87.3686, 0, 0, 0, '1339|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1110, '{8B4513}[SYN] White Chair', 2123, 421.743, 609.665, 999.822, 0, 0, 1.1539, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1111, '{8B4513}[SYN] White Chair', 2123, 419.626, 609.933, 999.822, 0, 0, 173.173, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1112, '{8B4513}[SYN] White Chair', 2123, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(79, 1113, '{8B4513}[SYN] White Chair', 2123, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(127, 1122, '{8B4513}[SYN] Modern Bed Set', 2575, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(127, 1123, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(127, 1124, '{8B4513}[SYN] Office Chair', 19999, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(127, 1125, '{8B4513}[SYN] Desk', 2184, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1126, 'Long Table', 2357, 427.634, 608.632, 999.422, 0, 0, 0.5072, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1127, 'Bed Set 2', 2298, 421.416, 609.845, 998.922, 0, 0, -174.343, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1128, 'Picture 3', 19174, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1129, 'Tabble Modern', 2311, 414.298, 617.295, 999.322, 0, 0, 1.6067, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1130, 'Small Sofa Modern', 1724, 424.75, 606.575, 999.222, 0, 0, 144.555, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1131, 'Small Sofa Modern', 1724, 430.874, 607.365, 999.322, 0, 0, -142.759, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1132, 'Sofa Modern', 1703, 428.495, 606.039, 999.122, 0, 0, 178.95, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1133, 'Komik Doujin', 2827, 413.867, 608.821, 1000.02, 0, 0, -64.1599, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1134, 'Komik Doujin', 2827, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1135, 'BoomBox', 2226, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1136, 'Kulit Macan', 1828, 415.38, 607.954, 999.222, 0, 0, 175.974, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1137, 'Keset', 11737, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1138, 'Lemari Kayu', 2025, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1139, 'Tempat Sampah', 11706, 411.883, 610.06, 999.122, 0, 0, 90.4192, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1140, 'Kursi Kerja', 19999, 412.334, 607.216, 999.222, 0, 0, 152.347, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1141, 'Meja Kerja', 2184, 414.127, 608.896, 999.222, 0, 0, 164.426, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1142, 'Computer', 2190, 412.556, 609.396, 1000.02, 0, 0, 2.1235, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1143, 'Lemari Baju', 2066, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1144, 'Lemari Baju', 2066, 417.249, 606.872, 999.222, 0, 0, -130.619, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(73, 1145, 'Picture 4', 19173, 414.29, 606.6, 1002.22, 10, 0, -177.697, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1146, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 431.645, 608.525, 1000.9, 0, 0, -89.8479, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1147, '{8B4513}[SYN] \" I \" Speaker', 2229, 431.573, 609.667, 999.182, 0, 0, -90.9639, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1148, '{8B4513}[SYN] Light Wood Rack', 2067, 431.254, 606.892, 999.221, 0, 0, -100.447, 0, 0, 0, '229|455|455|455|455|455|0|0|0|0|0|0|0|0|0|0'),
(38, 1149, 'Wine rak', 1742, 425.955, 607.32, 999.462, 0, 0, -88.684, 0, 0, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1150, 'Lemari Kayu', 2025, 417.239, 608.044, 999.162, 0, 0, -89.0942, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1151, 'Tumpukan celana', 2819, 413.633, 611.676, 999.192, 0, 0, 9.2619, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1152, 'Komik Doujin', 2827, 416.224, 610.781, 999.222, 0, 0, 199.617, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1153, 'Bed Set 3', 1797, 413.155, 609.982, 999.182, 0, 0, -179.817, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1154, 'Tabble Modern', 2311, 429.177, 607.895, 999.202, 0, 0, 88.59, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1155, 'Small Sofa Modern', 1724, 426.688, 605.567, 999.232, 0, 0, 93.9507, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1156, 'Sofa Modern', 1703, 426.614, 606.944, 999.192, 0, 0, 92.9205, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1157, 'Lemari Baju', 2066, 413.982, 607.178, 999.203, 0, 0, -168.559, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1158, 'Kitchen Set Besar', 14720, 418.406, 606.941, 999.181, 0, 0, 0.4436, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1159, 'Tempat Sampah', 11706, 424.926, 605.887, 999.412, 0, 0, -179.15, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1160, 'Dispenser', 2002, 424.323, 606.091, 999.192, 0, 0, 179.428, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1161, 'Kitchen Set 1', 2135, 423.487, 605.985, 999.284, 0, 0, 181.088, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1162, 'Kitchen Set 2', 2136, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1163, 'Tumpukan Baju', 2819, 431.033, 607.911, 999.211, 0, 0, 72.1514, 0, 0, 0, '4220|455|4220|4220|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1164, 'Tumpukan Baju', 2819, 413.15, 608.497, 999.852, 0, 0, 182.823, 0, 0, 0, '4220|455|4220|4220|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1165, 'Kursi makan', 2120, 418.687, 623.156, 999.842, 0, 0, 179.317, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1166, 'Kursi makan', 2120, 421.576, 624.286, 999.832, 0, 0, 88.4134, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1167, 'Kursi makan', 2120, 421.435, 621.781, 999.831, 0, 0, -91.4379, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1168, 'Piring&Gelas', 2812, 422.406, 605.951, 1000.18, 0, 0, 151.988, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1169, 'Long Table', 2357, 421.427, 623.102, 999.462, 0, 0, -179.964, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1170, 'Keset', 11737, 431.157, 612.697, 999.221, 0, 0, 90.8351, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1171, '{8B4513}[SYN] Light Wood Rack', 2067, 0, 0, 0, 0, 0, 0, 0, 1, 0, '229|455|455|455|455|455|0|0|0|0|0|0|0|0|0|0'),
(38, 1172, 'RADIO', 2103, 429.146, 608.731, 999.721, 0, 0, -120.289, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1173, '{8B4513}[SYN] Big White Safe', 2332, 415.526, 606.925, 999.602, 0, 0, 179.96, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1174, '{8B4513}[SYN] Big Map', 19174, 426.437, 622.827, 1001.2, 0, 0, -90.0706, 0, 0, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1175, '{8B4513}[SYN] Wood Stand Lamp', 2108, 430.936, 606.315, 999.201, 0, 0, 250.251, 0, 0, 0, '463|1067|1310|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(38, 1176, '{8B4513}[SYN] Wood Frame Lamp', 2069, 414.849, 607.027, 999.232, 0, 0, 99.0467, 0, 0, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(106, 1177, '{8B4513}[SYN] Potrait 1', 19173, 346.085, 1660.78, 1003.29, 0, 0, 179.923, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(106, 1178, '{8B4513}[SYN] Tiger Skin', 1828, 350.493, 1665.87, 1001.16, 0, 0, 87.6698, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1180, 'RADIO', 2103, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1181, '{8B4513}[SYN] Tiger Skin', 1828, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1182, '{8B4513}[SYN] Office Chair', 19999, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1183, '{8B4513}[SYN] Desk', 2184, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1184, 'Wine rak', 1742, 0, 0, 0, 0, 0, 0, 0, 1, 0, '2709|2709|335|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1185, '{8B4513}[SYN] Plate', 2820, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1186, '{8B4513}[SYN] Kitchen 2', 2151, 0, 0, 0, 0, 0, 0, 0, 1, 0, '455|463|455|463|463|463|463|463|0|0|0|0|0|0|0|0'),
(145, 1187, '{8B4513}[SYN] Trash Bin', 11706, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1188, '{8B4513}[SYN] Potrait 5', 2284, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1189, '{8B4513}[SYN] Big Map', 19174, 0, 0, 0, 0, 0, 0, 0, 1, 0, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1190, '{8B4513}[SYN] Water Cooler', 1808, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1191, '{8B4513}[SYN] LCD TV 32 Inch', 19786, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1192, '{8B4513}[SYN] Marble Carpet', 2632, 0, 0, 0, 0, 0, 0, 0, 1, 0, '4670|4118|4118|4118|4118|4118|4|0|0|0|0|0|0|0|0|0'),
(145, 1193, '{8B4513}[SYN] Long Soft Sofa', 1753, 0, 0, 0, 0, 0, 0, 0, 1, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(145, 1194, '{8B4513}[SYN] Unrest Soft Sofa', 2293, 0, 0, 0, 0, 0, 0, 0, 1, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1195, '{8B4513}[SYN] Single Soft Sofa', 1754, 0, 0, 0, 0, 0, 0, 0, 1, 0, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1196, '{8B4513}[SYN] Long Soft Sofa', 1753, 0, 0, 0, 0, 0, 0, 0, 1, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(145, 1197, '{8B4513}[SYN] Grey Round Table', 2315, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1198, '{8B4513}[SYN] Wood Frame Lamp', 2069, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1199, '{8B4513}[SYN] Air Conditioner', 2230, 0, 0, 0, 0, 0, 0, 0, 1, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(145, 1200, '{8B4513}[SYN] Long Marble Table', 2357, 0, 0, 0, 0, 0, 0, 0, 1, 0, '1339|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1201, '{8B4513}[SYN] White Chair', 2123, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(145, 1202, '{8B4513}[SYN] Round Table', 2030, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(59, 1203, 'Modern Bed Set', 2575, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(59, 1204, 'Darktone Cabinet', 2576, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(59, 1205, 'Wood Frame Lamp', 2069, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(59, 1206, 'Long Mirror', 2815, 0, 0, 0, 0, 0, 0, 0, 1, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(59, 1207, 'Air Conditioner', 2230, 0, 0, 0, 0, 0, 0, 0, 1, 0, '995|455|463|631|631|455|268|268|0|0|0|0|0|0|0|0'),
(59, 1208, 'RADIO', 2103, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(59, 1209, 'Grey Round Table', 2315, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(59, 1210, 'Marble Carpet', 2632, 0, 0, 0, 0, 0, 0, 0, 1, 0, '4670|4118|4118|4118|4118|4118|4|0|0|0|0|0|0|0|0|0'),
(59, 1211, 'Long Soft Sofa', 1753, 0, 0, 0, 0, 0, 0, 0, 1, 0, '229|4118|4118|4118|4118|4118|0|0|0|0|0|0|0|0|0|0'),
(28, 1212, 'Modern Bed Set', 2575, 425.327, 612.636, 999.821, 0, 0, 6.2561, 0, 0, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(28, 1213, 'Darktone Cabinet', 2576, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(28, 1214, 'Wood Stand Lamp', 2108, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|1310|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(28, 1215, 'Wood Frame Lamp', 2069, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(28, 1216, 'Long Mirror', 2815, 0, 0, 0, 0, 0, 0, 0, 1, 0, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(28, 1217, 'Abstract Carpet', 2631, 0, 0, 0, 0, 0, 0, 0, 1, 0, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(28, 1218, 'Classic Table', 2311, 0, 0, 0, 0, 0, 0, 0, 1, 0, '1868|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(28, 1219, 'LCD Tv 32 Inch', 19786, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(28, 1220, '\" I \" Speaker', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(28, 1221, '\" I \" Speaker', 2229, 0, 0, 0, 0, 0, 0, 0, 1, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 1222, 'Modern Bed Set', 2575, 0, 0, 0, 0, 0, 0, 0, 1, 0, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(34, 1223, 'Darktone Cabinet', 2576, 0, 0, 0, 0, 0, 0, 0, 1, 0, '8704|8698|8698|0|0|0|0|0|0|0|0|0|0|0|0|0');

-- --------------------------------------------------------

--
-- Table structure for table `furnobject`
--

CREATE TABLE `furnobject` (
  `id` int(10) UNSIGNED NOT NULL,
  `model` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `rx` float NOT NULL,
  `ry` float NOT NULL,
  `rz` float NOT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `stock` int(10) UNSIGNED NOT NULL,
  `storeid` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `materials` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `furnobject`
--

INSERT INTO `furnobject` (`id`, `model`, `name`, `x`, `y`, `z`, `rx`, `ry`, `rz`, `price`, `stock`, `storeid`, `materials`) VALUES
(571, 2575, 'Modern Bed Set', 1466.3, 1781.45, 10.295, 0, 0, 89.999, 150, 20, 1, '463|8704|0|0|0|0|0|0|0|0|0|0|0|0'),
(572, 1797, 'Roundless Bed', 1467.31, 1785.34, 9.895, 0, 0, 89.999, 125, 20, 1, '463|8702|8704|0|0|0|0|0|0|0|0|0|'),
(577, 2576, 'Darktone Cabinet', 1464.28, 1788.41, 9.906, 0, 0, 90, 125, 20, 1, '8704|8698|8698|0|0|0|0|0|0|0|0|0'),
(578, 2067, 'Light Wood Rack', 1464.3, 1792.43, 9.885, 0, 0, 90.097, 125, 20, 1, '229|455|455|455|455|455|0|0|0|0|'),
(579, 2108, 'Wood Stand Lamp', 1464.16, 1793.48, 9.916, 0, 0, 0, 125, 20, 1, '463|1067|1310|0|0|0|0|0|0|0|0|0|'),
(580, 2069, 'Wood Frame Lamp', 1464.17, 1794.4, 9.965, 0, 0, 0, 125, 20, 1, '463|1067|0|0|0|0|0|0|0|0|0|0|0|0'),
(581, 2815, 'Long Mirror', 1466.45, 1795.31, 10.93, -0.398, -89.999, 89.999, 125, 20, 1, '220|0|0|0|0|0|0|0|0|0|0|0|0|0|0|'),
(582, 11737, 'Square Mirror', 1467.19, 1795.31, 11.423, 0, -89.899, 89.999, 125, 20, 1, '220|5266|0|0|0|0|0|0|8273|0|42|0'),
(584, 1753, 'Long Soft Sofa', 1468.68, 1794.76, 9.895, 0, 0, 0, 150, 20, 1, '229|4118|4118|4118|4118|4118|0|0'),
(585, 1713, 'Satin Long Sofa', 1471.9, 1794.76, 9.895, 0, 0, 0, 125, 20, 1, '455|1067|463|0|0|0|0|0|0|0|0|0|0'),
(586, 1754, 'Single Long Sofa', 1470.67, 1793.75, 9.895, 0, 0, -90, 125, 20, 1, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|'),
(587, 2293, 'Unrest Long Sofa', 1470.67, 1792.74, 9.895, 0, 0, 0, 125, 20, 1, '229|0|0|0|0|0|0|0|0|0|0|0|0|0|0|'),
(588, 1708, 'Single Long Sofa', 1474.58, 1794, 9.885, 0, 0, -90.097, 125, 20, 1, '455|1067|463|0|0|0|0|0|0|0|0|0|0'),
(589, 2632, 'Marble Carpet', 1468.61, 1793.51, 9.895, 0, 0, 0, 125, 10, 1, '4670|4118|4118|4118|4118|4118|4|'),
(590, 2315, 'Grey Round Table', 1467.69, 1793.48, 9.946, 0, 0, 0, 125, 20, 1, '8704|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(591, 2631, 'Abstract Carpet', 1473.22, 1793.59, 9.885, 0, 0, 0, 125, 20, 1, '7034|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(592, 2311, 'Classic Table', 1471.95, 1793.48, 9.935, 0, 0, 0, 125, 20, 1, '1868|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(624, 19786, 'LCD Tv 32 Inch', 1477.27, 1795.44, 12.036, 0, 0, 0, 150, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(625, 19787, 'LCD Tv 24 Inch', 1479.89, 1795.37, 11.916, 0, 0, 0, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(627, 2514, 'White Toilet', 1481.63, 1794.69, 9.895, 0, 0, 0, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(628, 2516, 'White Bathtub', 1482.61, 1794.88, 9.916, 0, 0, 0, 150, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(629, 2517, 'White Shower', 1483.82, 1792.54, 9.965, 0, 0, 0, 150, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(630, 2523, 'Stand White Sink', 1484.07, 1792, 9.965, 0, 0, -91.194, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(631, 2518, 'White Marble Sink', 1484.06, 1790.63, 10.196, 0, 0, -88.999, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(633, 2332, 'Big White Safe', 1484.09, 1785.47, 10.354, 0, 0, -90.5, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(634, 2229, '\" I \" Speaker', 1479.11, 1795.42, 9.906, 0, 0, 4.8, 125, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(635, 19174, 'Big Map', 1484.48, 1783.19, 12.175, 0, 0, -89.999, 100, 20, 1, '110|0|0|0|0|0|0|0|0|0|0|0|0|0|0|'),
(636, 1808, 'Water Coler', 1484.25, 1784.24, 9.916, 0, 0, -92.097, 130, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(638, 2269, 'Potrait 2', 1484.01, 1778.49, 11.765, 0, 0, -91.899, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(639, 19173, 'Potrait 1', 1484.51, 1780.33, 12.104, 0, 0, -90.097, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(641, 2820, 'Plate', 1482.48, 1767.27, 10.965, 0, 0, -45.395, 100, 20, 1, '463|0|0|0|0|0|0|0|0|0|0|0|0|0|0|'),
(644, 2030, 'Round Table', 1464.7, 1777.08, 10.305, 0, 0, 0, 80, 20, 1, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|'),
(645, 2184, 'Desk', 1465.94, 1773.03, 9.916, 0, 0, 75.194, 200, 20, 1, '0|102|0|0|0|0|0|0|0|0|0|0|0|0|0|'),
(646, 19999, 'Office Chair', 1464.66, 1774.3, 9.895, 0, 0, 83.8, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(647, 11706, 'Trash Bin', 1484.28, 1768.4, 9.885, 0, 0, 90.597, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(648, 11707, 'Towel Hanging', 1483.08, 1795.24, 10.965, 0, 0, 0, 125, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(649, 2123, 'White Chair', 1464.83, 1776.16, 10.484, 0, 0, -95, 125, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(685, 2151, 'Kitchen 2', 1482.67, 1766.97, 9.906, 0, 0, 179.8, 125, 20, 1, '455|463|455|463|463|463|463|463|'),
(691, 2272, 'Potrait 7', 1483.99, 1773.1, 11.616, 0, 0, -89.799, 100, 20, 1, '463|528|0|0|0|0|0|0|0|0|0|0|0|0|'),
(692, 2263, 'Potrait 4', 1484.01, 1776.44, 11.746, 0, 0, -90.194, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(693, 2284, 'Potrait 5', 1484, 1775.44, 11.685, 0, 0, -90, 100, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(709, 2160, 'Kitchen Faucet', 1481.29, 1766.97, 9.895, 0, 0, -179.899, 125, 20, 1, '463|463|463|455|455|455|455|0|0|'),
(724, 2135, 'Kitchen Stove', 1479.94, 1767.16, 9.786, 0, 0, 180, 125, 20, 1, '97|463|455|463|463|463|0|0|0|0|0'),
(730, 2147, 'Fridge', 1478.93, 1767.17, 9.776, 0, 0, 179.5, 150, 20, 1, '1052|5708|5708|8273|138|10|10|1|'),
(750, 2149, 'Microwave', 1483.91, 1769.98, 11.126, 0, 0, -91.5, 125, 20, 1, '5708|5708|5708|5708|5708|5708|5|'),
(763, 2230, 'Air Conditioner', 1463.62, 1783.84, 12.425, 1.7, -90.097, 89.8, 200, 20, 1, '995|455|463|631|631|455|268|268|'),
(824, 2357, 'Long Marble Table', 1476.29, 1781.98, 10.345, 0, 0, 92.399, 125, 21, 1, '1339|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(848, 1828, 'Tiger Skin', 1465.98, 1779.42, 9.895, 0, 0, 0, 125, 20, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0'),
(930, 1742, 'Wine rak', 1476.99, 1766.51, 10.906, 0, 0, 179.8, 200, 30, 1, '2709|2709|335|0|0|0|0|0|0|0|0|0|'),
(1082, 2103, 'RADIO', 1474.61, 1787.35, 11.545, 0, 0, 0, 1000, 10, 1, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0');

-- --------------------------------------------------------

--
-- Table structure for table `furnstore`
--

CREATE TABLE `furnstore` (
  `id` int(10) UNSIGNED NOT NULL,
  `ownername` varchar(24) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `i_x` float NOT NULL,
  `i_y` float NOT NULL,
  `i_z` float NOT NULL,
  `owner` int(10) UNSIGNED NOT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `vault` int(11) NOT NULL,
  `employe1` tinyint(4) NOT NULL,
  `employe2` tinyint(4) NOT NULL,
  `employe3` tinyint(4) NOT NULL,
  `seal` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `furnstore`
--

INSERT INTO `furnstore` (`id`, `ownername`, `name`, `x`, `y`, `z`, `i_x`, `i_y`, `i_z`, `owner`, `price`, `vault`, `employe1`, `employe2`, `employe3`, `seal`) VALUES
(1, 'Daniel_Pitcher', '{00FFFF}Syntage Furniture', 1284.4, -1585.4, 13.5, 1464.3, 1768, 10.8, 5, 6500000, 7675, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `garbage`
--

CREATE TABLE `garbage` (
  `garbageID` int(11) NOT NULL,
  `garbageModel` int(11) DEFAULT 1236,
  `garbageCapacity` int(11) NOT NULL DEFAULT 0,
  `garbageX` float NOT NULL DEFAULT 0,
  `garbageY` float NOT NULL DEFAULT 0,
  `garbageZ` float NOT NULL DEFAULT 0,
  `garbageA` float NOT NULL DEFAULT 0,
  `garbageInterior` int(11) NOT NULL DEFAULT 0,
  `garbageWorld` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gates`
--

CREATE TABLE `gates` (
  `ID` int(11) NOT NULL,
  `model` int(11) NOT NULL DEFAULT 0,
  `password` varchar(36) NOT NULL DEFAULT '',
  `admin` tinyint(4) NOT NULL DEFAULT 0,
  `vip` tinyint(4) NOT NULL DEFAULT 0,
  `faction` tinyint(4) NOT NULL DEFAULT 0,
  `family` int(11) NOT NULL DEFAULT -1,
  `speed` float NOT NULL DEFAULT 2,
  `cX` float NOT NULL,
  `cY` float NOT NULL,
  `cZ` float NOT NULL,
  `cRX` float NOT NULL,
  `cRY` float NOT NULL,
  `cRZ` float NOT NULL,
  `oX` float NOT NULL,
  `oY` float NOT NULL,
  `oZ` float NOT NULL,
  `oRX` float NOT NULL,
  `oRY` float NOT NULL,
  `oRZ` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `gstations`
--

CREATE TABLE `gstations` (
  `id` int(11) NOT NULL DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 10000,
  `posx` float DEFAULT 0,
  `posy` float DEFAULT 0,
  `posz` float DEFAULT 0,
  `posrx` float DEFAULT 0,
  `posry` float DEFAULT 0,
  `posrz` float DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=FIXED;

-- --------------------------------------------------------

--
-- Table structure for table `gymobjects`
--

CREATE TABLE `gymobjects` (
  `ID` int(11) NOT NULL,
  `BizID` int(11) NOT NULL DEFAULT 0,
  `Model` int(11) NOT NULL DEFAULT 0,
  `Int` int(11) NOT NULL,
  `Vw` int(11) NOT NULL,
  `Position` varchar(64) NOT NULL DEFAULT '0.00|0.00|0.00',
  `Rotation` varchar(64) NOT NULL DEFAULT '0.00|0.00|0.00',
  `Type` int(11) NOT NULL DEFAULT 0,
  `Condition` int(11) NOT NULL DEFAULT 5000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `houses`
--

CREATE TABLE `houses` (
  `ID` int(11) NOT NULL,
  `owner` varchar(50) NOT NULL DEFAULT '-',
  `address` varchar(50) DEFAULT 'None',
  `price` int(11) NOT NULL DEFAULT 500000,
  `type` int(11) NOT NULL DEFAULT 1,
  `locked` int(11) NOT NULL DEFAULT 1,
  `money` int(11) NOT NULL DEFAULT 0,
  `crack` int(11) NOT NULL DEFAULT 0,
  `pot` int(11) NOT NULL DEFAULT 0,
  `houseint` int(11) NOT NULL DEFAULT 0,
  `extvw` int(11) NOT NULL DEFAULT 0,
  `extint` int(11) NOT NULL DEFAULT 0,
  `extposx` float NOT NULL DEFAULT 0,
  `extposy` float NOT NULL DEFAULT 0,
  `extposz` float NOT NULL DEFAULT 0,
  `extposa` float NOT NULL DEFAULT 0,
  `intposx` float NOT NULL DEFAULT 0,
  `intposy` float NOT NULL DEFAULT 0,
  `intposz` float NOT NULL DEFAULT 0,
  `intposa` float NOT NULL DEFAULT 0,
  `visit` bigint(16) DEFAULT 0,
  `garage` int(11) NOT NULL DEFAULT 0,
  `garageposx` float NOT NULL DEFAULT 0,
  `garageposy` float NOT NULL DEFAULT 0,
  `garageposz` float NOT NULL DEFAULT 0,
  `houseBuilder` int(11) NOT NULL DEFAULT 0,
  `houseBuilderTime` int(11) NOT NULL DEFAULT 0,
  `houseWeapon1` int(12) DEFAULT 0,
  `houseAmmo1` int(12) DEFAULT 0,
  `houseWeapon2` int(12) DEFAULT 0,
  `houseAmmo2` int(12) DEFAULT 0,
  `houseWeapon3` int(12) DEFAULT 0,
  `houseAmmo3` int(12) DEFAULT 0,
  `houseWeapon4` int(12) DEFAULT 0,
  `houseAmmo4` int(12) DEFAULT 0,
  `houseWeapon5` int(12) DEFAULT 0,
  `houseAmmo5` int(12) DEFAULT 0,
  `houseWeapon6` int(12) DEFAULT 0,
  `houseAmmo6` int(12) DEFAULT 0,
  `houseWeapon7` int(12) DEFAULT 0,
  `houseAmmo7` int(12) DEFAULT 0,
  `houseWeapon8` int(12) DEFAULT 0,
  `houseAmmo8` int(12) DEFAULT 0,
  `houseWeapon9` int(12) DEFAULT 0,
  `houseAmmo9` int(12) DEFAULT 0,
  `houseWeapon10` int(12) DEFAULT 0,
  `houseAmmo10` int(12) DEFAULT 0,
  `houseAmmoType` varchar(52) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0|0|0|0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `housestruct`
--

CREATE TABLE `housestruct` (
  `ID` int(11) NOT NULL,
  `HouseID` int(11) NOT NULL DEFAULT 0,
  `Model` int(11) NOT NULL DEFAULT 0,
  `PosX` float NOT NULL,
  `PosY` float NOT NULL,
  `PosZ` float NOT NULL,
  `RotX` float NOT NULL,
  `RotY` float NOT NULL,
  `RotZ` float NOT NULL,
  `Material` int(11) NOT NULL DEFAULT 0,
  `Color` int(11) NOT NULL DEFAULT 0,
  `Type` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jailrecord`
--

CREATE TABLE `jailrecord` (
  `id` int(12) NOT NULL,
  `owner` int(12) NOT NULL DEFAULT 0,
  `admin` varchar(32) NOT NULL,
  `reason` varchar(64) NOT NULL,
  `time` int(8) NOT NULL DEFAULT 0,
  `date` varchar(40) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ladang`
--

CREATE TABLE `ladang` (
  `ID` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'None',
  `owner` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'None',
  `price` int(11) NOT NULL DEFAULT 99999999,
  `extposx` float DEFAULT 0,
  `extposy` float DEFAULT 0,
  `extposz` float DEFAULT 0,
  `safex` float DEFAULT 0,
  `safey` float DEFAULT 0,
  `safez` float DEFAULT 0,
  `product` int(11) NOT NULL DEFAULT 0,
  `white` int(11) NOT NULL DEFAULT 0,
  `orange` int(11) NOT NULL DEFAULT 0,
  `pegawai1` varchar(24) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `pegawai2` varchar(24) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `pegawai3` varchar(24) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lemari`
--

CREATE TABLE `lemari` (
  `id` int(11) NOT NULL,
  `posx` float NOT NULL,
  `posy` float NOT NULL,
  `posz` float NOT NULL,
  `interior` int(11) NOT NULL DEFAULT 0,
  `world` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lemari`
--

INSERT INTO `lemari` (`id`, `posx`, `posy`, `posz`, `interior`, `world`) VALUES
(0, 199.038, -162.864, 1000.52, 14, 8),
(1, 199.063, -162.961, 1000.52, 14, 9),
(2, 199.59, -162.923, 1000.52, 14, 15),
(3, -402.542, -1379.63, 23.8143, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lockers`
--

CREATE TABLE `lockers` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT 0,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `interior` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=FIXED;

--
-- Dumping data for table `lockers`
--

INSERT INTO `lockers` (`id`, `type`, `posx`, `posy`, `posz`, `interior`) VALUES
(0, 1, 1358.07, 755.164, 111.32, 1),
(4, 4, 2848.48, -294.764, 2014.48, 0),
(3, 1, 1577.37, 1603.72, 1003.5, 1),
(5, 3, 1457.62, -1777.92, -20.5291, 1),
(2, 1, 1534.16, -1671.3, 5.89062, 0);

-- --------------------------------------------------------

--
-- Table structure for table `logpay`
--

CREATE TABLE `logpay` (
  `player` varchar(40) NOT NULL DEFAULT 'None',
  `playerid` int(11) NOT NULL DEFAULT 0,
  `toplayer` varchar(40) NOT NULL DEFAULT 'None',
  `toplayerid` int(11) NOT NULL DEFAULT 0,
  `ammount` int(11) NOT NULL DEFAULT 0,
  `time` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `logstaff`
--

CREATE TABLE `logstaff` (
  `command` varchar(50) NOT NULL,
  `admin` varchar(50) NOT NULL,
  `adminid` int(11) NOT NULL,
  `player` varchar(50) NOT NULL DEFAULT '*',
  `playerid` int(11) NOT NULL DEFAULT -1,
  `str` varchar(50) NOT NULL DEFAULT '*',
  `time` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `logstaff`
--

INSERT INTO `logstaff` (`command`, `admin`, `adminid`, `player`, `playerid`, `str`, `time`) VALUES
('SETMONEY', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '3500000', 1686127606),
('SETMONEY', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '3500000', 1686127705),
('SETMONEY', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '5500000', 1686550447),
('SETMONEY', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '55000', 1686550471),
('SETLEADER', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '0', 1686551351),
('SETLEADER', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '0', 1686552253),
('SETLEADER', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '1', 1686552280),
('SETMONEY', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '3500000', 1686559419),
('SETMONEY', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '6500000', 1686559428),
('SETCOMPONENT', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '10000', 1686562241),
('SETCOMPONENT', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '10000', 1686563114),
('SETCOMPONENT', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '10000', 1686565155),
('SETLEADER', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '1', 1686568426),
('SETMONEY', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '6500000', 1686725349),
('SETCOMPONENT', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '121', 1686735460),
('SETCOMPONENT', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '1000', 1686738026),
('SETCOMPONENT', 'Rudi_Salam(himeko)', 3, 'Rudi_Salam', 3, '100', 1686761674),
('SETADMINLEVEL', 'Daniel_Pitcher(None)', 5, 'Kaizo_Diningrat', 4, '6', 1689241169),
('SETLEADER', 'Kaizo_Diningrat(Rulay)', 4, 'Kaizo_Diningrat', 4, '1', 1689257283),
('SETMONEY', 'Kaizo_Diningrat(Rulay)', 4, 'Kaizo_Diningrat', 4, '100000', 1689333457),
('SETMONEY', 'Kaizo_Diningrat(Rulay)', 4, 'Kaizo_Diningrat', 4, '1000000', 1689333711),
('SETMONEY', 'Kaizo_Diningrat(Rulay)', 6, 'Kaizo_Diningrat', 6, '1000000', 1689499484),
('SETLEADER', 'Kaizo_Diningrat(Rulay)', 6, 'Kaizo_Diningrat', 6, '1', 1689510760),
('SETMONEY', 'Kaizo_Diningrat(Rulay)', 6, 'Kaizo_Diningrat', 6, '1000000', 1689741457),
('SETLEADER', 'Kaizo_Diningrat(Rulay)', 6, 'Kaizo_Diningrat', 6, '4', 1690548977),
('SETLEADER', 'Kaizo_Diningrat(Rulay)', 6, 'Kaizo_Diningrat', 6, '3', 1690548979),
('SETLEADER', 'Kaizo_Diningrat(Rulay)', 6, 'Kaizo_Diningrat', 6, '1', 1690550024),
('SETLEADER', 'Kaizo_Diningrat(Rulay)', 6, 'Kaizo_Diningrat', 6, '3', 1690882999),
('SETLEADER', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '1', 1695560956),
('SETMONEY', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '99999900', 1695566542),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Daniel_Pitcher', 5, '1', 1695685735),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Daniel_Pitcher', 5, '3', 1695685920),
('SETADMINLEVEL', 'Benji_Aldrich(GmZ)', 8, 'Nathaniel_Everet', 9, '6', 1695734051),
('SETLEADER', 'Nathaniel_Everet(None)', 9, 'Nathaniel_Everet', 9, '1', 1695734194),
('SETLEADER', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '3', 1695734556),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Daniel_Pitcher', 5, '1', 1695734564),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Daniel_Pitcher', 5, '0', 1695734675),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Benji_Aldrich', 8, '2', 1695734700),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Benji_Aldrich', 8, '2', 1695734734),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Daniel_Pitcher', 5, '1', 1695734825),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Daniel_Pitcher', 5, '3', 1695735340),
('SETFACTION', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '3(1 rank)', 1695735443),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '1', 1695736280),
('SETMONEY', 'Nathaniel_Everet(cvNathan)', 9, 'Synester_Vengeance', 12, '50000', 1695816692),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '3', 1695818976),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Rachelle_Nathalie', 14, '3', 1695819193),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '3', 1695819306),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '1', 1695819326),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '2', 1695819339),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '2', 1695819625),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '4', 1695819631),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '2', 1695819638),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '3', 1695820086),
('SETADMINLEVEL', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '6', 1695820371),
('SETMONEY', 'Nathaniel_Everet(cvNathan)', 9, 'Rachelle_Nathalie', 14, '200000', 1695820481),
('SETMONEY', 'Daniel_Pitcher(MangWann)', 5, 'Daniel_Pitcher', 5, '99999900', 1695836849),
('SETMONEY', 'Daniel_Pitcher(MangWann)', 5, 'Ramos_Stetson', 16, '9000000', 1695846374),
('SETLEADER', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '1', 1695870196),
('SETMONEY', 'Nathaniel_Everet(cvNathan)', 9, 'Jhon_Andreas', 18, '50000', 1695877054),
('SETMONEY', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '12000', 1695878278),
('SETMONEY', 'Nathaniel_Everet(cvNathan)', 9, 'Nathaniel_Everet', 9, '2000000', 1695878499),
('SETMONEY', 'Nathaniel_Everet(cvNathan)', 9, 'Jhon_Andreas', 18, '70000', 1695878549),
('SETLEADER', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '1', 1696051099),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Daniel_Pitcher', 5, '2', 1696065339),
('SETLEADER', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '2', 1696065373),
('SETLEADER', 'Daniel_Pitcher(MangWann)', 5, 'Daniel_Pitcher', 5, '1', 1696065895),
('SETLEADER', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '1', 1696066019),
('SETMONEY', 'Nathaniel_Everet(JakiTulul)', 9, 'Nathaniel_Everet', 9, '0', 1696122519),
('SETMONEY', 'Nathaniel_Everet(JakiTulul)', 9, 'Nathaniel_Everet', 9, '2112423716', 1696122574),
('SETMONEY', 'Nathaniel_Everet(JakiTulul)', 9, 'Nathaniel_Everet', 9, '0', 1696122629),
('SETMONEY', 'Nathaniel_Everet(JakiTulul)', 9, 'Nathaniel_Everet', 9, '1410065408', 1696122707),
('SETMONEY', 'Nathaniel_Everet(LineAdmin)', 9, 'Nathaniel_Everet', 9, '0', 1696123913),
('SETADMINLEVEL', 'Daniel_Pitcher(Valdes)', 5, 'Mylleena_Noelle', 10, '6', 1696143223),
('SETMONEY', 'Mylleena_Noelle(Remora)', 10, 'Mylleena_Noelle', 10, '500000000', 1696145420),
('SETMONEY', 'Mylleena_Noelle(Remora)', 10, 'Mylleena_Noelle', 10, '0', 1696146133),
('SETMONEY', 'Mylleena_Noelle(Remora)', 10, 'Mylleena_Noelle', 10, '50000', 1696146724),
('SETMONEY', 'Mylleena_Noelle(Remora)', 10, 'Mylleena_Noelle', 10, '200000', 1696146770),
('SETMONEY', 'Mylleena_Noelle(Remora)', 10, 'Mylleena_Noelle', 10, '50000', 1696148026),
('SETMONEY', 'Mylleena_Noelle(Remora)', 10, 'Mylleena_Noelle', 10, '5000000', 1696148037),
('SETLEADER', 'Nathaniel_Everet(cvNathan.)', 9, 'Nathaniel_Everet', 9, '1', 1696148498),
('SETFACTION', 'Mylleena_Noelle(Remora)', 10, 'Mylleena_Noelle', 10, '3(6 rank)', 1696148692),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Nathaniel_Everet', 9, '1000000', 1696149020),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Owell_Mendez', 47, '100000', 1696150177),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Owell_Mendez', 47, '150000', 1696150217),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '-1863462912', 1696150849),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '-1474836480', 1696150851),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '1454759936', 1696150862),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Peter_Calhoun', 70, '60000', 1696151166),
('SETMONEY', 'Vanessa_DeLaura(Remora)', 10, 'Vanessa_DeLaura', 10, '0', 1696163438),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '1', 1696165476),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '0', 1696203003),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '50000000', 1696403179),
('SETLEADER', 'Nathaniel_Everet(cvNathan.)', 9, 'Andreas_Loye', 197, '4', 1696411417),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Trey_Swagger', 188, '15000', 1696411841),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Nathaniel_Everet', 9, '1215752192', 1696412150),
('SETMONEY', 'Elena_Victoriaswer(YBEF)', 10, 'Elena_Victoriaswer', 10, '50000', 1696412758),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Nathaniel_Everet', 9, '0', 1696413422),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Nathaniel_Everet', 9, '20000', 1696413491),
('SETLEADER', 'Nathaniel_Everet(cvNathan.)', 9, 'Nathaniel_Everet', 9, '4', 1696419528),
('SETFACTION', 'Elena_Victoriaswer(YBEF)', 10, 'Elena_Victoriaswer', 10, '1(6 rank)', 1696420330),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Nathaniel_Everet', 9, '10000000', 1696421255),
('SETLEADER', 'Nathaniel_Everet(cvNathan.)', 9, 'Nathaniel_Everet', 9, '1', 1696421597),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Timmy_Hemsworth', 19, '100000', 1696422570),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Timmy_Hemsworth', 19, '200000', 1696422665),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Timmy_Hemsworth', 19, '175000', 1696422693),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '3', 1696597108),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '905400', 1696602797),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '99999900', 1696602804),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '0', 1696602814),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '900000000', 1696649581),
('SETCOMPONENT', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '250', 1696660688),
('SETMONEY', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '500000', 1696662539),
('SETMONEY', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '500000', 1696663222),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '0', 1696673784),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Rachelle_Nathalie', 14, '999900', 1696673992),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Rachelle_Nathalie', 14, '100000', 1696674005),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '9999900', 1696674163),
('SETFACTION', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '3(5 rank)', 1696674674),
('SETCOMPONENT', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '900000', 1696683730),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '2', 1696687024),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '1', 1696687350),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '2', 1696687360),
('SETFACTION', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '3(5 rank)', 1696687688),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '99999900', 1696687940),
('SETADMINLEVEL', 'Daniel_Pitcher(Valdes)', 5, 'Timmy_Hemsworth', 19, '3', 1696688781),
('SETMONEY', 'Elena_Victoriaswer(YBEF)', 10, 'Elena_Victoriaswer', 10, '50000', 1696692953),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Purz_Walker', 230, '900000000', 1696771159),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Purz_Walker', 230, '9000000', 1696771162),
('SETADMINLEVEL', 'Nathaniel_Everet(cvNathan.)', 9, 'Elena_Victoriaswer', 10, '4', 1696771408),
('SETADMINLEVEL', 'Nathaniel_Everet(cvNathan.)', 9, 'Elena_Victoriaswer', 10, '1', 1696771420),
('SETADMINLEVEL', 'Nathaniel_Everet(cvNathan.)', 9, 'Elena_Victoriaswer', 10, '6', 1696771481),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Teejay_Anderson', 88, '500000', 1696772020),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Teejay_Anderson', 88, '650000', 1696772028),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Teejay_Anderson', 88, '1100000', 1696772103),
('SETADMINLEVEL', 'Nathaniel_Everet(cvNathan.)', 9, 'Elena_Victoriaswer', 10, '1', 1696772500),
('SETADMINLEVEL', 'Daniel_Pitcher(Valdes)', 5, 'Elena_Victoriaswer', 10, '6', 1696772555),
('SETADMINLEVEL', 'Elena_Victoriaswer(YBEF)', 10, 'Nathaniel_Everet', 9, '1', 1696772567),
('SETADMINLEVEL', 'Elena_Victoriaswer(YBEF)', 10, 'Nathaniel_Everet', 9, '0', 1696772571),
('SETADMINLEVEL', 'Daniel_Pitcher(Valdes)', 5, 'Nathaniel_Everet', 9, '6', 1696772587),
('SETADMINLEVEL', 'Elena_Victoriaswer(YBEF)', 10, 'Nathaniel_Everet', 9, '0', 1696772668),
('SETADMINLEVEL', 'Elena_Victoriaswer(YBEF)', 10, 'Nathaniel_Everet', 9, '6', 1696772681),
('SETADMINLEVEL', 'Daniel_Pitcher(Valdes)', 5, 'Nathaniel_Everet', 9, '6', 1696772682),
('SETHELPERLEVEL', 'Nathaniel_Everet(cvNathan.)', 9, 'Elena_Victoriaswer', 10, '1', 1696772826),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '1', 1696773521),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '4', 1696773526),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '1', 1696774934),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '1', 1696776109),
('SETCOMPONENT', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '9999999', 1696836031),
('SETMONEY', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '20000000', 1696855827),
('SETMONEY', 'Benji_Aldrich(GmZ)', 8, 'Benji_Aldrich', 8, '200000', 1696855930),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Jeremmiah_Lowell', 57, '600000', 1696858919),
('SETADMINLEVEL', 'Nathaniel_Everet(cvNathan.)', 9, 'Rachelle_Nathalie', 14, '1', 1696867750),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Rachelle_Nathalie', 14, '0', 1696867791),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Rachelle_Nathalie', 14, '1500000', 1696867798),
('SETMONEY', 'Nathaniel_Everet(cvNathan.)', 9, 'Rachelle_Nathalie', 14, '2500000', 1696867827),
('SETADMINLEVEL', 'Daniel_Pitcher(Valdes)', 5, 'Rachelle_Nathalie', 14, '6', 1696873538),
('SETADMINLEVEL', 'Rachelle_Nathalie(Dazzle)', 14, 'Daniel_Pitcher', 5, '1', 1696873583),
('SETADMINLEVEL', 'Rachelle_Nathalie(Dazzle)', 14, 'Daniel_Pitcher', 5, '6', 1696873630),
('SETADMINLEVEL', 'Daniel_Pitcher(Valdes)', 5, 'Rachelle_Nathalie', 14, '1', 1696873640),
('SETMATERIAL', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '99999', 1696916399),
('SETFACTION', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '3(5 rank)', 1696919416),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '100000', 1696921370),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '500000', 1696926110),
('SETPASSWORD', 'Nathaniel_Everet(cvNathan.)', 9, '*', -1, 'quin122', 1696941704),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '1', 1696947364),
('SETLEADER', 'Nathaniel_Everet(Mahes.)', 9, 'Nathaniel_Everet', 9, '3', 1697116607),
('SETMONEY', 'Mahes_Ansell(Mahes.)', 9, 'Mahes_Ansell', 9, '200000000', 1697119875),
('SETFACTION', 'Mahes_Ansell(Mahes.)', 9, 'Gifari_Atharazka', 239, '1(3 rank)', 1697120815),
('SETLEADER', 'Mahes_Ansell(Mahes.)', 9, 'Mahes_Ansell', 9, '1', 1697120956),
('SETADMINLEVEL', 'Daniel_Pitcher(Valdes)', 5, 'Timmy_Hemsworth', 19, '6', 1697131295),
('SETADMINLEVEL', 'Daniel_Pitcher(Valdes)', 5, 'Timmy_Hemsworth', 19, '1', 1697132011),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '6500000', 1697132114),
('SETADMINLEVEL', 'Mahes_Ansell(Mahes.)', 9, 'Timmy_Hemsworth', 19, '3', 1697132314),
('SETMONEY', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '6000000', 1697132530),
('SETCOMPONENT', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '99999', 1697132894),
('SETMONEY', 'Mahes_Ansell(Mahes.)', 9, 'Gifari_Atharazka', 239, '50000', 1697189906),
('SETMONEY', 'Mahes_Ansell(Mahes.)', 9, 'Gifari_Atharazka', 239, '50000', 1697190010),
('SETMONEY', 'Mahes_Ansell(Mahes.)', 9, 'Gifari_Atharazka', 239, '500000', 1697190255),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '0', 1697358362),
('SETLEADER', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '1', 1697359370),
('SETCOMPONENT', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '0', 1697360385),
('SETMATERIAL', 'Daniel_Pitcher(Valdes)', 5, 'Daniel_Pitcher', 5, '0', 1697360393),
('SETLEADER', 'Mahes_Ansell(Mahes.)', 9, 'Mahes_Ansell', 9, '3', 1697371455),
('SETADMINLEVEL', 'Daniel_Pitcher(Valldes)', 5, 'Rachelle_Nathalie', 14, '2', 1697459813),
('SETADMINLEVEL', 'Mahes_Ansell(Mahes.)', 9, 'Rachelle_Nathalie', 14, '3', 1697464408),
('SETLEADER', 'Mahes_Ansell(Mahes.)', 9, 'Mahes_Ansell', 9, '1', 1697464570),
('SETMONEY', 'Mahes_Ansell(Mahes.)', 9, 'Andreas_Loye', 197, '1500000', 1697465728),
('SETMONEY', 'Mahes_Ansell(Mahes.)', 9, 'Kaii_Chorvet', 363, '35000', 1697466090),
('SETMONEY', 'Mahes_Ansell(Mahes.)', 9, 'Mahes_Ansell', 9, '2000', 1697468486),
('SETCOMPONENT', 'Daniel_Pitcher(Valldes)', 5, 'Daniel_Pitcher', 5, '99999', 1697517891),
('SETMONEY', 'Daniel_Pitcher(Valldes)', 5, 'Wann_Cheng', 402, '50000000', 1697603097),
('SETMATERIAL', 'Daniel_Pitcher(Valldes)', 5, 'Daniel_Pitcher', 5, '500', 1697654762),
('SETMONEY', 'Daniel_Pitcher(Valldes)', 5, 'Daniel_Pitcher', 5, '700000', 1697655521),
('SETMONEY', 'Daniel_Pitcher(Valldes)', 5, 'Gatra_Simatupang', 419, '700000', 1697655537),
('SETMONEY', 'Daniel_Pitcher(Valldes)', 5, 'Gatra_Simatupang', 419, '0', 1697655594),
('SETADMINLEVEL', 'Daniel_Pitcher(Valldes)', 5, 'Gatra_Simatupang', 419, '4', 1697656208),
('SETMONEY', 'Daniel_Pitcher(Valldes)', 5, 'Gatra_Simatupang', 419, '90000000', 1697656916),
('SETCOMPONENT', 'Daniel_Pitcher(Valldes)', 5, 'Gatra_Simatupang', 419, '250', 1697660270),
('SETCOMPONENT', 'Daniel_Pitcher(Valldes)', 5, 'Daniel_Pitcher', 5, '0', 1697660472),
('SETPASSWORD', 'Daniel_Pitcher(Valldes)', 5, '*', -1, '1234', 1697671458),
('SETPASSWORD', 'Daniel_Pitcher(Valldes)', 5, '*', -1, 'bendica', 1697671667),
('SETPASSWORD', 'Daniel_Pitcher(Valldes)', 5, '*', -1, 'blendica', 1697671683),
('SETADMINLEVEL', 'Alee_Anggur(None)', 1, 'Daniel_Pitcher', 2, '6', 1698350880),
('SETADMINLEVEL', 'Alee_Anggur(None)', 1, 'Alee_Anggur', 1, '6', 1698351438),
('SETADMINLEVEL', 'Alee_Anggur(None)', 1, 'Alee_Anggur', 1, '6', 1698351441),
('SETADMINLEVEL', 'Alee_Anggur(None)', 1, 'Daniel_Pitcher', 2, '6', 1698351443),
('SETADMINLEVEL', 'Daniel_Pitcher(Ansell)', 2, 'Alhard_Romeo', 4, '6', 1698353031),
('SETADMINLEVEL', 'Alee_Anggur(None)', 1, 'Alee_Anggur', 1, '6', 1698353034),
('SETADMINLEVEL', 'Alee_Anggur(None)', 1, 'Daniel_Pitcher', 2, '6', 1698353038),
('SETADMINLEVEL', 'Alee_Anggur(None)', 1, 'Daniel_Pitcher', 2, '6', 1698353039),
('SETADMINLEVEL', 'Alee_Anggur(None)', 1, 'Alhard_Romeo', 4, '6', 1698353041),
('SETLEADER', 'Daniel_Pitcher(Ansell)', 2, 'Daniel_Pitcher', 2, '1', 1698353189),
('SETLEADER', 'Daniel_Pitcher(Ansell)', 2, 'Daniel_Pitcher', 2, '1', 1698353313),
('SETLEADER', 'Daniel_Pitcher(Ansell)', 2, 'Daniel_Pitcher', 2, '0', 1698353317),
('SETLEADER', 'Daniel_Pitcher(Ansell)', 2, 'Daniel_Pitcher', 2, '0', 1698353320),
('SETFACTION', 'Alee_Anggur(None)', 1, 'Daniel_Pitcher', 2, '1(5 rank)', 1698353531),
('SETLEADER', 'Daniel_Pitcher(Ansell)', 2, 'Daniel_Pitcher', 2, '0', 1698353561),
('SETLEADER', 'Daniel_Pitcher(Ansell)', 2, 'Daniel_Pitcher', 2, '1', 1698353574);

-- --------------------------------------------------------

--
-- Table structure for table `maps`
--

CREATE TABLE `maps` (
  `ID` int(11) NOT NULL,
  `Name` varchar(128) DEFAULT NULL,
  `LoadBy` varchar(128) DEFAULT NULL,
  `Int` int(11) NOT NULL DEFAULT 0,
  `Vw` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `maps`
--

INSERT INTO `maps` (`ID`, `Name`, `LoadBy`, `Int`, `Vw`) VALUES
(16, 'R22', '', 1, 1),
(17, 'TEST', '', 1, 1),
(18, 'R22', '', 1, 1),
(19, 'YA', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `objects`
--

CREATE TABLE `objects` (
  `ID` int(11) NOT NULL,
  `Model` int(11) NOT NULL DEFAULT 0,
  `X` float NOT NULL DEFAULT 0,
  `Y` float NOT NULL DEFAULT 0,
  `Z` float NOT NULL DEFAULT 0,
  `RotX` float NOT NULL DEFAULT 0,
  `RotY` float NOT NULL DEFAULT 0,
  `RotZ` float NOT NULL DEFAULT 0,
  `Vw` int(11) NOT NULL DEFAULT 0,
  `Int` int(11) NOT NULL DEFAULT 0,
  `Stream` float NOT NULL DEFAULT 300,
  `Materials` varchar(128) NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0',
  `MatsColor` varchar(128) NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0',
  `MatsText` int(11) NOT NULL DEFAULT 0,
  `MatsTextIndex` int(11) NOT NULL DEFAULT 0,
  `Text` varchar(256) DEFAULT NULL,
  `MatsTextSize` int(11) NOT NULL DEFAULT 0,
  `MatsTextFont` varchar(32) DEFAULT NULL,
  `MatsTextFontSize` int(11) NOT NULL DEFAULT 0,
  `MatsTextBold` int(11) NOT NULL DEFAULT 0,
  `MatsTextColor` int(11) NOT NULL DEFAULT 0,
  `MatsTextBackColor` int(11) NOT NULL DEFAULT 0,
  `MatsTextAlignment` int(11) NOT NULL DEFAULT 0,
  `House` int(11) NOT NULL DEFAULT -1,
  `Business` int(11) NOT NULL DEFAULT -1,
  `Workshop` int(11) NOT NULL DEFAULT -1,
  `Dealership` int(11) NOT NULL DEFAULT -1,
  `Other` int(11) NOT NULL DEFAULT -1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `objects`
--

INSERT INTO `objects` (`ID`, `Model`, `X`, `Y`, `Z`, `RotX`, `RotY`, `RotZ`, `Vw`, `Int`, `Stream`, `Materials`, `MatsColor`, `MatsText`, `MatsTextIndex`, `Text`, `MatsTextSize`, `MatsTextFont`, `MatsTextFontSize`, `MatsTextBold`, `MatsTextColor`, `MatsTextBackColor`, `MatsTextAlignment`, `House`, `Business`, `Workshop`, `Dealership`, `Other`) VALUES
(221, 19598, 2387.05, -1790.09, 15.015, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(222, 19855, 2348.76, -1784.59, 12.5565, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(223, 19854, 2348.75, -1784.59, 12.5565, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(224, 19863, 2366.72, -1776.08, 15.0727, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(225, 19856, 2348.75, -1784.59, 12.5565, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(226, 19857, 2343.93, -1774.73, 14.5341, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(227, 5837, 2376.64, -1764.64, 14.192, 0, 0, 270, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(228, 5837, 2365.91, -1764.47, 14.192, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(229, 19912, 2379.88, -1759.5, 15.3107, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(230, 987, 2403.95, -1759.19, 12.5171, 0, 0, 270, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(231, 987, 2391.91, -1759.14, 12.5231, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(232, 987, 2379.93, -1759.16, 12.5231, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(233, 987, 2356.37, -1759.16, 12.5231, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(234, 987, 2344.42, -1759.16, 12.5231, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(235, 987, 2338.41, -1759.16, 12.5231, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(236, 987, 2338.36, -1771.19, 12.5171, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(237, 987, 2338.36, -1783.13, 12.5171, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(238, 987, 2338.36, -1795.06, 12.5171, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(239, 987, 2338.36, -1806.99, 12.5171, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(240, 987, 2338.36, -1818.92, 12.5171, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(241, 987, 2350.42, -1818.97, 12.5231, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(242, 987, 2362.35, -1818.97, 12.5231, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(243, 987, 2374.28, -1818.97, 12.5231, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(244, 987, 2386.2, -1818.97, 12.5231, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(245, 987, 2398.13, -1818.97, 12.5231, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(246, 987, 2403.95, -1771.12, 12.5171, 0, 0, 270, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(247, 987, 2403.95, -1783.05, 12.5171, 0, 0, 270, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(248, 987, 2403.95, -1794.98, 12.5171, 0, 0, 270, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(249, 987, 2403.95, -1806.91, 12.5171, 0, 0, 270, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(250, 987, 2404.14, -1818.97, 12.5231, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(251, 19786, 2348.7, -1780.43, 15.9691, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(252, 2090, 2348.77, -1785.43, 13.2077, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(253, 1742, 2344.18, -1788.37, 13.2557, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(254, 2205, 2344.81, -1785.34, 13.2557, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(255, 19893, 2344.86, -1784.69, 14.1879, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(256, 11706, 2344.87, -1783.02, 13.2557, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(257, 2738, 2348.33, -1779.88, 13.8261, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(258, 2517, 2343.93, -1779.62, 13.2261, 0, 0, 270, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(259, 2523, 2349.2, -1777.01, 13.2638, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(260, 1738, 2344.79, -1797.28, 13.9038, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(261, 2417, 2344.54, -1789.68, 13.2735, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(262, 2339, 2344.74, -1790.75, 13.2583, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(263, 1808, 2344.65, -1791.65, 13.2506, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(264, 1594, 2347.21, -1794.64, 13.745, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(265, 1594, 2349.96, -1795.42, 13.745, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(266, 1594, 2351.15, -1793.01, 13.745, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(267, 1728, 2364.17, -1793.89, 13.2764, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(268, 19787, 2363.08, -1789.07, 15.4038, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(269, 1728, 2360.21, -1792.51, 13.2764, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(270, 1728, 2365.55, -1790.71, 13.2764, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(271, 2126, 2362.55, -1791.82, 13.2532, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(272, 1502, 2353.56, -1791.05, 13.2786, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(273, 1502, 2353.56, -1782.54, 13.2786, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(274, 1502, 2353.56, -1779.95, 13.2786, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(275, 1502, 2359.22, -1780.44, 13.2786, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(276, 1502, 2359.38, -1785.93, 13.2786, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(277, 19815, 2359.29, -1774.26, 14.0491, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(278, 19899, 2359.75, -1777.36, 12.5331, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(279, 936, 2359.94, -1774.38, 13.0209, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(280, 2957, 2382.49, -1787.79, 14.1964, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(281, 2957, 2382.49, -1782.48, 14.1964, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(282, 714, 2388.08, -1808.28, 10.9168, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(283, 669, 2351.41, -1806.62, 12.8984, 3.14159, -0.03491, -3.14159, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(284, 3651, 2290.27, -1771.01, 15.3867, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(285, 3655, 2317.72, -1777.25, 15.3748, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(286, 3655, 2271.38, -1814.88, 15.44, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(287, 10847, 2247.87, -1801.62, 18.9721, 0, 0, -180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(288, 3517, 2330.94, -1820.36, 23.4199, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(289, 3517, 2319.71, -1823.58, 23.4199, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(290, 3517, 2324.25, -1817.07, 23.4199, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(291, 671, 2329.47, -1802.99, 12.6309, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(292, 673, 2289.52, -1828.99, 12.6309, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(293, 673, 2272.03, -1831.52, 12.6309, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(294, 673, 2252.81, -1834.45, 12.6309, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(295, 673, 2235.09, -1836.57, 12.6309, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(296, 4100, 2326.26, -1759.62, 15.1319, 0, 0, -40, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(297, 4100, 2312.53, -1759.59, 15.1319, 0, 0, -40, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(298, 4100, 2287.81, -1759.59, 15.1319, 0, 0, -40, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(299, 4100, 2274.94, -1759.59, 15.1319, 0, 0, -40, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(300, 4100, 2250.34, -1759.59, 15.1319, 0, 0, -40, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(301, 4100, 2238.66, -1759.59, 15.1319, 0, 0, -40, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(302, 19869, 2231.41, -1762.16, 12.546, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(303, 19869, 2231.41, -1767.33, 12.546, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(304, 19869, 2231.41, -1772.49, 12.546, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(305, 19869, 2231.41, -1777.66, 12.546, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(306, 19869, 2229.6, -1782.15, 12.546, 0, 0, -135, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(307, 19869, 2229.6, -1788.93, 12.546, 0, 0, 135, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(308, 19869, 2231.41, -1793.37, 12.546, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(309, 19869, 2231.41, -1798.54, 12.546, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(310, 19869, 2231.41, -1803.74, 12.546, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(311, 19869, 2231.41, -1808.93, 12.546, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(312, 18762, 2231.92, -1811.95, 13.0615, 0, 90, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(313, 18765, 2237, -1764.94, 10.0669, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(314, 18765, 2237, -1774.92, 10.0669, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(315, 18765, 2247, -1764.94, 10.0669, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(316, 18765, 2246.99, -1774.91, 10.0669, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(317, 19467, 2259.16, -1759.61, 11.9651, -54.978, 180, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(318, 19467, 2265.57, -1759.61, 11.9651, -54.978, 180, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(319, 8041, 2262.41, -1758.34, 18.1806, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(320, 18765, 2262.34, -1764.88, 10.0711, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(321, 18765, 2254.85, -1764.88, 7.5721, 0, 90, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(322, 19467, 2252.18, -1762.13, 11.9851, -54.978, 180, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(323, 19467, 2252.18, -1766.4, 11.9851, -54.978, 180, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(324, 4641, 2252.14, -1770.28, 13.4163, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(325, 3578, 2267.07, -1759.49, 11.7695, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(326, 3578, 2263.44, -1759.49, 11.7695, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(327, 19467, 2262.38, -1759.61, 11.9671, -54.978, 180, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(328, 3578, 2261.31, -1759.49, 11.7695, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(329, 3578, 2257.59, -1759.49, 11.7695, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(330, 19126, 2262.3, -1760.72, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(331, 19126, 2262.3, -1762.26, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(332, 19126, 2261.94, -1763.94, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(333, 19126, 2260.9, -1765.12, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(334, 19126, 2259.26, -1765.17, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(335, 19126, 2257.47, -1765.17, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(336, 3005, 2259.38, -1797.91, 12.5541, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(337, 1334, 2242.5, -1792.01, 13.3264, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(338, 1334, 2247.4, -1792.01, 13.3264, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(339, 19355, 2233.61, -1776.67, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(340, 19355, 2233.61, -1773.34, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(341, 19355, 2233.61, -1769.91, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(342, 19355, 2233.61, -1766.67, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(343, 19355, 2233.61, -1763.05, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(344, 19355, 2250.37, -1776.67, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(345, 19355, 2250.37, -1773.34, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(346, 19355, 2241.74, -1776.67, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(347, 19355, 2241.74, -1773.34, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(348, 19355, 2241.74, -1769.91, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(349, 19355, 2241.74, -1766.67, 10.8225, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(350, 19126, 2253.81, -1769.76, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(351, 19126, 2255.98, -1769.76, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(352, 19126, 2258.53, -1769.76, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(353, 19126, 2261.03, -1769.76, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(354, 19126, 2263.26, -1769.76, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(355, 19126, 2265.61, -1769.76, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(356, 19126, 2267.18, -1768.61, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(357, 19126, 2267.18, -1766.51, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(358, 19126, 2267.18, -1764.4, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(359, 19126, 2267.18, -1762.09, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(360, 19126, 2267.18, -1760.02, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(361, 856, 2283.39, -1820.01, 12.7616, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(362, 19839, 2272.47, -1815.93, 12.5337, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(363, 19839, 2274.33, -1818.24, 12.5337, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(364, 19839, 2272.16, -1823.8, 12.5337, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(365, 19839, 2275.99, -1829.51, 12.5337, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(366, 19839, 2284.47, -1816.36, 12.5337, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(367, 19839, 2282.45, -1818.9, 12.5337, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(368, 19839, 2288.87, -1829.13, 12.5337, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(369, 19869, 2251.98, -1774.67, 12.53, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(370, 19869, 2251.98, -1777.27, 12.53, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(371, 19869, 2249.45, -1779.87, 12.53, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(372, 19869, 2244.18, -1779.87, 12.53, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(373, 19869, 2234.64, -1779.87, 12.53, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(374, 19869, 2239.38, -1779.87, 12.53, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(375, 19126, 2227.6, -1786.94, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(376, 19126, 2227.6, -1784.18, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(377, 19126, 2227.6, -1785.55, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(378, 19126, 2299.62, -1759.41, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(379, 19126, 2302.14, -1759.41, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(380, 19126, 2297.1, -1759.41, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(381, 1280, 2255.67, -1834.07, 12.8025, 0, 0, -80.608, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(382, 1280, 2249.82, -1834.99, 12.8025, 0, 0, -80.608, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(383, 1280, 2237.93, -1836.3, 12.8025, 0, 0, -80.608, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(384, 1280, 2232.21, -1837.17, 12.8025, 0, 0, -80.608, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(385, 16335, 2262.76, -1828.06, -42.7967, 0, 0, -30, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(386, 712, 2331.99, -1761.14, 21.8921, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(387, 712, 2320.82, -1761.14, 21.8921, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(388, 712, 2310.36, -1761.14, 21.8921, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(389, 712, 2288.62, -1761.14, 21.8921, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(390, 712, 2277.18, -1761.14, 21.8921, 356.858, 0, 3.1416, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(391, 19838, 2273.81, -1829.25, 12.5399, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(392, 19126, 2334.8, -1759.41, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(393, 19126, 2338.11, -1759.41, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(394, 19126, 2336.46, -1759.41, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(395, 922, 2236.42, -1794.9, 13.4131, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(396, 922, 2236.42, -1796.45, 13.4131, 0, 0, 5, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(397, 922, 2236.48, -1799.26, 13.4131, 0, 0, 39, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(398, 1558, 2241.81, -1812.3, 13.1139, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(399, 14449, 2306.85, -1776.24, 12.836, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(400, 18236, 2274.64, -1789.49, 12.4024, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(401, 18066, 2278.82, -1786.97, 14.7511, 0, 0, -180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(402, 832, 2256.16, -1775.41, 14.2155, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(403, 837, 2284.31, -1789.78, 12.9835, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(404, 737, 2266.01, -1783.35, 12.9551, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(405, 737, 2266.01, -1770.52, 12.9551, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(406, 640, 2384.98, -1791.94, 13.2264, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(407, 640, 2392.02, -1791.94, 13.2264, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(408, 12940, 2298.62, -1809.97, 16.3697, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(409, 1334, 2299.56, -1808.95, 13.3264, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(410, 1281, 2296.14, -1798.42, 13.3463, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(411, 1281, 2303.01, -1798.42, 13.3463, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(412, 19126, 2303.94, -1759.41, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(413, 19126, 2295.59, -1759.41, 13.027, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(414, 2593, 2344.51, -1772.13, 14.116, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(415, 11707, 2347.17, -1780.29, 14.322, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(416, 2519, 2344.71, -1778.32, 13.2769, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(417, 19873, 2349.02, -1780.19, 13.3384, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(418, 19173, 2359.15, -1782.44, 14.7609, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(419, 19172, 2356.32, -1776.52, 16.7268, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(420, 1661, 2356.3, -1788.92, 17.3718, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(421, 1659, 2356.3, -1788.92, 17.3718, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(422, 19899, 2386.31, -1779.37, 12.5397, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(423, 19815, 2389.68, -1785.81, 13.9561, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(424, 936, 2389.1, -1785.81, 12.9361, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(425, 1502, 2389.54, -1778.74, 12.5646, 0, 0, 180, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(426, 2565, 2384.44, -1775.42, 16.3908, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(427, 2565, 2389.35, -1775.41, 16.3908, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(428, 1742, 2382.48, -1790.59, 15.9531, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(429, 2078, 2390.39, -1789.42, 12.5154, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(430, 19172, 2389.82, -1781.22, 14.4381, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(431, 19786, 2381.48, -1774.29, 14.4069, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(432, 1760, 2384.97, -1773.41, 12.5141, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(433, 1817, 2383.37, -1774.86, 12.5301, 0, 0, 90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(434, 1432, 2392.79, -1773.6, 12.5524, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(435, 19933, 2394.2, -1777.86, 12.9955, 0, 0, 0, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(436, 2136, 2393.96, -1776.03, 12.4165, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0),
(437, 18066, 2265.63, -1789.48, 15.3701, 0, 0, -90, 0, 0, 300, '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0', 0, 0, 'Text Here', 90, 'Arial', 24, 1, -1, -16777216, 0, -1, -1, -1, -1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `parks`
--

CREATE TABLE `parks` (
  `id` int(10) NOT NULL,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `interior` int(11) NOT NULL DEFAULT 0,
  `world` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plants`
--

CREATE TABLE `plants` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT 0,
  `time` int(11) NOT NULL DEFAULT 0,
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=FIXED;

--
-- Dumping data for table `plants`
--

INSERT INTO `plants` (`id`, `type`, `time`, `posx`, `posy`, `posz`) VALUES
(0, 3, 5400, -386.604, -1384.59, 23.0985);

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `reg_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(24) NOT NULL DEFAULT '',
  `adminname` varchar(24) NOT NULL DEFAULT 'None',
  `ucpname` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ip` varchar(24) NOT NULL DEFAULT '',
  `admin` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `helper` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `level` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `levelup` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `cschar` int(11) NOT NULL DEFAULT -1,
  `vip` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `vip_time` int(20) NOT NULL DEFAULT -2,
  `gold` int(11) NOT NULL DEFAULT 0,
  `reg_date` varchar(30) NOT NULL DEFAULT '',
  `last_login` varchar(30) NOT NULL DEFAULT '',
  `money` int(11) NOT NULL DEFAULT 5000,
  `bmoney` int(11) NOT NULL DEFAULT 10000,
  `brek` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `phone` mediumint(8) UNSIGNED NOT NULL,
  `phonecredit` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `wt` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `hours` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `minutes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `paycheck` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `skin` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `facskin` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `gender` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `newp` int(11) NOT NULL DEFAULT 0,
  `age` varchar(30) NOT NULL DEFAULT 'n/a',
  `indoor` mediumint(9) NOT NULL DEFAULT -1,
  `inbiz` mediumint(9) NOT NULL DEFAULT -1,
  `inhouse` mediumint(9) NOT NULL DEFAULT -1,
  `posx` float NOT NULL DEFAULT 1744.34,
  `posy` float NOT NULL DEFAULT -1862.87,
  `posz` float NOT NULL DEFAULT 13.3983,
  `posa` float NOT NULL DEFAULT 270,
  `interior` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `world` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `health` float NOT NULL DEFAULT 100,
  `armour` float NOT NULL DEFAULT 0,
  `hunger` float NOT NULL DEFAULT 100,
  `energy` float NOT NULL DEFAULT 100,
  `sick` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `hospital` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `injured` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `duty` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `dutytime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `faction` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `factionrank` tinyint(3) UNSIGNED NOT NULL DEFAULT 5,
  `factionlead` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `family` tinyint(4) NOT NULL DEFAULT -1,
  `familyrank` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `jail` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `jail_time` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `arrest` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `arrest_time` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `warn` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `job` tinyint(4) UNSIGNED NOT NULL DEFAULT 0,
  `job2` tinyint(4) UNSIGNED NOT NULL DEFAULT 0,
  `exitjob` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxitime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `medicine` mediumint(9) NOT NULL DEFAULT 0,
  `medkit` mediumint(9) NOT NULL DEFAULT 0,
  `mask` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `helmet` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `snack` mediumint(9) NOT NULL DEFAULT 0,
  `sprunk` mediumint(9) NOT NULL DEFAULT 0,
  `gas` mediumint(9) NOT NULL DEFAULT 0,
  `bandage` mediumint(9) NOT NULL DEFAULT 0,
  `gps` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `material` mediumint(9) NOT NULL DEFAULT 0,
  `component` mediumint(9) NOT NULL DEFAULT 0,
  `food` mediumint(9) NOT NULL DEFAULT 0,
  `seedwheat` int(11) NOT NULL DEFAULT 0,
  `seedonion` int(11) NOT NULL DEFAULT 0,
  `seedcarrot` int(11) NOT NULL DEFAULT 0,
  `seedpotato` int(11) NOT NULL DEFAULT 0,
  `seedcorn` int(11) NOT NULL DEFAULT 0,
  `wheat` int(11) NOT NULL DEFAULT 0,
  `onion` int(11) NOT NULL DEFAULT 0,
  `carrot` int(11) NOT NULL DEFAULT 0,
  `potato` int(11) NOT NULL DEFAULT 0,
  `corn` int(11) NOT NULL DEFAULT 0,
  `price1` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `price2` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `price3` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `price4` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `marijuana` mediumint(9) NOT NULL DEFAULT 0,
  `crack` int(11) NOT NULL DEFAULT 0,
  `pot` int(11) NOT NULL DEFAULT 0,
  `plant` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `plant_time` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `fishtool` tinyint(4) NOT NULL DEFAULT 0,
  `fish0` varchar(24) NOT NULL,
  `fish1` varchar(24) NOT NULL,
  `fish2` varchar(24) NOT NULL,
  `fish3` varchar(24) NOT NULL,
  `fish4` varchar(24) NOT NULL,
  `worm` mediumint(9) NOT NULL DEFAULT 0,
  `drivelic` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `drivelic_time` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `flylic` tinyint(3) NOT NULL DEFAULT 0,
  `flylic_time` bigint(20) NOT NULL DEFAULT 0,
  `boatlic` tinyint(3) NOT NULL DEFAULT 0,
  `boatlic_time` bigint(20) NOT NULL DEFAULT 0,
  `gunlic` tinyint(3) NOT NULL DEFAULT 0,
  `gunlic_time` bigint(20) NOT NULL DEFAULT 0,
  `trucker` tinyint(3) NOT NULL DEFAULT 0,
  `trucker_time` bigint(20) NOT NULL DEFAULT 0,
  `lumber` tinyint(3) NOT NULL DEFAULT 0,
  `lumber_time` bigint(20) NOT NULL DEFAULT 0,
  `hbemode` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `togpm` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `toglog` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `togads` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `togwt` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `togradio` tinyint(4) NOT NULL,
  `togpaycheck` int(11) NOT NULL DEFAULT 0,
  `togseatbelt` int(11) NOT NULL DEFAULT 0,
  `togchat` int(11) NOT NULL DEFAULT 0,
  `toghelmet` int(11) NOT NULL DEFAULT 0,
  `togmask` int(11) NOT NULL DEFAULT 0,
  `togammo` int(11) NOT NULL DEFAULT 0,
  `Gun1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun2` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun3` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun4` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun5` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun6` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun7` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun8` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun9` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun10` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun11` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun12` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Gun13` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo2` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo3` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo4` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo5` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo6` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo7` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo8` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo9` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo10` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo11` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo12` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Ammo13` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `AmmoType` varchar(52) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0|0|0|0',
  `pbanned` int(11) NOT NULL,
  `pbanreason` varchar(128) NOT NULL,
  `pbanby` varchar(128) NOT NULL,
  `workshop` tinyint(4) NOT NULL DEFAULT -1,
  `workshoprank` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `rokok` mediumint(9) NOT NULL DEFAULT 0,
  `cgun` mediumint(9) NOT NULL DEFAULT 0,
  `fightstyle` mediumint(11) NOT NULL DEFAULT 0,
  `leveltrucker` mediumint(9) NOT NULL DEFAULT 0,
  `skilltrucker` mediumint(9) NOT NULL DEFAULT 1,
  `married` mediumint(9) NOT NULL DEFAULT 0,
  `marriedto` varchar(50) NOT NULL DEFAULT 'None',
  `paytoll` mediumint(9) NOT NULL DEFAULT 0,
  `levelfishing` int(11) NOT NULL DEFAULT 0,
  `apart` int(11) NOT NULL DEFAULT -1,
  `ladang` tinyint(4) NOT NULL DEFAULT -1,
  `ladangrank` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `maskid` int(11) NOT NULL,
  `wanted` int(11) NOT NULL DEFAULT 0,
  `inapart` mediumint(9) NOT NULL DEFAULT -1,
  `indoorflat` mediumint(9) NOT NULL DEFAULT -1,
  `mutewt` int(11) NOT NULL DEFAULT 0,
  `skillbuilder` int(11) NOT NULL DEFAULT 0,
  `skillmecha` int(11) NOT NULL DEFAULT 0,
  `rentveh` int(11) NOT NULL DEFAULT -1,
  `accent` int(11) NOT NULL DEFAULT 0,
  `furnstore` int(11) NOT NULL DEFAULT -1,
  `GYMMember` varchar(32) NOT NULL DEFAULT '0|0',
  `FitnessRating` varchar(52) NOT NULL DEFAULT '100.00|100.00|100.00|100.00|100.00|100.00	',
  `Cough` varchar(52) NOT NULL DEFAULT '0|0',
  `Fever` varchar(52) NOT NULL DEFAULT '0|0|0',
  `Migrain` varchar(52) NOT NULL DEFAULT '0|0|0|0',
  `UsePills` int(11) NOT NULL DEFAULT 0,
  `Badge` varchar(24) NOT NULL DEFAULT 'None|None',
  `InInt` varchar(52) NOT NULL DEFAULT '0|0|0|0',
  `scoreskill` varchar(52) NOT NULL DEFAULT '0|0|0|0',
  `skilljob` varchar(52) NOT NULL DEFAULT '1|1|1|1',
  `streamer` int(11) NOT NULL DEFAULT 2,
  `claimvip` varchar(52) NOT NULL DEFAULT '0|0|0',
  `schematicgun` varchar(52) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0|0|0|0|0',
  `skillweapon` varchar(52) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0|0|0|0|0',
  `Toggle` varchar(52) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '1|1|1|1',
  `Delay` varchar(52) NOT NULL DEFAULT '1|1|1|1|1|1|1|1|1|1|1|1|1',
  `SkinSlot` varchar(52) NOT NULL DEFAULT '0|0|0|0|0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`reg_id`, `username`, `adminname`, `ucpname`, `ip`, `admin`, `helper`, `level`, `levelup`, `cschar`, `vip`, `vip_time`, `gold`, `reg_date`, `last_login`, `money`, `bmoney`, `brek`, `phone`, `phonecredit`, `wt`, `hours`, `minutes`, `seconds`, `paycheck`, `skin`, `facskin`, `gender`, `newp`, `age`, `indoor`, `inbiz`, `inhouse`, `posx`, `posy`, `posz`, `posa`, `interior`, `world`, `health`, `armour`, `hunger`, `energy`, `sick`, `hospital`, `injured`, `duty`, `dutytime`, `faction`, `factionrank`, `factionlead`, `family`, `familyrank`, `jail`, `jail_time`, `arrest`, `arrest_time`, `warn`, `job`, `job2`, `exitjob`, `taxitime`, `medicine`, `medkit`, `mask`, `helmet`, `snack`, `sprunk`, `gas`, `bandage`, `gps`, `material`, `component`, `food`, `seedwheat`, `seedonion`, `seedcarrot`, `seedpotato`, `seedcorn`, `wheat`, `onion`, `carrot`, `potato`, `corn`, `price1`, `price2`, `price3`, `price4`, `marijuana`, `crack`, `pot`, `plant`, `plant_time`, `fishtool`, `fish0`, `fish1`, `fish2`, `fish3`, `fish4`, `worm`, `drivelic`, `drivelic_time`, `flylic`, `flylic_time`, `boatlic`, `boatlic_time`, `gunlic`, `gunlic_time`, `trucker`, `trucker_time`, `lumber`, `lumber_time`, `hbemode`, `togpm`, `toglog`, `togads`, `togwt`, `togradio`, `togpaycheck`, `togseatbelt`, `togchat`, `toghelmet`, `togmask`, `togammo`, `Gun1`, `Gun2`, `Gun3`, `Gun4`, `Gun5`, `Gun6`, `Gun7`, `Gun8`, `Gun9`, `Gun10`, `Gun11`, `Gun12`, `Gun13`, `Ammo1`, `Ammo2`, `Ammo3`, `Ammo4`, `Ammo5`, `Ammo6`, `Ammo7`, `Ammo8`, `Ammo9`, `Ammo10`, `Ammo11`, `Ammo12`, `Ammo13`, `AmmoType`, `pbanned`, `pbanreason`, `pbanby`, `workshop`, `workshoprank`, `rokok`, `cgun`, `fightstyle`, `leveltrucker`, `skilltrucker`, `married`, `marriedto`, `paytoll`, `levelfishing`, `apart`, `ladang`, `ladangrank`, `maskid`, `wanted`, `inapart`, `indoorflat`, `mutewt`, `skillbuilder`, `skillmecha`, `rentveh`, `accent`, `furnstore`, `GYMMember`, `FitnessRating`, `Cough`, `Fever`, `Migrain`, `UsePills`, `Badge`, `InInt`, `scoreskill`, `skilljob`, `streamer`, `claimvip`, `schematicgun`, `skillweapon`, `Toggle`, `Delay`, `SkinSlot`) VALUES
(1, 'Alee_Anggur', 'None', 'aleew', '255.255.255.255', 6, 0, 1, 0, -1, 0, -2, 0, '', '2023-10-30 14:44:28', 5000, 10000, 604138, 0, 0, 0, 1, 5, 52, 3952, 5, 0, 1, 1, '08/08/1998', -1, -1, -1, -395.26, -1383.89, 23.8565, 210.899, 0, 0, 63, 0, 76.7, 68.8, 0, 0, 0, 0, 0, 1, 5, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '|0.0', '|0.0', '|0.0', '|0.0', '|0.0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0', 0, '', '', -1, 0, 0, 0, 0, 0, 1, 0, 'None', 0, 0, -1, -1, 0, 0, 0, -1, -1, 0, 0, 1, -1, 2, -1, '0|0', '100.000000|100.000000|100.000000|100.000000|100.0000', '0|0', '0|0|0', '3|0|0|0', 0, '|', '-1|-1|-1|-1', '0|0|0|0', '1|1|1|1', 2, '0|0|0', '0|0|0|0|0', '0|0|0|0|0', '0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0'),
(2, 'Daniel_Pitcher', 'Ansell', 'Ansell', '114.124.148.15', 6, 0, 1, 0, 0, 0, 0, 0, '', '2023-10-30 14:44:26', 4220, 10000, 488565, 0, 0, 0, 0, 50, 28, 3028, 2, 300, 1, 1, '09/09/1999', -1, -1, -1, -403.332, -1377.32, 24.1685, 270.439, 0, 0, 99, 0, 87.4, 83.2, 0, 0, 0, 0, 0, 1, 6, 1, -1, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 59, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, '|0.0', '|0.0', '|0.0', '|0.0', '|0.0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|1|0|0|0|0|0|0|0|0|0|0|0', 0, '', '', -1, 0, 0, 0, 0, 0, 1, 0, '', 0, 0, 0, -1, 0, 0, 0, -1, -1, 0, 0, 1, -1, 0, 0, '0|0', '100.000000|100.000000|100.000000|100.000000|100.0000', '0|0', '0|0|0', '9|0|0|0', 0, '|', '-1|-1|-1|-1', '0|0|0|0', '1|1|1|1', 2, '0|0|0', '0|0|0|0|0', '0|0|0|0|0', '1|1|0|1', '0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0'),
(4, 'Alhard_Romeo', 'AlhardGanteng', 'Alhard', '103.165.157.115', 6, 0, 1, 0, 0, 0, 0, 0, '', '2023-10-27 04:03:12', 5000, 5000, 431418, 0, 0, 0, 0, 29, 30, 1770, 62, 0, 1, 1, '18/02/2000', -1, -1, -1, -383.837, -1388.88, 23.1397, 290.999, 0, 0, 103, 0, 90.2, 86.8, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '|0.0', '|0.0', '|0.0', '|0.0', '|0.0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 475, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0|0|0|0|0|0', 0, '', '', -1, 0, 0, 0, 0, 0, 1, 0, '', 0, 0, 0, -1, 0, 0, 0, -1, -1, 0, 0, 1, -1, 18, 0, '0|0', '100.000000|100.000000|100.000000|100.000000|100.0000', '0|0', '0|0|0', '11|0|0|0', 0, '|', '-1|-1|-1|-1', '0|0|0|0', '1|1|1|1', 3, '0|0|0', '0|0|0|0|0', '0|0|0|0|0', '0|0|0|0', '0|0|0|0|0|0|0|0|0|0|0|0|0', '0|0|0|0|0');

-- --------------------------------------------------------

--
-- Table structure for table `privategarage`
--

CREATE TABLE `privategarage` (
  `ID` int(11) NOT NULL,
  `owner` varchar(52) NOT NULL DEFAULT '-',
  `price` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `garagepos` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00|0.00',
  `textpos` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00|0.00	',
  `gatepos` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00|0.00	'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `removebuild`
--

CREATE TABLE `removebuild` (
  `ID` int(11) NOT NULL,
  `RemoveModel` int(11) NOT NULL DEFAULT 0,
  `RemoveOther` int(11) NOT NULL DEFAULT 0,
  `RemovePos` varchar(128) NOT NULL DEFAULT '0.0|0.0|0.0|'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `removebuild`
--

INSERT INTO `removebuild` (`ID`, `RemoveModel`, `RemoveOther`, `RemovePos`) VALUES
(95, 3695, 0, '2239.929687|-1790.695312|17.007799'),
(96, 3695, 0, '2282.992187|-1790.695312|17.007799'),
(97, 3695, 0, '2314.820312|-1790.695312|17.007799'),
(98, 3695, 0, '2352.718750|-1790.695312|17.007799'),
(99, 3695, 0, '2387.820312|-1790.695312|17.007799'),
(100, 1408, 0, '2229.046875|-1810.031250|13.156299'),
(101, 1408, 0, '2226.164062|-1807.328125|13.156299'),
(102, 1408, 0, '2226.164062|-1801.867187|13.156299'),
(103, 620, 0, '2230.414062|-1815.148437|11.343799'),
(104, 620, 0, '2234.484375|-1817.929687|12.093799'),
(105, 1408, 0, '2226.164062|-1791.000000|13.156299'),
(106, 1408, 0, '2226.164062|-1796.453125|13.156299'),
(107, 3584, 0, '2239.929687|-1790.695312|17.007799'),
(108, 1408, 0, '2226.164062|-1775.507812|13.156299'),
(109, 1408, 0, '2226.164062|-1780.984375|13.156299'),
(110, 1408, 0, '2228.671875|-1767.273437|13.156299'),
(111, 1408, 0, '2226.164062|-1770.046875|13.156299'),
(112, 1307, 0, '2232.515625|-1766.054687|12.750000'),
(113, 1307, 0, '2249.867187|-1815.414062|12.750000'),
(114, 669, 0, '2254.726562|-1827.437500|12.562500'),
(115, 1226, 0, '2259.945312|-1796.070312|16.421899'),
(116, 620, 0, '2258.343750|-1804.742187|12.093799'),
(117, 645, 0, '2259.265625|-1773.242187|11.125000'),
(118, 17886, 0, '2264.039062|-1789.257812|20.773399'),
(119, 1408, 0, '2265.296875|-1791.000000|13.156299'),
(120, 1408, 0, '2265.296875|-1796.453125|13.156299'),
(121, 1408, 0, '2265.296875|-1807.328125|13.156299'),
(122, 1408, 0, '2265.296875|-1801.867187|13.156299'),
(123, 1408, 0, '2265.296875|-1770.046875|13.156299'),
(124, 1408, 0, '2265.296875|-1775.507812|13.156299'),
(125, 1408, 0, '2265.296875|-1780.984375|13.156299'),
(126, 620, 0, '2275.390625|-1820.726562|12.093799'),
(127, 1408, 0, '2268.187500|-1810.031250|13.156299'),
(128, 1408, 0, '2273.695312|-1810.031250|13.156299'),
(129, 3584, 0, '2282.992187|-1790.695312|17.007799'),
(130, 1408, 0, '2267.812500|-1767.273437|13.156299'),
(131, 1408, 0, '2273.335937|-1767.343750|13.156299'),
(132, 620, 0, '2271.648437|-1772.398437|8.351599'),
(133, 1307, 0, '2263.523437|-1742.195312|12.750000'),
(134, 645, 0, '2285.757812|-1762.125000|12.289099'),
(135, 1226, 0, '2297.898437|-1793.820312|16.421899'),
(136, 620, 0, '2297.382812|-1798.539062|8.351599'),
(137, 1307, 0, '2293.625000|-1760.617187|12.750000'),
(138, 620, 0, '2297.148437|-1775.875000|8.351599'),
(139, 1408, 0, '2305.062500|-1810.031250|13.156299'),
(140, 1408, 0, '2302.171875|-1807.328125|13.156299'),
(141, 1408, 0, '2302.171875|-1801.867187|13.156299'),
(142, 1408, 0, '2302.171875|-1791.000000|13.156299'),
(143, 1408, 0, '2302.171875|-1796.453125|13.156299'),
(144, 3584, 0, '2314.820312|-1790.695312|17.007799'),
(145, 1408, 0, '2302.171875|-1775.507812|13.156299'),
(146, 1408, 0, '2302.171875|-1770.046875|13.156299'),
(147, 1408, 0, '2302.171875|-1780.984375|13.156299'),
(148, 1408, 0, '2304.781250|-1767.382812|13.156299'),
(149, 1307, 0, '2322.648437|-1815.414062|12.750000'),
(150, 645, 0, '2332.828125|-1817.710937|12.117199'),
(151, 1408, 0, '2341.757812|-1810.031250|13.156299'),
(152, 1408, 0, '2338.867187|-1807.328125|13.156299'),
(153, 620, 0, '2341.757812|-1817.726562|8.359399'),
(154, 1408, 0, '2338.867187|-1801.867187|13.156299'),
(155, 1226, 0, '2335.648437|-1796.632812|16.421899'),
(156, 1408, 0, '2338.867187|-1791.000000|13.156299'),
(157, 1408, 0, '2338.867187|-1796.453125|13.156299'),
(158, 620, 0, '2334.710937|-1785.062500|12.093799'),
(159, 1408, 0, '2338.867187|-1775.507812|13.156299'),
(160, 1408, 0, '2338.867187|-1780.984375|13.156299'),
(161, 17887, 0, '2343.609375|-1784.507812|20.312500'),
(162, 1408, 0, '2338.867187|-1770.046875|13.156299'),
(163, 1408, 0, '2341.382812|-1767.273437|13.156299'),
(164, 669, 0, '2329.187500|-1765.523437|12.437500'),
(165, 673, 0, '2349.617187|-1763.343750|11.632800'),
(166, 1307, 0, '2295.703125|-1742.195312|12.750000'),
(167, 1307, 0, '2331.265625|-1742.414062|12.750000'),
(168, 3584, 0, '2352.718750|-1790.695312|17.007799'),
(169, 620, 0, '2367.648437|-1802.796875|8.359399'),
(170, 1307, 0, '2364.250000|-1742.117187|12.750000'),
(171, 620, 0, '2367.648437|-1780.773437|11.046899'),
(172, 620, 0, '2378.335937|-1818.726562|8.359399'),
(173, 1408, 0, '2374.101562|-1800.468750|13.156299'),
(174, 1408, 0, '2374.101562|-1805.929687|13.156299'),
(175, 1408, 0, '2376.992187|-1813.929687|13.156299'),
(176, 1408, 0, '2374.101562|-1811.382812|13.156299'),
(177, 1408, 0, '2374.101562|-1780.984375|13.156299'),
(178, 1408, 0, '2374.101562|-1789.601562|13.156299'),
(179, 1408, 0, '2374.101562|-1795.054687|13.156299'),
(180, 1408, 0, '2376.617187|-1767.273437|13.156299'),
(181, 1408, 0, '2374.101562|-1770.046875|13.156299'),
(182, 1408, 0, '2374.101562|-1775.507812|13.156299'),
(183, 645, 0, '2399.976562|-1815.992187|11.890600'),
(184, 3584, 0, '2387.820312|-1790.695312|17.007799'),
(185, 673, 0, '2398.578125|-1782.773437|10.703100'),
(186, 645, 0, '2387.023437|-1763.640625|12.179699'),
(187, 1307, 0, '2403.289062|-1741.742187|12.750000'),
(188, 17518, 0, '2361.937500|-1699.937500|15.921899');

-- --------------------------------------------------------

--
-- Table structure for table `rentplayer`
--

CREATE TABLE `rentplayer` (
  `rID` int(11) NOT NULL,
  `rX` float NOT NULL,
  `rY` float NOT NULL,
  `rZ` float NOT NULL,
  `rRX` float NOT NULL,
  `rRY` float NOT NULL,
  `rRZ` float NOT NULL,
  `rRA` float NOT NULL,
  `rType` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=FIXED;

--
-- Dumping data for table `rentplayer`
--

INSERT INTO `rentplayer` (`rID`, `rX`, `rY`, `rZ`, `rRX`, `rRY`, `rRZ`, `rRA`, `rType`) VALUES
(0, 1739.19, -1850.97, 13.4141, 1743.13, -1846.8, 13.5787, 173.56, 1),
(2, 2939.4, -2051.51, 3.54804, 2971.23, -2062.68, -0.643707, 173.658, 3);

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` bigint(20) NOT NULL,
  `owner` int(11) DEFAULT 0,
  `info` varchar(46) DEFAULT '',
  `reason` varchar(46) DEFAULT '',
  `money` int(11) NOT NULL DEFAULT 0,
  `date` varchar(36) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `owner`, `info`, `reason`, `money`, `date`) VALUES
(1, 3, 'San Andreas Express', 'Delivered  packages', 0, '2023-06-05 13:02:30'),
(2, 3, 'San Andreas Express', 'Delivered  packages', 0, '2023-06-05 13:07:43'),
(3, 3, 'San Andreas Express', 'Delivered  packages', 0, '2023-06-05 13:11:42'),
(4, 3, 'San Andreas Express', 'Delivered  packages', 0, '2023-06-05 13:14:46'),
(5, 3, 'San Andreas Express', 'Delivered  packages', 0, '2023-06-05 13:16:59'),
(6, 3, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-06-05 13:44:00'),
(7, 3, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-06-05 13:58:29'),
(8, 3, 'Public Service (Trashmaster)', 'Cleared 10 trash dumps', 150000, '2023-06-05 15:57:25'),
(9, 3, 'Public Service (Trashmaster)', 'Cleared 10 trash dumps', 15000, '2023-06-05 16:02:09'),
(10, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-06-11 15:43:32'),
(11, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-06-12 15:58:16'),
(12, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-06-14 19:27:07'),
(13, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-06-24 13:10:24'),
(14, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-07-13 02:29:24'),
(15, 4, 'Public Service (Trashmaster)', 'Cleared 10 trash dumps', 15000, '2023-07-13 18:48:56'),
(16, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-24 08:15:39'),
(400, 288, 'San Andreas Express', 'Delivered  packages', 15000, '2023-10-16 13:03:31'),
(18, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-26 13:10:50'),
(19, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-26 13:13:41'),
(20, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-27 11:17:42'),
(21, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-27 19:43:07'),
(22, 16, 'San Andreas Express', 'Delivered  packages', 25000, '2023-09-27 20:00:29'),
(23, 16, 'San Andreas Express', 'Delivered  packages', 225000, '2023-09-27 20:12:23'),
(459, 374, 'Public Service (Trashmaster)', 'Cleared 7 trash dumps', 105000, '2023-10-19 12:17:54'),
(458, 189, 'San Andreas Express', 'Delivered  packages', 20000, '2023-10-19 05:33:23'),
(26, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 05:06:08'),
(27, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 05:40:38'),
(28, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 05:56:55'),
(29, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 05:58:18'),
(30, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 05:58:49'),
(31, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 06:22:23'),
(32, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 06:22:23'),
(33, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 06:22:31'),
(34, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 09:11:48'),
(35, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 09:24:25'),
(36, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 23:54:16'),
(37, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-09-30 23:54:39'),
(402, 292, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-16 13:21:05'),
(40, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 01:04:16'),
(401, 292, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-16 13:09:03'),
(399, 109, 'San Andreas Express', 'Delivered  packages', 7500, '2023-10-16 12:47:20'),
(43, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 03:25:30'),
(44, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 04:04:22'),
(45, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 05:17:37'),
(46, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 06:13:09'),
(47, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 06:23:15'),
(48, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:04:18'),
(49, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:05:06'),
(50, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:05:17'),
(51, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:05:18'),
(52, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:05:36'),
(53, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:06:03'),
(54, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:06:57'),
(55, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:08:20'),
(56, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:08:49'),
(57, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:09:16'),
(58, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:13:03'),
(59, 31, 'San Andreas Express', 'Delivered  packages', 150000, '2023-10-01 07:13:48'),
(60, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:18:11'),
(61, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:18:48'),
(62, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:27:01'),
(63, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:27:11'),
(64, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:29:27'),
(65, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 07:32:40'),
(68, 53, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-01 08:24:51'),
(69, 62, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-01 08:47:44'),
(70, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 08:50:11'),
(71, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 08:50:12'),
(457, 174, 'San Andreas Express', 'Delivered  packages', 22500, '2023-10-19 05:30:11'),
(73, 60, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-01 09:00:11'),
(74, 67, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-01 09:07:02'),
(75, 70, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-01 09:50:46'),
(76, 30, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 10:37:03'),
(77, 30, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 10:37:04'),
(332, 174, 'Trucking Co.', 'Delivered 7 fish crates', 8750, '2023-10-14 08:27:30'),
(81, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 11:46:53'),
(82, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 11:47:00'),
(83, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 11:49:47'),
(84, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 11:50:52'),
(389, 339, 'San Andreas Express', 'Delivered  packages', 20000, '2023-10-16 09:02:39'),
(88, 65, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 11:57:54'),
(89, 65, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 11:57:55'),
(390, 111, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-16 09:47:56'),
(91, 82, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-01 12:12:57'),
(92, 30, 'San Andreas Express', 'Delivered  packages', 25000, '2023-10-01 12:13:02'),
(387, 306, 'Farmer Storage Co', 'Sold 127 units of onion', 508, '2023-10-16 08:50:54'),
(94, 67, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-01 12:18:07'),
(95, 82, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-01 12:18:29'),
(96, 26, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-01 12:23:20'),
(97, 93, 'San Andreas Express', 'Delivered  packages', 225000, '2023-10-01 12:23:29'),
(99, 91, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-01 12:24:27'),
(100, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:25:46'),
(101, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:25:49'),
(386, 306, 'Farmer Storage Co', 'Sold 151 units of onion', 604, '2023-10-16 08:47:35'),
(103, 95, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:35:46'),
(104, 95, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:35:47'),
(437, 400, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-17 17:37:35'),
(418, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-17 07:49:08'),
(416, 174, 'Trucking Co.', 'Delivered 10 component crates', 12500, '2023-10-17 07:02:57'),
(278, 8, 'Public Service (Trashmaster)', 'Cleared 10 trash dumps', 15000, '2023-10-07 09:37:59'),
(108, 95, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:37:38'),
(109, 95, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:37:39'),
(110, 82, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-01 12:38:46'),
(111, 34, 'Public Service (Trashmaster)', 'Cleared 1 trash dumps', 15000, '2023-10-01 12:42:35'),
(112, 34, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:42:36'),
(113, 93, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-01 12:44:47'),
(114, 97, 'San Andreas Express', 'Delivered  packages', 175000, '2023-10-01 12:47:26'),
(115, 30, 'San Andreas Express', 'Delivered  packages', 200000, '2023-10-01 12:48:33'),
(116, 95, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:52:15'),
(117, 95, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:52:16'),
(118, 30, 'San Andreas Express', 'Delivered  packages', 25000, '2023-10-01 12:55:38'),
(461, 342, 'San Andreas Express', 'Delivered  packages', 22500, '2023-10-19 12:31:53'),
(120, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 12:58:54'),
(121, 107, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 13:05:17'),
(122, 107, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 13:05:18'),
(123, 30, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-01 13:06:53'),
(124, 72, 'San Andreas Express', 'Delivered  packages', 25000, '2023-10-01 13:23:39'),
(125, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 13:25:53'),
(350, 271, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-15 12:04:06'),
(351, 269, 'Farmer Storage Co', 'Sold 12 units of wheat', 60, '2023-10-15 12:07:18'),
(130, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 15:13:07'),
(131, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-01 15:13:08'),
(380, 335, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-16 08:07:49'),
(334, 245, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-14 08:59:57'),
(449, 382, 'San Andreas Express', 'Delivered  packages', 22500, '2023-10-18 16:05:38'),
(377, 315, 'San Andreas Express', 'Delivered  packages', 22500, '2023-10-16 01:06:47'),
(136, 136, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-02 01:17:43'),
(460, 374, 'San Andreas Express', 'Delivered  packages', 15000, '2023-10-19 12:27:27'),
(139, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 07:05:13'),
(140, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 07:05:36'),
(141, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 07:09:40'),
(142, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 07:09:41'),
(143, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 07:10:18'),
(144, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 07:10:26'),
(145, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 07:13:50'),
(146, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 07:14:16'),
(147, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 07:19:43'),
(453, 419, 'San Andreas Express', 'Delivered  packages', 2500, '2023-10-18 19:21:16'),
(456, 174, 'Trucking Co.', 'Delivered 10 component crates', 12500, '2023-10-19 05:17:39'),
(452, 419, 'Public Service (Trashmaster)', 'Cleared 1 trash dumps', 15000, '2023-10-18 19:16:22'),
(151, 82, 'San Andreas Express', 'Delivered  packages', 225000, '2023-10-04 07:41:30'),
(451, 365, 'Woody Wood Works', 'Sold 3 timbers', 7500, '2023-10-18 17:17:35'),
(450, 367, 'Trucking Co.', 'Delivered 10 component crates', 12500, '2023-10-18 16:11:54'),
(448, 367, 'San Andreas Express', 'Delivered  packages', 20000, '2023-10-18 16:03:28'),
(155, 185, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-04 08:17:36'),
(398, 243, 'San Andreas Express', 'Delivered  packages', 10000, '2023-10-16 12:46:14'),
(158, 95, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 08:48:39'),
(159, 95, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 08:48:40'),
(160, 95, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-04 08:55:53'),
(425, 386, 'San Andreas Express', 'Delivered  packages', 2500, '2023-10-17 08:56:48'),
(429, 18, 'Public Service (Trashmaster)', 'Cleared 9 trash dumps', 135000, '2023-10-17 11:26:21'),
(412, 262, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-17 03:12:20'),
(407, 276, 'San Andreas Express', 'Delivered  packages', 2500, '2023-10-16 15:43:28'),
(393, 313, 'Trucking Co.', 'Delivered 10 fish crates', 12500, '2023-10-16 10:57:45'),
(383, 314, 'San Andreas Express', 'Delivered  packages', 5000, '2023-10-16 08:32:10'),
(167, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 09:32:48'),
(442, 383, 'San Andreas Express', 'Delivered  packages', 7500, '2023-10-18 05:05:38'),
(355, 263, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-15 12:32:09'),
(385, 336, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-16 08:36:17'),
(384, 314, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-16 08:33:58'),
(172, 154, 'Public Service (Trashmaster)', 'Cleared 1 trash dumps', 15000, '2023-10-04 10:12:25'),
(173, 154, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 10:12:26'),
(175, 109, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 10:42:07'),
(176, 109, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 10:42:08'),
(441, 374, 'San Andreas Express', 'Delivered  packages', 20000, '2023-10-18 03:58:31'),
(178, 83, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 10:47:39'),
(179, 83, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 10:47:40'),
(440, 374, 'Public Service (Trashmaster)', 'Cleared 5 trash dumps', 75000, '2023-10-18 03:49:55'),
(439, 276, 'San Andreas Express', 'Delivered  packages', 17500, '2023-10-17 22:56:47'),
(182, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 11:35:31'),
(455, 420, 'San Andreas Express', 'Delivered  packages', 5000, '2023-10-19 03:21:47'),
(184, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 11:37:57'),
(185, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-04 11:38:06'),
(454, 373, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-18 20:06:36'),
(187, 148, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-04 11:59:23'),
(392, 271, 'San Andreas Express', 'Delivered  packages', 22500, '2023-10-16 10:19:07'),
(381, 263, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-16 08:25:38'),
(378, 265, 'Farmer Storage Co', 'Sold 159 units of onion', 954, '2023-10-16 03:04:37'),
(371, 305, 'San Andreas Express', 'Delivered  packages', 17500, '2023-10-15 19:19:05'),
(364, 293, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-15 16:43:02'),
(363, 301, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-15 16:13:29'),
(346, 263, 'San Andreas Express', 'Delivered  packages', 5000, '2023-10-15 11:45:11'),
(362, 265, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-15 15:59:21'),
(348, 188, 'San Andreas Express', 'Delivered  packages', 17500, '2023-10-15 11:50:04'),
(382, 243, 'Trucking Co.', 'Delivered 10 component crates', 12500, '2023-10-16 08:28:49'),
(198, 132, 'Public Service (Trashmaster)', 'Cleared 10 trash dumps', 15000, '2023-10-05 00:18:42'),
(430, 338, 'San Andreas Express', 'Delivered  packages', 2500, '2023-10-17 12:45:26'),
(411, 355, 'Public Service (Trashmaster)', 'Cleared 6 trash dumps', 90000, '2023-10-16 21:23:44'),
(424, 388, 'San Andreas Express', 'Delivered  packages', 20000, '2023-10-17 08:51:42'),
(420, 382, 'San Andreas Express', 'Delivered  packages', 15000, '2023-10-17 08:01:56'),
(423, 382, 'San Andreas Express', 'Delivered  packages', 17500, '2023-10-17 08:44:52'),
(415, 382, 'San Andreas Express', 'Delivered  packages', 2500, '2023-10-17 05:29:54'),
(447, 367, 'Trucking Co.', 'Delivered 10 component crates', 12500, '2023-10-18 15:52:03'),
(329, 8, 'San Andreas Express', 'Delivered  packages', 2500, '2023-10-12 14:43:56'),
(264, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-07 02:19:00'),
(210, 132, 'Public Service (Trashmaster)', 'Cleared 10 trash dumps', 15000, '2023-10-05 07:59:31'),
(434, 382, 'San Andreas Express', 'Delivered  packages', 22500, '2023-10-17 17:02:23'),
(435, 382, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-17 17:03:51'),
(431, 292, 'San Andreas Express', 'Delivered  packages', 2500, '2023-10-17 13:09:05'),
(285, 96, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-07 14:50:16'),
(284, 96, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-07 14:44:04'),
(354, 256, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-15 12:26:42'),
(391, 293, 'San Andreas Express', 'Delivered  packages', 17500, '2023-10-16 10:05:55'),
(299, 89, 'Public Service (Trashmaster)', 'Cleared 2 trash dumps', 30000, '2023-10-08 09:58:46'),
(326, 99, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-12 11:05:01'),
(413, 382, 'San Andreas Express', 'Delivered  packages', 5000, '2023-10-17 04:56:03'),
(275, 0, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-07 09:12:19'),
(226, 96, 'Public Service (Trashmaster)', 'Cleared 10 trash dumps', 15000, '2023-10-06 02:02:24'),
(302, 123, 'Trucking Co.', 'Delivered 10 component crates', 12500, '2023-10-08 13:28:15'),
(303, 123, 'Trucking Co.', 'Delivered 10 component crates', 12500, '2023-10-08 13:42:12'),
(241, 72, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-06 14:38:26'),
(353, 271, 'Public Service (Trashmaster)', 'Cleared 0 trash dumps', 0, '2023-10-15 12:18:00'),
(231, 12, 'San Andreas Express', 'Delivered  packages', 0, '2023-10-06 11:07:24'),
(237, 96, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-06 14:01:30'),
(235, 93, 'San Andreas Express', 'Delivered 10 packages', 25000, '2023-10-06 13:11:16'),
(446, 367, 'Trucking Co.', 'Delivered 10 component crates', 12500, '2023-10-18 15:38:11');

-- --------------------------------------------------------

--
-- Table structure for table `server`
--

CREATE TABLE `server` (
  `id` int(11) NOT NULL DEFAULT 0,
  `component` int(11) NOT NULL DEFAULT 500,
  `fishstock` int(11) NOT NULL DEFAULT 1000,
  `timber` int(11) NOT NULL DEFAULT 1000,
  `crack` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=FIXED;

-- --------------------------------------------------------

--
-- Table structure for table `sms`
--

CREATE TABLE `sms` (
  `id` int(12) NOT NULL,
  `owner` int(12) NOT NULL DEFAULT -1,
  `message` varchar(64) NOT NULL DEFAULT 'ERROR  NO MSG',
  `type` int(3) NOT NULL DEFAULT 0,
  `number` int(8) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `speedcameras`
--

CREATE TABLE `speedcameras` (
  `speedID` int(11) NOT NULL,
  `speedRange` float NOT NULL DEFAULT 0,
  `speedLimit` float NOT NULL DEFAULT 0,
  `speedX` float NOT NULL DEFAULT 0,
  `speedY` float NOT NULL DEFAULT 0,
  `speedZ` float NOT NULL DEFAULT 0,
  `speedAngle` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `storage`
--

CREATE TABLE `storage` (
  `id` int(11) NOT NULL,
  `owner` varchar(25) NOT NULL DEFAULT '-',
  `posx` float NOT NULL DEFAULT 0,
  `posy` float NOT NULL DEFAULT 0,
  `posz` float NOT NULL DEFAULT 0,
  `component` int(11) NOT NULL DEFAULT 0,
  `material` int(11) NOT NULL DEFAULT 0,
  `money` int(11) NOT NULL DEFAULT 0,
  `name` varchar(26) NOT NULL DEFAULT '-',
  `price` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `tagId` int(11) NOT NULL,
  `tagText` varchar(65) NOT NULL,
  `tagFont` varchar(24) NOT NULL,
  `tagCreated` varchar(24) NOT NULL,
  `tagColor` int(10) UNSIGNED NOT NULL,
  `tagFontsize` int(10) UNSIGNED NOT NULL,
  `tagBold` int(10) UNSIGNED NOT NULL,
  `tagOwner` int(10) UNSIGNED NOT NULL,
  `tagPosx` float NOT NULL,
  `tagPosy` float NOT NULL,
  `tagPosz` float NOT NULL,
  `tagRotx` float NOT NULL,
  `tagRoty` float NOT NULL,
  `tagRotz` float NOT NULL,
  `tagExpired` int(11) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tollgate`
--

CREATE TABLE `tollgate` (
  `ID` int(11) NOT NULL,
  `Model` int(11) NOT NULL DEFAULT 0,
  `PosX` float NOT NULL DEFAULT 0,
  `PosY` float NOT NULL DEFAULT 0,
  `PosZ` float NOT NULL DEFAULT 0,
  `RotX` float NOT NULL DEFAULT 0,
  `RotY` float NOT NULL DEFAULT 0,
  `RotZ` float NOT NULL DEFAULT 0,
  `MoveX` float NOT NULL DEFAULT 0,
  `MoveY` float NOT NULL DEFAULT 0,
  `MoveZ` float NOT NULL DEFAULT 0,
  `MoveRotX` float NOT NULL DEFAULT 0,
  `MoveRotY` float NOT NULL DEFAULT 0,
  `MoveRotZ` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tollgate`
--

INSERT INTO `tollgate` (`ID`, `Model`, `PosX`, `PosY`, `PosZ`, `RotX`, `RotY`, `RotZ`, `MoveX`, `MoveY`, `MoveZ`, `MoveRotX`, `MoveRotY`, `MoveRotZ`) VALUES
(2, 968, 68.0416, -1531.22, 4.70299, 0, -90, -92.5, 68.0167, -1531.11, 4.53561, 0, -4.60001, -92.5),
(3, 968, 35.2025, -1532.4, 5.01197, 0, -90.8, 89.4, 35.2025, -1532.4, 5.01197, 0, 0.200014, 89.4),
(4, 968, -88.0002, -933.645, 19.4842, 0, -90.8, -25.7, -88.0002, -933.645, 19.4842, 0, -7.10002, -25.7),
(6, 968, -80.4825, -887.619, 15.63, 0, 90.7, -27.1, -80.4825, -887.619, 15.63, 0, 12.6, -27.1),
(7, 968, -186.366, 270.852, 11.8381, 0, -90.5, -14.8, -186.366, 270.852, 11.8381, 0, -10.2, -14.8),
(8, 968, -198.237, 279.368, 11.8681, 0, 90.2, -14.8, -198.237, 279.368, 11.8681, 0, 5.69996, -14.8),
(9, 968, 529.101, 472.494, 18.8066, 0, -90.9, 37.1, 529.101, 472.494, 18.8066, 0, -8.59997, 37.1),
(10, 968, 514.137, 469.826, 18.7896, 0, 90.5, 35.1, 516.653, 473.742, 18.9297, 0, 0, 0),
(11, 968, 625.792, -1190.58, 18.4219, 0, 90, 30, 625.792, -1190.58, 18.4219, 0, -20, 30),
(14, 968, -1125.57, 1098.59, 37.8708, 0, -90, -43.3, -1128.19, 1101.27, 38.1707, 0, 0, 0),
(15, 968, -964.746, -365.269, 35.9342, 0, -89.3, -13, -969.93, -367.619, 36.1959, 0, 0, 0),
(16, 968, -977.014, -356.157, 36.6402, 0, 93.7, -12.4, -972.867, -357.472, 36.4014, 0, 0, 0),
(17, 968, -1142.69, 1114.34, 37.8278, 0, 89.2, -43.4, -1136.31, 1114.84, 38.0379, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `toys`
--

CREATE TABLE `toys` (
  `Id` int(10) NOT NULL,
  `Owner` varchar(40) NOT NULL DEFAULT '',
  `Slot0_Model` int(8) NOT NULL DEFAULT 0,
  `Slot0_Bone` int(8) NOT NULL DEFAULT 0,
  `Slot0_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot0_Color1` int(11) NOT NULL DEFAULT 0,
  `Slot0_Color2` int(11) NOT NULL DEFAULT 0,
  `Slot0_Dettach` int(11) NOT NULL DEFAULT 0,
  `Slot1_Model` int(8) NOT NULL DEFAULT 0,
  `Slot1_Bone` int(8) NOT NULL DEFAULT 0,
  `Slot1_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot1_Color1` int(11) NOT NULL DEFAULT 0,
  `Slot1_Color2` int(11) NOT NULL DEFAULT 0,
  `Slot1_Dettach` int(11) NOT NULL DEFAULT 0,
  `Slot2_Model` int(8) NOT NULL DEFAULT 0,
  `Slot2_Bone` int(8) NOT NULL DEFAULT 0,
  `Slot2_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot2_Color1` int(11) NOT NULL DEFAULT 0,
  `Slot2_Color2` int(11) NOT NULL DEFAULT 0,
  `Slot2_Dettach` int(11) NOT NULL DEFAULT 0,
  `Slot3_Model` int(8) NOT NULL DEFAULT 0,
  `Slot3_Bone` int(8) NOT NULL DEFAULT 0,
  `Slot3_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot3_Color1` int(11) NOT NULL DEFAULT 0,
  `Slot3_Color2` int(11) NOT NULL DEFAULT 0,
  `Slot3_Dettach` int(11) NOT NULL DEFAULT 0,
  `Slot4_Model` int(8) NOT NULL DEFAULT 0,
  `Slot4_Bone` int(8) NOT NULL DEFAULT 0,
  `Slot4_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot4_Color1` int(11) NOT NULL DEFAULT 0,
  `Slot4_Color2` int(11) NOT NULL DEFAULT 0,
  `Slot4_Dettach` int(11) NOT NULL DEFAULT 0,
  `Slot5_Model` int(8) NOT NULL DEFAULT 0,
  `Slot5_Bone` int(8) NOT NULL DEFAULT 0,
  `Slot5_XPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_YPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_ZPos` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_XRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_YRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_ZRot` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_XScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_YScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_ZScale` float(20,3) NOT NULL DEFAULT 0.000,
  `Slot5_Color1` int(11) NOT NULL DEFAULT 0,
  `Slot5_Color2` int(11) NOT NULL DEFAULT 0,
  `Slot5_Dettach` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trees`
--

CREATE TABLE `trees` (
  `id` int(11) NOT NULL,
  `posx` float DEFAULT NULL,
  `posy` float DEFAULT NULL,
  `posz` float DEFAULT NULL,
  `posrx` float DEFAULT NULL,
  `posry` float DEFAULT NULL,
  `posrz` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=FIXED;

--
-- Dumping data for table `trees`
--

INSERT INTO `trees` (`id`, `posx`, `posy`, `posz`, `posrx`, `posry`, `posrz`) VALUES
(0, -1236.62, -1446.36, 108.272, 0, 0, 0),
(1, -1227.06, -1446.47, 109.733, 0, 0, 0),
(2, -1213.96, -1446.94, 111.863, 0, 0, 0),
(3, -1214.69, -1436.87, 112.772, 0, 0, 0),
(4, -1223.03, -1434.97, 111.954, 0, 0, 0),
(5, -1233.05, -1434.39, 110.382, 0, 0, 0),
(6, -1235.68, -1422.05, 110.245, 0, 0, 0),
(7, -1226.72, -1427.32, 111.808, 0, 0, 0),
(8, -1213.31, -1423.12, 113.565, 0, 0, 0),
(9, -1213.97, -1413.01, 114.355, 0, 0, 0),
(10, -1225.28, -1414.65, 113.131, 0, 0, 0),
(11, -1221.05, -1419.02, 113.287, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ucp`
--

CREATE TABLE `ucp` (
  `reg_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(24) NOT NULL DEFAULT '',
  `password` char(64) NOT NULL DEFAULT '',
  `salt` char(16) NOT NULL DEFAULT '',
  `verifemail` int(11) NOT NULL DEFAULT 0,
  `sprunk` mediumint(9) NOT NULL DEFAULT 0,
  `verifcode` text NOT NULL,
  `verification_code` decimal(10,0) NOT NULL,
  `CharName` int(11) NOT NULL,
  `CharName2` int(11) NOT NULL,
  `CharName3` int(11) NOT NULL,
  `banned` int(11) NOT NULL,
  `bannedreason` varchar(128) NOT NULL,
  `bannedby` varchar(128) NOT NULL,
  `referral` int(11) NOT NULL,
  `pin` int(11) NOT NULL DEFAULT 0,
  `DiscordID` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `ucp`
--

INSERT INTO `ucp` (`reg_id`, `username`, `password`, `salt`, `verifemail`, `sprunk`, `verifcode`, `verification_code`, `CharName`, `CharName2`, `CharName3`, `banned`, `bannedreason`, `bannedby`, `referral`, `pin`, `DiscordID`) VALUES
(1, 'Ansell', '', '1', 1, 0, '', 0, 2, 0, 0, 0, '', '', 0, 1234, 7812487547161782),
(2, 'aleew', '', '1', 1, 0, '', 0, 1, 0, 0, 0, '', '', 0, 1234, 7812487547161782),
(3, 'alhard', '', '1', 1, 0, '', 0, 4, 0, 0, 0, '', '', 0, 1234, 7812487547161782);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `id` int(10) UNSIGNED NOT NULL,
  `owner` int(11) NOT NULL,
  `model` int(11) NOT NULL DEFAULT 0,
  `color1` int(11) NOT NULL DEFAULT 0,
  `color2` int(11) NOT NULL DEFAULT 0,
  `paintjob` int(11) NOT NULL DEFAULT -1,
  `neon` int(11) NOT NULL DEFAULT 0,
  `locked` int(11) NOT NULL DEFAULT 0,
  `plate` varchar(50) NOT NULL DEFAULT 'None',
  `plate_time` bigint(20) NOT NULL DEFAULT 0,
  `ticket` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `price` int(11) NOT NULL DEFAULT 200000,
  `health` float NOT NULL DEFAULT 1000,
  `fuel` int(11) NOT NULL DEFAULT 1000,
  `x` float NOT NULL DEFAULT 0,
  `y` float NOT NULL DEFAULT 0,
  `z` float NOT NULL DEFAULT 0,
  `a` float NOT NULL DEFAULT 0,
  `int` int(11) NOT NULL DEFAULT 0,
  `vw` int(11) NOT NULL DEFAULT 0,
  `damage0` int(11) NOT NULL DEFAULT 0,
  `damage1` int(11) NOT NULL DEFAULT 0,
  `damage2` int(11) NOT NULL DEFAULT 0,
  `damage3` int(11) NOT NULL DEFAULT 0,
  `mod0` int(11) NOT NULL DEFAULT 0,
  `mod1` int(11) NOT NULL DEFAULT 0,
  `mod2` int(11) NOT NULL DEFAULT 0,
  `mod3` int(11) NOT NULL DEFAULT 0,
  `mod4` int(11) NOT NULL DEFAULT 0,
  `mod5` int(11) NOT NULL DEFAULT 0,
  `mod6` int(11) NOT NULL DEFAULT 0,
  `mod7` int(11) NOT NULL DEFAULT 0,
  `mod8` int(11) NOT NULL DEFAULT 0,
  `mod9` int(11) NOT NULL DEFAULT 0,
  `mod10` int(11) NOT NULL DEFAULT 0,
  `mod11` int(11) NOT NULL DEFAULT 0,
  `mod12` int(11) NOT NULL DEFAULT 0,
  `mod13` int(11) NOT NULL DEFAULT 0,
  `mod14` int(11) NOT NULL DEFAULT 0,
  `mod15` int(11) NOT NULL DEFAULT 0,
  `mod16` int(11) NOT NULL DEFAULT 0,
  `lumber` int(11) NOT NULL DEFAULT -1,
  `rental` bigint(20) NOT NULL DEFAULT 0,
  `gun1` int(12) DEFAULT 0,
  `ammo1` int(12) DEFAULT 0,
  `gun2` int(12) DEFAULT 0,
  `ammo2` int(12) DEFAULT 0,
  `gun3` int(12) DEFAULT 0,
  `ammo3` int(12) DEFAULT 0,
  `gun4` int(12) DEFAULT 0,
  `ammo4` int(12) DEFAULT 0,
  `gun5` int(12) DEFAULT 0,
  `ammo5` int(12) DEFAULT 0,
  `gun6` int(12) DEFAULT 0,
  `ammo6` int(12) DEFAULT 0,
  `gun7` int(12) DEFAULT 0,
  `ammo7` int(12) DEFAULT 0,
  `gun8` int(12) DEFAULT 0,
  `ammo8` int(12) DEFAULT 0,
  `gun9` int(12) DEFAULT 0,
  `ammo9` int(12) DEFAULT 0,
  `gun10` int(12) DEFAULT 0,
  `ammo10` int(12) DEFAULT 0,
  `cratecomponent` int(11) NOT NULL DEFAULT 0,
  `cratefish` int(11) NOT NULL DEFAULT 0,
  `cratelumber` int(11) NOT NULL DEFAULT 0,
  `crateplant` int(11) NOT NULL DEFAULT 0,
  `plantwheat` int(11) NOT NULL DEFAULT 0,
  `plantonion` int(11) NOT NULL DEFAULT 0,
  `plantcarrot` int(11) NOT NULL DEFAULT 0,
  `plantpotato` int(11) NOT NULL DEFAULT 0,
  `plantcorn` int(11) NOT NULL DEFAULT 0,
  `trunkcrack` int(11) NOT NULL DEFAULT 0,
  `trunkpot` int(11) NOT NULL DEFAULT 0,
  `trunkmaterial` int(11) NOT NULL DEFAULT 0,
  `trunkcomponent` int(11) NOT NULL DEFAULT 0,
  `trunkcgun` int(11) NOT NULL DEFAULT 0,
  `upgradeengine` int(11) NOT NULL DEFAULT 0,
  `upgradebody` int(11) NOT NULL DEFAULT 0,
  `insurance` int(11) NOT NULL DEFAULT 3,
  `insuranceclaim` int(11) NOT NULL DEFAULT 0,
  `insuranceclaimtime` int(11) NOT NULL DEFAULT 0,
  `ticketime` int(11) NOT NULL DEFAULT 0,
  `park` int(11) NOT NULL DEFAULT 0,
  `impound` int(11) NOT NULL DEFAULT 0,
  `impoundprice` int(11) NOT NULL DEFAULT 0,
  `tirelock` int(11) NOT NULL DEFAULT 0,
  `vehgarage` int(11) NOT NULL DEFAULT -1
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `vehicledata`
--

CREATE TABLE `vehicledata` (
  `ID` int(10) NOT NULL,
  `Faction` int(10) NOT NULL DEFAULT -1,
  `Bisnis` int(10) NOT NULL DEFAULT -1,
  `Workshop` int(10) NOT NULL DEFAULT -1,
  `Model` int(10) NOT NULL DEFAULT -1,
  `Color` varchar(24) NOT NULL DEFAULT '0|0',
  `Paintjob` int(10) NOT NULL DEFAULT -1,
  `Locked` int(10) NOT NULL DEFAULT 0,
  `Plate` varchar(24) NOT NULL DEFAULT 'No Have',
  `HealthFuel` varchar(24) NOT NULL DEFAULT '1000|1000',
  `VehiclePos` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00',
  `IntVw` varchar(24) NOT NULL DEFAULT '0|0',
  `Damage` varchar(24) NOT NULL DEFAULT '0|0|0|0',
  `Mod` varchar(52) NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0',
  `Weapon` varchar(24) NOT NULL DEFAULT '0|0|0|0',
  `Ammo` varchar(24) NOT NULL DEFAULT '0|0|0|0',
  `TypeAmmo` varchar(24) NOT NULL DEFAULT '0|0|0|0',
  `Storage` varchar(24) NOT NULL DEFAULT '0|0|0|0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_object`
--

CREATE TABLE `vehicle_object` (
  `id` int(10) UNSIGNED NOT NULL,
  `model` int(10) UNSIGNED DEFAULT NULL,
  `vehicle` int(10) UNSIGNED DEFAULT NULL,
  `color` int(24) DEFAULT NULL,
  `type` tinyint(2) UNSIGNED DEFAULT NULL,
  `x` float DEFAULT NULL,
  `y` float DEFAULT NULL,
  `z` float DEFAULT NULL,
  `rx` float DEFAULT NULL,
  `ry` float DEFAULT NULL,
  `rz` float DEFAULT NULL,
  `text` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Text',
  `font` varchar(24) DEFAULT NULL,
  `fontcolor` int(10) UNSIGNED DEFAULT NULL,
  `fontsize` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vouchers`
--

CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL,
  `code` varchar(52) NOT NULL DEFAULT '',
  `vip` int(11) NOT NULL DEFAULT 0,
  `vip_time` int(11) NOT NULL DEFAULT 0,
  `gold` int(11) NOT NULL DEFAULT 0,
  `claimvip` varchar(52) NOT NULL DEFAULT '0|0|0',
  `admin` varchar(52) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'None',
  `donature` varchar(16) NOT NULL DEFAULT 'None',
  `claim` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `warnrecord`
--

CREATE TABLE `warnrecord` (
  `ID` int(11) NOT NULL,
  `owner` int(11) NOT NULL DEFAULT -1,
  `reason` varchar(128) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `weaponsettings`
--

CREATE TABLE `weaponsettings` (
  `Owner` int(11) NOT NULL,
  `WeaponID` tinyint(4) NOT NULL,
  `PosX` float DEFAULT 0,
  `PosY` float DEFAULT 0,
  `PosZ` float DEFAULT 0,
  `RotX` float DEFAULT 0,
  `RotY` float DEFAULT 44,
  `RotZ` float DEFAULT 0,
  `Bone` tinyint(4) NOT NULL DEFAULT 1,
  `Hidden` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=FIXED;

--
-- Dumping data for table `weaponsettings`
--

INSERT INTO `weaponsettings` (`Owner`, `WeaponID`, `PosX`, `PosY`, `PosZ`, `RotX`, `RotY`, `RotZ`, `Bone`, `Hidden`) VALUES
(3, 24, -0.258, -0.143, 0.057, 0, 44.5, 0, 1, 0),
(3, -1, 0.125, -0.019, 0, -176.7, 0.3, 48.6, 1, 0),
(5, 24, -0.195, 0.058, 0.175, 93.9, 166.7, 0, 1, 0),
(5, 8, 0.382, -0.29, -0.033, 166.2, -90.4, -120.4, 1, 0),
(9, 24, -0.116, -0.011, -0.205, 70, 164.5, 0, 1, 0),
(9, 30, -0.116, -0.211, 0.088, 0, 34.5, 10, 1, 0),
(9, 8, 0.2, -0.211, 0.088, 10, 224.5, 40, 1, 0),
(10, 24, -0.116, 0.189, 0.088, 0, 44.5, 0, 1, 1),
(123, 5, -0.177, -0.112, -0.03, -22.1, 65.5, 0, 1, 1),
(10, 3, -0.216, -0.011, -0.112, -20, 264.5, 90, 1, 0),
(10, 31, -0.116, -0.111, 0.088, 0, 44.5, 0, 1, 0),
(150, 25, 0, 0, 0, 0, 44, 0, 18, 1),
(18, 5, -0.516, -0.111, -0.112, -10, 84.5, -10, 17, 0),
(47, 5, -0.115, 0.188, 0, 44.5, 0, 0, 1, 1),
(9, 25, -0.116, -0.011, -0.212, 70, 164.5, 0, 1, 1),
(29, 5, 0, 0, 0, 0, 44, 0, 1, 1),
(29, 15, 0, 0, 0, 0, 44, 0, 1, 1),
(19, 25, 0, 0, 0, 0, 44, 0, 1, 1),
(18, 6, 0, 0, 0, 0, 44, 0, 1, 1),
(18, 9, 0.384, -0.111, -0.212, -90, -25.5, 180, 1, 0),
(10, 30, -0.116, -0.111, 0.088, 0, 44.5, 0, 1, 0),
(15, 25, 0, 0, 0, 0, 44, 0, 1, 1),
(10, 27, 0, 0, 0, 0, 44, 0, 1, 1),
(57, 24, 0, 0, 0, 0, 44, 0, 1, 1),
(5, 31, 0.289, -0.149, -0.009, -10.8, -153.8, 5.3, 1, 0),
(150, 31, 0, 0, 0, 0, 44, 0, 1, 1),
(19, 31, 0, 0, 0, 0, 44, 0, 1, 1),
(9, 4, 0.154, -0.128, -0.259, 0, 44.5, 0, 1, 0),
(19, 24, -0.19, 0.02, 0.146, 86.8, -180, -14.6, 1, 0),
(150, 9, 0, 0, 0, 0, 44, 0, 1, 1),
(19, 15, 0, 0, 0, 0, 44, 0, 1, 1),
(150, 24, 0, 0, 0, 0, 44, 0, 8, 1),
(2, 8, 0.269, -0.142, 0.088, -15.2, -128.2, -6.4, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `weapon_factions`
--

CREATE TABLE `weapon_factions` (
  `userid` int(10) UNSIGNED NOT NULL,
  `weaponid` tinyint(3) UNSIGNED NOT NULL,
  `ammo` int(11) NOT NULL,
  `slot` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `weapon_players`
--

CREATE TABLE `weapon_players` (
  `userid` int(10) UNSIGNED NOT NULL,
  `slot` int(10) UNSIGNED NOT NULL,
  `weaponid` int(10) UNSIGNED NOT NULL,
  `ammo` int(11) NOT NULL,
  `created` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `workshop`
--

CREATE TABLE `workshop` (
  `ID` int(11) NOT NULL,
  `name` varchar(52) NOT NULL,
  `owner` varchar(52) NOT NULL DEFAULT '-',
  `price` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `cash` int(11) NOT NULL,
  `component` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `text` varchar(128) NOT NULL,
  `wspos` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00|0.00	',
  `gateposf` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00|0.00	',
  `gateposr` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00|0.00	',
  `boardpos` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00|0.00	',
  `buttompos` varchar(52) NOT NULL DEFAULT '0.00|0.00|0.00|0.00|0.00|0.00	'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `workshop_employee`
--

CREATE TABLE `workshop_employee` (
  `ID` int(11) NOT NULL,
  `Workshop` int(10) UNSIGNED NOT NULL,
  `Name` varchar(24) NOT NULL,
  `Time` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actor`
--
ALTER TABLE `actor`
  ADD PRIMARY KEY (`actorID`);

--
-- Indexes for table `aksesoris`
--
ALTER TABLE `aksesoris`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `arrestrecord`
--
ALTER TABLE `arrestrecord`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `atms`
--
ALTER TABLE `atms`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `baju`
--
ALTER TABLE `baju`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Owner` (`Owner`);

--
-- Indexes for table `bisnis`
--
ALTER TABLE `bisnis`
  ADD PRIMARY KEY (`ID`) USING BTREE;

--
-- Indexes for table `business_employee`
--
ALTER TABLE `business_employee`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `casino`
--
ALTER TABLE `casino`
  ADD PRIMARY KEY (`casinoID`);

--
-- Indexes for table `cd`
--
ALTER TABLE `cd`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cd_employee`
--
ALTER TABLE `cd_employee`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`contactID`);

--
-- Indexes for table `crimerecord`
--
ALTER TABLE `crimerecord`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealership`
--
ALTER TABLE `dealership`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `doors`
--
ALTER TABLE `doors`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `faction_vehpoint`
--
ALTER TABLE `faction_vehpoint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `familys`
--
ALTER TABLE `familys`
  ADD PRIMARY KEY (`ID`) USING BTREE;

--
-- Indexes for table `fishingarea`
--
ALTER TABLE `fishingarea`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `flat`
--
ALTER TABLE `flat`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `flatroom`
--
ALTER TABLE `flatroom`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `flat_furniture`
--
ALTER TABLE `flat_furniture`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `flat_storage`
--
ALTER TABLE `flat_storage`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `flat_structure`
--
ALTER TABLE `flat_structure`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `flat_weapon`
--
ALTER TABLE `flat_weapon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `furniture`
--
ALTER TABLE `furniture`
  ADD PRIMARY KEY (`furnitureID`);

--
-- Indexes for table `furnobject`
--
ALTER TABLE `furnobject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `furnstore`
--
ALTER TABLE `furnstore`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `garbage`
--
ALTER TABLE `garbage`
  ADD PRIMARY KEY (`garbageID`);

--
-- Indexes for table `gates`
--
ALTER TABLE `gates`
  ADD PRIMARY KEY (`ID`) USING BTREE;

--
-- Indexes for table `gstations`
--
ALTER TABLE `gstations`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `gymobjects`
--
ALTER TABLE `gymobjects`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `housestruct`
--
ALTER TABLE `housestruct`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `jailrecord`
--
ALTER TABLE `jailrecord`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ladang`
--
ALTER TABLE `ladang`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lemari`
--
ALTER TABLE `lemari`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lockers`
--
ALTER TABLE `lockers`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `maps`
--
ALTER TABLE `maps`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `objects`
--
ALTER TABLE `objects`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `parks`
--
ALTER TABLE `parks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plants`
--
ALTER TABLE `plants`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`reg_id`,`sprunk`) USING BTREE;

--
-- Indexes for table `privategarage`
--
ALTER TABLE `privategarage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `removebuild`
--
ALTER TABLE `removebuild`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `rentplayer`
--
ALTER TABLE `rentplayer`
  ADD PRIMARY KEY (`rID`) USING BTREE;

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `server`
--
ALTER TABLE `server`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `sms`
--
ALTER TABLE `sms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `speedcameras`
--
ALTER TABLE `speedcameras`
  ADD PRIMARY KEY (`speedID`);

--
-- Indexes for table `storage`
--
ALTER TABLE `storage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`tagId`);

--
-- Indexes for table `tollgate`
--
ALTER TABLE `tollgate`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `toys`
--
ALTER TABLE `toys`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `id` (`Owner`);

--
-- Indexes for table `trees`
--
ALTER TABLE `trees`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `ucp`
--
ALTER TABLE `ucp`
  ADD PRIMARY KEY (`reg_id`,`sprunk`) USING BTREE;

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `vehicledata`
--
ALTER TABLE `vehicledata`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `vehicle_object`
--
ALTER TABLE `vehicle_object`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vouchers`
--
ALTER TABLE `vouchers`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `warnrecord`
--
ALTER TABLE `warnrecord`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `weaponsettings`
--
ALTER TABLE `weaponsettings`
  ADD PRIMARY KEY (`Owner`,`WeaponID`) USING BTREE,
  ADD UNIQUE KEY `Owner` (`Owner`,`WeaponID`) USING BTREE;

--
-- Indexes for table `weapon_factions`
--
ALTER TABLE `weapon_factions`
  ADD PRIMARY KEY (`userid`,`weaponid`);

--
-- Indexes for table `weapon_players`
--
ALTER TABLE `weapon_players`
  ADD PRIMARY KEY (`userid`,`weaponid`);

--
-- Indexes for table `workshop`
--
ALTER TABLE `workshop`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `workshop_employee`
--
ALTER TABLE `workshop_employee`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actor`
--
ALTER TABLE `actor`
  MODIFY `actorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `aksesoris`
--
ALTER TABLE `aksesoris`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT for table `arrestrecord`
--
ALTER TABLE `arrestrecord`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `baju`
--
ALTER TABLE `baju`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `business_employee`
--
ALTER TABLE `business_employee`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `casino`
--
ALTER TABLE `casino`
  MODIFY `casinoID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cd_employee`
--
ALTER TABLE `cd_employee`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `contactID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `crimerecord`
--
ALTER TABLE `crimerecord`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `flat`
--
ALTER TABLE `flat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `flatroom`
--
ALTER TABLE `flatroom`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `flat_furniture`
--
ALTER TABLE `flat_furniture`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `flat_storage`
--
ALTER TABLE `flat_storage`
  MODIFY `itemID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `flat_structure`
--
ALTER TABLE `flat_structure`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1254;

--
-- AUTO_INCREMENT for table `flat_weapon`
--
ALTER TABLE `flat_weapon`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `furniture`
--
ALTER TABLE `furniture`
  MODIFY `furnitureID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1224;

--
-- AUTO_INCREMENT for table `furnobject`
--
ALTER TABLE `furnobject`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1089;

--
-- AUTO_INCREMENT for table `furnstore`
--
ALTER TABLE `furnstore`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `garbage`
--
ALTER TABLE `garbage`
  MODIFY `garbageID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gymobjects`
--
ALTER TABLE `gymobjects`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `housestruct`
--
ALTER TABLE `housestruct`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jailrecord`
--
ALTER TABLE `jailrecord`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `maps`
--
ALTER TABLE `maps`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `objects`
--
ALTER TABLE `objects`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=438;

--
-- AUTO_INCREMENT for table `parks`
--
ALTER TABLE `parks`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `reg_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `removebuild`
--
ALTER TABLE `removebuild`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=462;

--
-- AUTO_INCREMENT for table `sms`
--
ALTER TABLE `sms`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `speedcameras`
--
ALTER TABLE `speedcameras`
  MODIFY `speedID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `tagId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tollgate`
--
ALTER TABLE `tollgate`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `toys`
--
ALTER TABLE `toys`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ucp`
--
ALTER TABLE `ucp`
  MODIFY `reg_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_object`
--
ALTER TABLE `vehicle_object`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `warnrecord`
--
ALTER TABLE `warnrecord`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `workshop_employee`
--
ALTER TABLE `workshop_employee`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
